"""Numerical and record checks shared by the controlled revision experiments."""
import numpy as np

def binary_metrics(y, probability):
    y=np.asarray(y);p=np.asarray(probability,dtype=float)
    if y.ndim!=1 or p.shape!=y.shape or not len(y):raise ValueError('nonempty aligned vectors required')
    if not np.isin(y,[0,1]).all() or not np.isfinite(p).all() or np.any((p<0)|(p>1)):raise ValueError('invalid binary labels/probabilities')
    if len(np.unique(y))!=2:raise ValueError('AUROC requires both classes')
    y=y.astype(int)
    order=np.argsort(p,kind='stable');sorted_p=p[order];sorted_y=y[order]
    starts=np.r_[0,np.flatnonzero(sorted_p[1:]!=sorted_p[:-1])+1];ends=np.r_[starts[1:],len(p)]
    pos=np.add.reduceat(sorted_y,starts);neg=ends-starts-pos
    auc=float(np.sum(pos*(np.cumsum(neg)-neg+.5*neg))/(y.sum()*(len(y)-y.sum())))
    safe=np.clip(p,1e-7,1-1e-7)
    return {'auc':auc,'log_loss':float(np.mean(-y*np.log(safe)-(1-y)*np.log1p(-safe))),'brier':float(np.mean((p-y)**2))}

def unique_records(rows,key,expected=None,label_field=None,expected_labels=None):
    ids=[r[key] for r in rows]
    if len(ids)!=len(set(ids)):raise ValueError(f'duplicate {key} values')
    records=dict(zip(ids,rows,strict=True))
    if expected is not None and set(records)!=set(expected):raise ValueError('missing or unexpected identifiers')
    if expected_labels is not None:
        for id,row in records.items():
            if int(row[label_field])!=int(expected_labels[id]):raise ValueError(f'label mismatch for {id}')
    return records

def validate_probe_config(cfg):
    # This experiment has a defined 8-vs-16 checkpoint comparison.
    if cfg['epochs']!=16:raise ValueError('this probe requires 16 epochs for its declared checkpoint comparison')
    if cfg['optimizer']!='AdamW':raise ValueError('unsupported optimizer')
    if len(cfg['train_outer_folds'])!=len(set(cfg['train_outer_folds'])):raise ValueError('duplicate training folds')
    groups=[set(cfg['train_outer_folds']),{cfg['validation_outer_fold']},{cfg['audit_outer_fold']}]
    if any(groups[i]&groups[j] for i in range(3) for j in range(i)):raise ValueError('training/validation/audit overlap')
    if set.union(*groups)!={0,1,2,3,4}:raise ValueError('five outer folds must be assigned once')
    if cfg['batch_size']<1 or cfg['weight_decay']<0 or any(x<=0 for x in cfg['learning_rates']):raise ValueError('invalid training hyperparameters')
    return cfg
