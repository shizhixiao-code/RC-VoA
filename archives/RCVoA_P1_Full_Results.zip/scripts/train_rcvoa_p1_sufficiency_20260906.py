"""Bounded MILK-only training diagnostic; never opens external data."""
from pathlib import Path
import csv, json, time, hashlib, random, os, argparse, copy
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from torchvision import models, transforms
from PIL import Image
from rcvoa_revision_checks import binary_metrics,validate_probe_config

ROOT=Path(__file__).resolve().parents[1]
# New runs cannot overwrite the delivered P1 experiment.
OUT=ROOT/'artifacts/analysis/rcvoa_p2_revision_20260907/training_rerun'
METRIC_VERSION='raw_auc_brier_logloss_clip_1e-7_v2'
CFG=ROOT/'configs/rcvoa/rcvoa_p1_revision_20260906.json'

def read(path):
    with path.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(path, obj):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2)+'\n');tmp.replace(path)
def csvwrite(path, rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
class Images(Dataset):
    def __init__(self,rows,modality,train):
        self.rows=rows
        self.paths=[ROOT/r[modality+'_image_path'] for r in rows]
        aug=[transforms.RandomResizedCrop(224,scale=(.75,1.)),transforms.RandomHorizontalFlip(),transforms.RandomVerticalFlip(),transforms.RandomRotation(20),transforms.ColorJitter(.15,.15,.15,.02)] if train else [transforms.Resize(256),transforms.CenterCrop(224)]
        self.transform=transforms.Compose(aug+[transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
    def __len__(self):return len(self.rows)
    def __getitem__(self,i):
        with Image.open(self.paths[i]) as im:x=self.transform(im.convert('RGB'))
        return x,int(self.rows[i]['strict_cancer'])

def loader(rows,modality,train,seed,batch_size=16):
    g=torch.Generator().manual_seed(seed)
    return DataLoader(Images(rows,modality,train),batch_size=batch_size if train else 2*batch_size,shuffle=train,num_workers=2,pin_memory=True,persistent_workers=True,generator=g)

def build(arch):
    model=getattr(models,arch)(weights=None)
    filename='efficientnet_b0_rwightman-7f5810bc.pth' if arch=='efficientnet_b0' else 'convnext_tiny-983f1562.pth'
    model.load_state_dict(torch.load(ROOT/'artifacts/pretrained'/filename,map_location='cpu',weights_only=True))
    model.classifier[-1]=nn.Linear(model.classifier[-1].in_features,2)
    return model.to('cuda')

@torch.no_grad()
def evaluate(model,dl):
    model.eval(); probs=[];ys=[]
    for x,y in dl:
        with torch.autocast('cuda',dtype=torch.bfloat16):z=model(x.to('cuda',non_blocking=True))
        probs.extend(z.float().softmax(1)[:,1].cpu().tolist());ys.extend(y.tolist())
    return binary_metrics(ys,probs),probs

def main():
    args=argparse.ArgumentParser();args.add_argument('--job',default='all');args=args.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    config=json.loads(CFG.read_text());cfg=validate_probe_config(config['training_probe']);config_hash=hashlib.sha256(CFG.read_bytes()).hexdigest()
    assert torch.cuda.is_available(),'CUDA required; CPU fallback is not permitted for this diagnostic'
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    split=read(ROOT/'data/splits/rcvoa_milk_strict_cancer_v1.csv')
    manifest={r['lesion_id']:r for r in read(ROOT/'data/modeling_ready/skin/rcvoa_data_lock_v1/milk10k_lesions.csv')}
    components={}
    for r in sorted(split,key=lambda r:r['lesion_id']):components.setdefault(r['partition_group_id'],{**manifest[r['lesion_id']],**r})
    rows=list(components.values());assert len(rows)==4717
    groups={s:[r for r in rows if int(r['outer_fold']) in folds] for s,folds in [('train',cfg['train_outer_folds']),('validation',[cfg['validation_outer_fold']]),('audit',[cfg['audit_outer_fold']])]}
    assert not(set(r['partition_group_id'] for r in groups['train']) & set(r['partition_group_id'] for r in groups['validation']+groups['audit']))
    csvwrite(OUT/'component_roles.csv',[{'component':r['partition_group_id'],'lesion_id':r['lesion_id'],'role':s,'label':r['strict_cancer']} for s,rs in groups.items() for r in rs])
    write(OUT/'runtime.json',{'torch':torch.__version__,'gpu':torch.cuda.get_device_name(),'config_sha256':config_hash,'role_counts':{s:len(rs) for s,rs in groups.items()},'cpu_threads':4,'workers':2,'full_network_finetuning':True,'augmentation':'same as original except duplicate components represented by lexicographically first lesion'})
    for arch in cfg['architectures']:
      for modality in cfg['modalities']:
       for lr in cfg['learning_rates']:
        name=f'{arch}_{modality}_{lr:g}';directory=OUT/name
        if args.job not in ('all',name):continue
        if (directory/'result.json').exists():
            receipt=json.loads((directory/'result.json').read_text())
            assert receipt['config_sha256']==config_hash
            assert receipt.get('metric_version')==METRIC_VERSION,'incompatible historical metric receipt; preserve it and use a new output directory'
            continue
        directory.mkdir(exist_ok=True)
        seed=cfg['seed'];random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
        model=build(arch);opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=cfg['weight_decay'])
        dls={s:loader(rs,modality,s=='train',seed,cfg['batch_size']) for s,rs in groups.items()}
        counts=np.bincount([int(r['strict_cancer']) for r in groups['train']]);weights=torch.tensor(len(groups['train'])/(2*counts),dtype=torch.float32,device='cuda')
        lossfn=nn.CrossEntropyLoss(weight=weights);history=[];best=None;start=time.time()
        for epoch in range(1,cfg['epochs']+1):
            model.train();total=0.;n=0
            for x,y in dls['train']:
                x=x.to('cuda',non_blocking=True);y=y.to('cuda',non_blocking=True);opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model(x);loss=lossfn(z,y)
                loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
                total+=float(loss.detach())*len(y);n+=len(y)
            metrics,_=evaluate(model,dls['validation'])
            # This is a sample-count average of batch-normalized weighted CE,
            # not a single global class-weight-normalized loss.
            record={'epoch':epoch,'weighted_train_loss':total/n,'loss_aggregation':'sample-count average of batch-normalized weighted cross entropy',**{'validation_'+k:v for k,v in metrics.items()},'elapsed_seconds':time.time()-start}
            history.append(record);csvwrite(directory/'learning_curve.csv',history)
            key=(-metrics['auc'],metrics['log_loss'],epoch)
            if best is None or key<best[0]:
                best=(key,epoch);torch.save(model.state_dict(),directory/'validation_best.pt')
            if epoch in (8,16):torch.save(model.state_dict(),directory/f'epoch_{epoch}.pt')
            print(json.dumps({'job':name,**record}),flush=True)
        audit=[]
        for label,filename,epoch in [('epoch8','epoch_8.pt',8),('epoch16','epoch_16.pt',16),('validation_best','validation_best.pt',best[1])]:
            model.load_state_dict(torch.load(directory/filename,weights_only=True));metrics,probs=evaluate(model,dls['audit'])
            audit.append({'checkpoint':label,'epoch':epoch,**metrics})
            csvwrite(directory/f'audit_{label}.csv',[{'component':r['partition_group_id'],'label':r['strict_cancer'],'probability':p} for r,p in zip(groups['audit'],probs,strict=True)])
        # Simulated early stopping uses only the validation trajectory.
        incumbent=-float('inf');bad=0;stop=16;selected=1
        for row in history:
            if row['validation_auc']>incumbent+.001:incumbent=row['validation_auc'];bad=0;selected=row['epoch']
            else:bad+=1
            if bad>=4:stop=row['epoch'];break
        write(directory/'result.json',{'job':name,'config_sha256':config_hash,'metric_version':METRIC_VERSION,'best_epoch':best[1],'simulated_early_stop_epoch':stop,'simulated_selected_epoch':selected,'audit':audit,'epochs':cfg['epochs'],'elapsed_seconds':time.time()-start})
        del model,opt,dls;torch.cuda.empty_cache()
    print('MILK_TRAINING_PROBE_COMPLETE',flush=True)

if __name__=='__main__':main()
