"""R20 complete validation-selected ensemble with common source calibration.

This entry point reads MILK training/validation images only. Calibration and
external inference are separate phases; no external endpoint is accessed here.
"""
from pathlib import Path
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import argparse,csv,hashlib,json,random,time
import numpy as np
import torch
from torch import nn
from train_rcvoa_p1_sufficiency_20260906 import build,loader,read,evaluate

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'artifacts/analysis/rcvoa_r20_model_pipeline_20260909'
DESIGN={
    'version':'R20_20260909',
    'evidence_role':'post-outcome model-selection robustness; preserves original frozen studies; not new untouched external confirmation',
    'architecture':'convnext_tiny',
    'architecture_rationale':'alternative architecture already used in the MILK training probe; one complete pipeline, not an external-outcome architecture search',
    'calibration_fold':0,'validation_folds':[1,2,3,4],
    'network_training':'for each validation fold, train on the other three of folds1-4; no fold0 image or label enters network fitting, LR or checkpoint selection',
    'representatives':'one lexicographically first lesion per duplicate component; original five MILK group folds',
    'modalities':['clinical','dermoscopic'],'learning_rates':[.0002,.00005],
    'max_epochs':16,'early_stop_patience':4,'early_stop_logloss_min_delta':.0001,
    'selection':'minimum unweighted validation log loss; then larger validation AUROC, earlier epoch, smaller learning rate; no calibration/external metric selects models',
    'optimizer':'AdamW','weight_decay':.0001,'batch_size':16,'gradient_norm_clip':5.,
    'loss':'class-balanced cross entropy using training-fold frequencies',
    'seed':2026090920,'job_seed':'base + 100*validation_fold + modality_index; same seed across learning rates',
    'cpu_threads':4,'workers_per_loader':2,'mixed_precision':'bfloat16','deterministic_algorithms':True,
    'augmentation':'RandomResizedCrop224 scale(.75,1), horizontal/vertical flips, rotation20deg, ColorJitter(.15,.15,.15,.02), ImageNet normalization',
    'inference_transform':'Resize256, CenterCrop224, RGB tensor, ImageNet normalization',
    'ensemble':'mean raw binary logit difference over four selected members, separately by modality; exact same operator on common calibration and external rows',
    'calibration':'MILK fold0 only; modality-specific Platt logistic map on standardized ensemble logit; SUM unweighted NLL + .5*slope^2, intercept unpenalized; all fold0 for final fit',
    'fusion':'fixed mean of the two calibrated modality probabilities; no external fusion selection',
    'thresholds':'largest source-calibration p1 and p12 thresholds attaining at least90% cancer sensitivity; whole ties; external thresholds frozen',
    'source_oof_diagnostic':'five group folds within source calibration fold0; crossfit Platt maps and thresholds only; networks remain excluded from all fold0 rows; not whole-pipeline nested OOF',
    'external_cohorts':['MRA','HIBA','UQ'],'primary_definition':'single four-member calibrated pipeline in each cohort; not original three-seed consensus',
    'capacity':'q=.20 of original-negative candidates in each specified batch, floor; descending calibrated clinical probability then stable ID; all-comer primary and strict MRA/HIBA companions',
    'utility':{'r':9.,'cA':.1,'cR':0.},
    'comparators':['initial no acquisition','original selective','exact expected random','same selected cases direct escalation','full paired acquisition','grouped calibration-sensitivity and burden matched clinical thresholds'],
    'primary_checks':['discrimination versus selective decision gains','candidate cancer crossing opportunities and non-cancer burden','value against random and no-image alternatives'],
    'uncertainty':'10000 paired cluster resamples; frozen operating endpoints/selected sets and full-modality AUROC; AUVBC difference across q0-.30 step.05 fixed selections; grouped local-threshold controls refit thresholds/reallocate capacity using R11 algorithm',
    'bootstrap_seed':2026090922,'group_threshold_seed':2026090709,
    'unknown_endpoints':'all enter capacity; known endpoint gain minus all imaging costs divided by all N; excluded diagnoses not negatives',
    'scope_limits':'one alternate selected model pipeline; no retraining of original200refits or new clinical-effect evaluation',
    'stop_rule':'retain all unfavorable findings, no candidate/utility revision after new external outcomes; stop and check after manuscript integration',
}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()
def js(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n',encoding='utf-8');tmp.replace(path)
def wc(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def milk_rows():
    split=read(ROOT/'data/splits/rcvoa_milk_strict_cancer_v1.csv')
    manifest={r['lesion_id']:r for r in read(ROOT/'data/modeling_ready/skin/rcvoa_data_lock_v1/milk10k_lesions.csv')}
    components={}
    for r in sorted(split,key=lambda r:r['lesion_id']):components.setdefault(r['partition_group_id'],{**manifest[r['lesion_id']],**r})
    rows=list(components.values());assert len(rows)==4717
    return rows
def lock():
    OUT.mkdir(parents=True,exist_ok=True)
    paths=['data/splits/rcvoa_milk_strict_cancer_v1.csv','data/modeling_ready/skin/rcvoa_data_lock_v1/milk10k_lesions.csv',
           'artifacts/pretrained/convnext_tiny-983f1562.pth','scripts/train_rcvoa_p1_sufficiency_20260906.py','scripts/rcvoa_revision_checks.py']
    payload={'design':DESIGN,'inputs':{p:sha(ROOT/p) for p in paths},'training_script_sha256':sha(__file__)}
    path=OUT/'protocol_lock.json'
    if path.exists():assert json.loads(path.read_text())==payload,'immutable training lock drift'
    else:js(path,payload)
    rows=milk_rows();assert sum(int(r['outer_fold'])==0 for r in rows)==943
    wc(OUT/'private_component_roles.csv',[dict(component=r['partition_group_id'],lesion_id=r['lesion_id'],fold=r['outer_fold']) for r in rows])
    roles=[]
    for v in [1,2,3,4]:
        groups={role:{r['partition_group_id'] for r in rows if int(r['outer_fold']) in folds} for role,folds in [('train',[j for j in [1,2,3,4] if j!=v]),('validation',[v]),('calibration',[0])]}
        assert all(groups[a].isdisjoint(groups[b]) for a,b in [('train','validation'),('train','calibration'),('validation','calibration')])
        roles.append(dict(member=v,training_components=len(groups['train']),validation_components=len(groups['validation']),calibration_components=len(groups['calibration']),group_overlap=0))
    wc(OUT/'partition_summary.csv',roles);js(OUT/'lock_receipt.json',{'unix_time':time.time(),'protocol_sha256':sha(path),'status':'before_new_training'})
def verify():
    p=json.loads((OUT/'protocol_lock.json').read_text());assert p['design']==DESIGN and p['training_script_sha256']==sha(__file__)
    for path,h in p['inputs'].items():assert sha(ROOT/path)==h,path
def training():
    verify();assert torch.cuda.is_available();torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    rows=milk_rows();ph=sha(OUT/'protocol_lock.json');receipts=[]
    js(OUT/'runtime.json',{'torch':torch.__version__,'numpy':np.__version__,'gpu':torch.cuda.get_device_name(),'cuda':torch.version.cuda,'protocol_sha256':ph})
    for member in DESIGN['validation_folds']:
      tr=[r for r in rows if int(r['outer_fold']) not in [0,member]];va=[r for r in rows if int(r['outer_fold'])==member]
      for mi,modality in enumerate(DESIGN['modalities']):
       for lr in DESIGN['learning_rates']:
        job=f'member{member}_{modality}_lr{lr:g}';directory=OUT/'training'/job;directory.mkdir(parents=True,exist_ok=True)
        rp=directory/'result.json'
        if rp.exists():
            receipt=json.loads(rp.read_text());assert receipt['protocol_sha256']==ph and sha(directory/'validation_best.pt')==receipt['checkpoint_sha256'];receipts.append(receipt);continue
        seed=DESIGN['seed']+100*member+mi;random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
        model=build(DESIGN['architecture']);opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=DESIGN['weight_decay'])
        train_dl=loader(tr,modality,True,seed,16);val_dl=loader(va,modality,False,seed,16)
        counts=np.bincount([int(r['strict_cancer']) for r in tr]);weights=torch.tensor(len(tr)/(2*counts),device='cuda',dtype=torch.float32);lossfn=nn.CrossEntropyLoss(weight=weights)
        history=[];best=None;stop_best=float('inf');bad=0;start=time.time()
        print(json.dumps({'starting_job':job,'completed_jobs':len(receipts),'total_jobs':16}),flush=True)
        for epoch in range(1,17):
            model.train();total=0.;N=0
            for x,y in train_dl:
                x=x.to('cuda',non_blocking=True);y=y.to('cuda',non_blocking=True);opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):z=model(x);loss=lossfn(z,y)
                loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step();total+=float(loss.detach())*len(y);N+=len(y)
            metrics,prob=evaluate(model,val_dl);assert all(np.isfinite(v) for v in metrics.values())
            row={'epoch':epoch,'weighted_train_loss':total/N,**{'validation_'+k:v for k,v in metrics.items()},'seconds':time.time()-start};history.append(row);wc(directory/'learning_curve.csv',history)
            key=(metrics['log_loss'],-metrics['auc'],epoch,lr)
            if best is None or key<best[0]:
                best=(key,epoch,metrics);tmp=directory/'validation_best.tmp.pt';torch.save(model.state_dict(),tmp);tmp.replace(directory/'validation_best.pt')
                np.savez_compressed(directory/'private_validation_best.npz',id=np.array([r['partition_group_id'] for r in va]),y=np.array([int(r['strict_cancer']) for r in va]),probability=prob)
            if metrics['log_loss']<stop_best-DESIGN['early_stop_logloss_min_delta']:stop_best=metrics['log_loss'];bad=0
            else:bad+=1
            progress={'job':job,'member':member,'modality':modality,'learning_rate':lr,'epoch':epoch,'best_epoch':best[1],'best_validation_log_loss':best[2]['log_loss'],'completed_jobs':len(receipts),'total_jobs':16,'last_update':time.time(),**row}
            js(OUT/'training_progress.json',progress);print(json.dumps(progress),flush=True)
            if bad>=DESIGN['early_stop_patience']:break
        receipt={'job':job,'member':member,'modality':modality,'learning_rate':lr,'seed':seed,'protocol_sha256':ph,'checkpoint_sha256':sha(directory/'validation_best.pt'),'best_epoch':best[1],'best_validation':best[2],'epochs_run':epoch,'early_stopped':epoch<16,'training_components':len(tr),'validation_components':len(va),'calibration_components_used':0,'external_rows_used':0,'duration_seconds':time.time()-start}
        js(rp,receipt);receipts.append(receipt)
        del model,opt,train_dl,val_dl;torch.cuda.empty_cache()
    selected=[]
    for member in DESIGN['validation_folds']:
      for modality in DESIGN['modalities']:
        options=[r for r in receipts if r['member']==member and r['modality']==modality]
        r=min(options,key=lambda r:(r['best_validation']['log_loss'],-r['best_validation']['auc'],r['best_epoch'],r['learning_rate']))
        selected.append({**r,'checkpoint_path':(OUT/'training'/r['job']/'validation_best.pt').relative_to(ROOT).as_posix()})
    js(OUT/'selected_models.json',{'protocol_sha256':ph,'selected':selected,'all_training_jobs':receipts,'selection_time':time.time(),'selected_without_calibration_or_external_results':True})
    js(OUT/'training_complete.json',{'completed_jobs':len(receipts),'selected_models':len(selected),'selected_models_sha256':sha(OUT/'selected_models.json'),'protocol_sha256':ph,'time_unix':time.time()})
    print('R20_TRAINING_COMPLETE',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['lock','train']);args=ap.parse_args()
    {'lock':lock,'train':training}[args.stage]()
