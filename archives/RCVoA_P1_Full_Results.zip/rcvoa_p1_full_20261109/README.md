# P1 full label/exclusion sensitivity experiment

The fitted-model and numerical analyses are complete. Read `RESULTS_CN.md` for the full Chinese results and `REPRODUCE.md` for replay instructions. The manuscript remains the preserved 8+4-page version; no experimental result has been inserted into it.

The experiment retains 99 AK and 162 KA source components, refits the original model/calibration chain, and audits three external endpoint settings under two separate reference-decision contracts. Configuration denominators are 36/100/100. Results concern allocation existence, not clinical-input-only selector success.

Main results are in `results/`; the frozen-original-R companion is in `fixed_reference/results/`. Model, role, denominator, integer-allocation, bootstrap and version-preservation checks are recorded in `validation/`. The same-floor SCCIS/IEC rename is an exact equivalence check, not an independent robustness experiment.

`RCVoA_P1_Full_Results.zip` is built after this report and contains compact numerical replay inputs and training receipts; `validation/PACKAGE_AUDIT.json` and `validation/PORTABLE_REPLAY.json` confirm packaging and fresh numerical replay when present. Raw lesion-image pixels and network weights are retained separately. New large model artifacts are at `G:/RCVoA_P1_20261109_Artifacts/`, documented in `ARTIFACT_STORAGE.json`. The original manuscript delivery is backed up in `original_version/`.
