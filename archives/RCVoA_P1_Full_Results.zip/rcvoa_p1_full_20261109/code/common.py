"""Shared I/O and immutable scientific specification for the Week 2 extension."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, os, sys
import numpy as np

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
W1 = OUT
BACKBONES = ['efficientnet_b0','convnext_tiny','deit3_base_patch16_224']
COHORTS = ['MILK', 'MRA', 'HIBA', 'UQ', 'MCR-SL']
MODS = ['clinical', 'dermoscopic']
SEED = 2026101401

def now(): return datetime.now(timezone.utc).isoformat()
def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def read_json(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def read_csv(p):
    with Path(p).open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))
def write_json(p, obj):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp')
    temp.write_text(json.dumps(obj,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    temp.replace(p)
def write_csv(p, rows):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def save_npz(p, **arrays):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_name(p.name+'.tmp')
    with temp.open('wb') as f: np.savez_compressed(f,**arrays)
    temp.replace(p)
def nz(p):
    with np.load(p,allow_pickle=False) as z:return {k:z[k] for k in z.files}
def cases(): return read_csv(W1/'metadata/cases.csv')
def source():
    lab={r['id']:int(r['strict_cancer']) for r in read_csv(W1/'metadata/MILK_labels.csv')}
    rows=[{**r,'y':lab[r['id']], 'fold':int(r['source_fold'])} for r in cases() if r['cohort']=='MILK']
    assert len(rows)==4978 and len({r['id'] for r in rows})==4978
    return rows
def protocol_hash(): return sha(OUT/'protocol.json')

def freeze():
    plan=read_json(OUT/'protocol/PLAN.json')
    for name,h in plan['metadata_hashes'].items():assert sha(OUT/'metadata'/name)==h
    p=OUT/'protocol.json'
    obj=dict(plan_sha256=sha(OUT/'protocol/PLAN.json'),recipe='Original isolated FP32 source-only recipe on 4978 components',
        source_N=4978,backbones=BACKBONES,folds=5,seeds=3,modalities=MODS,
        original_training_code_sha256=sha(ROOT/'rcvoa_efficientnet_isolated_20261022/code/train_backbones.py'),
        code_hashes={n:sha(OUT/'code'/n) for n in ['common.py','train_backbones.py','fusion.py','fusion_guarded.py']})
    if p.exists():assert read_json(p)==obj
    else:write_json(p,obj)
    print('TRAINING_PROTOCOL_VERIFIED',sha(p),flush=True)
