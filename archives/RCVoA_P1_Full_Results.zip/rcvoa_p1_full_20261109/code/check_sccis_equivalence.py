"""Verify that a same-floor SCCIS -> IEC rename leaves every margin unchanged."""
from pathlib import Path
import importlib.util,json,numpy as np
from common import OUT,ROOT,write_json,read_json,nz,sha
from build_new_tables import cell_table
import reference_allocation as ref

def main():
    sp=importlib.util.spec_from_file_location('renamed_allocation',Path(ref.__file__))
    alt=importlib.util.module_from_spec(sp);sp.loader.exec_module(alt)
    alt.RATES={('IEC' if k=='SCCIS' else k):v for k,v in ref.RATES.items()}
    records=[]
    projects=[('original',ROOT/'rcvoa_label_sensitivity_20261109')]
    if (OUT/'inputs/tables.json').exists():projects.append(('expanded_source',OUT))
    if (OUT/'fixed_reference/inputs/tables.json').exists():projects.append(('expanded_source_fixed_R',OUT/'fixed_reference'))
    for cohort_project,p in projects:
        checks=0;sccis_tables=0
        for entry in read_json(p/'inputs/tables.json'):
            a=nz(p/'inputs/tables'/entry['file']);cells=a['cells'];b=(cells&4)>0;pair=(cells&2)>0;r=(cells&1)>0
            tab=cell_table(a['labels'],b,pair,r,entry['table_id'],entry['cap'])
            renamed={**tab,'cells':[['IEC' if row[0]=='SCCIS' else row[0],*row[1:]] for row in tab['cells']]}
            sccis_tables+=int(any(row[0]=='SCCIS' for row in tab['cells']))
            for budget in [10,15,20]:
                spec=dict(imaging_pct=budget,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=entry['cap'])
                assert ref.closed_form(tab,spec)==alt.closed_form(renamed,spec)
                checks+=1
        records.append(dict(project=cohort_project,tables=len(read_json(p/'inputs/tables.json')),tables_with_SCCIS=sccis_tables,exact_margin_identity_checks=checks))
    write_json(OUT/'validation/SCCIS_EQUIVALENCE.json',dict(status='PASS',projects=records,original_floor=90,renamed_floor=90,
        explanation='One-to-one label rename with unchanged stratum membership and floor: same integer deficits, pooled counts, transition supports and all six margins. Not an independent robustness experiment.',
        code_sha256=sha(__file__)))
    print(json.dumps(records),flush=True)
if __name__=='__main__':main()
