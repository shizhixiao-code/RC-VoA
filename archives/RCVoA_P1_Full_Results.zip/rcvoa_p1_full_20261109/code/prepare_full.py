"""Freeze the expanded MILK cohort before fitting; never modify prior projects."""
from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, json, shutil, collections

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parent
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):
    with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def js(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def main():
    for d in ['validation','protocol','evidence','metadata','cache','results','original_version','logs']:(OUT/d).mkdir(exist_ok=True)
    previous=ROOT/'rcvoa_label_sensitivity_20261109'
    preserved=json.loads((previous/'validation/PRESERVED_CURRENT_VERSION.json').read_text(encoding='utf-8'))
    for rel,h in preserved['files'].items():assert sha(Path(preserved['original_root'])/rel)==h,rel
    js(OUT/'validation/PRESERVED_CURRENT_VERSION.json',preserved)
    for name in ['RCVoA_Main_Integrated.pdf','RCVoA_Supplement_Integrated.pdf','RCVoA_P2_Completion.zip']:
        p=Path(preserved['original_root'])/'final'/name;q=OUT/'original_version'/name
        if not q.exists():shutil.copy2(p,q)
        assert sha(p)==sha(q)
    paths={
      'frozen_cases':ROOT/'rcvoa_fusion_week1_fp32/metadata/cases.csv',
      'frozen_labels':ROOT/'rcvoa_fusion_week1_fp32/metadata/MILK_labels.csv',
      'folds':ROOT/'data/splits/rcvoa_milk_outer_folds_v2.csv',
      'lesions':ROOT/'data/modeling_ready/skin/rcvoa_data_lock_v1/milk10k_lesions.csv',
      'official':ROOT/'output/rcvoa_operating_regions_20261009/provenance/milk10k_official_metadata_20261009.csv',
    }
    old=read(paths['frozen_cases']); oldsrc={r['id']:r for r in old if r['cohort']=='MILK'}
    oldlab={r['id']:r for r in read(paths['frozen_labels'])}
    images={r['lesion_id']:r for r in read(paths['lesions'])}
    raw=read(paths['official']); raw_by={}
    for r in raw:raw_by.setdefault(r['lesion_id'],set()).add((r['diagnosis_1'],r['diagnosis_3'],r['diagnosis_4']))
    assert all(len(v)==1 for v in raw_by.values())
    folds=read(paths['folds']);assert len(folds)==4983
    reps={}
    for r in sorted(folds,key=lambda x:x['lesion_id']):reps.setdefault(r['partition_group_id'],r)
    assert len(reps)==4978
    rows=[];labels=[];audit=[]
    for group,r in sorted(reps.items()):
        im=images[r['lesion_id']];d1,d3,d4=next(iter(raw_by[im['source_lesion_id']]))
        assert im['e0_eligible']=='True' and im['diagnosis_confirm_type']=='histopathology'
        y=int(im['strict_malignant']); added=group not in oldsrc
        if added:assert (d3,y) in [('Solar or actinic keratosis',0),('Keratoacanthoma',1)]
        else:
            assert oldsrc[group]['lesion_id']==r['lesion_id'] and int(oldsrc[group]['source_fold'])==int(r['outer_fold'])
            assert int(oldlab[group]['strict_cancer'])==y
        row=dict(cohort='MILK',id=group,lesion_id=r['lesion_id'],group=group,
                 group_type='duplicate_component_patient_id_unavailable',source_fold=int(r['outer_fold']),
                 **{m+'_image_path':im[m+'_image_path'] for m in ['clinical','dermoscopic']})
        rows.append(row)
        labels.append(dict(id=group,lesion_id=r['lesion_id'],strict_cancer=y,source_fold=int(r['outer_fold'])))
        subtype=1 if 'Melanoma' in d3 else 2 if d3=='Basal cell carcinoma' else 3 if d3 in ['Squamous cell carcinoma, Invasive','Keratoacanthoma'] else 4 if d3=='Squamous cell carcinoma in situ' else 0 if y==0 else -1
        audit.append(dict(id=group,lesion_id=r['lesion_id'],source_lesion_id=im['source_lesion_id'],fold=int(r['outer_fold']),added=added,diagnosis_1=d1,diagnosis_3=d3,diagnosis_4=d4,y=y,subtype=subtype,original_class=im['training_gt_class']))
        for mod in ['clinical','dermoscopic']:
            p=ROOT/im[mod+'_image_path'];assert p.is_file(),p
            if added:assert sha(p)==im[mod+'_image_sha256'],p
    assert sum(r['added'] for r in audit)==261
    assert collections.Counter(r['diagnosis_3'] for r in audit if r['added'])=={'Solar or actinic keratosis':99,'Keratoacanthoma':162}
    for r in old:
        if r['cohort']!='MILK':rows.append({k:v for k,v in r.items() if k!='row_index'})
    for i,r in enumerate(rows):r['row_index']=i
    assert len(rows)==14146
    for r in rows:
        for mod in ['clinical','dermoscopic']:assert (ROOT/r[mod+'_image_path']).is_file(),r
    write(OUT/'metadata/cases.csv',rows);write(OUT/'metadata/MILK_labels.csv',labels);write(OUT/'metadata/MILK_label_audit.csv',audit)
    fields=['id','lesion_id','group','source_fold','clinical_image_path','dermoscopic_image_path']
    assert all(all(str(next(x for x in rows if x['id']==i)[k])==str(r[k]) for k in fields) for i,r in oldsrc.items())
    protocol=dict(created_utc=datetime.now(timezone.utc).isoformat(),status='FROZEN_BEFORE_NEW_FITS',
      scope='Full P1 label/exclusion sensitivity; manuscript unchanged; exploratory retrospective rerun.',
      source_alternative=dict(N=4978,reference_N=4717,added_AK_negative=99,added_KA_positive=162,
        labels='Use original provider binary side: AK negative, KA positive. SCCIS remains its own subtype; no diagnostic re-adjudication.',
        folds='Previously frozen v2 duplicate-component folds retained for all 4978 components; existing 4717 folds and representatives identical.',
        other_exclusions='224 non-histopathology and 33 overlap candidates remain excluded; same five duplicate merges.'),
      steps=['Raw-field and duplicate/fold audit','Expanded-source refit with original isolated backbone/fusion/threshold recipe',
             'Expanded-source refit of the five original low-flag representation arms and original held-out threshold repair',
             'Reference and alternative endpoint definitions on all available newly fitted tables',
             'Formal SCCIS/IEC same-floor rename equivalence check','Independent integer allocation validation and preserved-version check'],
      fitting=dict(backbones=['efficientnet_b0','convnext_tiny','deit3_base_patch16_224'],outer_folds=5,seeds_per_fold=3,modalities=2,
        initialization='Same ImageNet weights for isolated backbones; original fixed warm-start checkpoint for the separate low-flag arm recipe.',
        calibration='Next MILK fold excluded from backbone fitting and validation; all external outcomes excluded from source fitting.',
        stopping='Original source validation and early-stopping rules; no target-dependent reruns or hyperparameter search.',
        lowflag='Keep original external group folds, arm recipes, warm-start checkpoints and target/reference definitions; add source AK/KA to source fits. No evaluation-fold labels enter selection/repair.'),
      endpoint_settings=['reference','AK_noncancer','endpoint_complete_case'],
      targets='Original reference targets; imaging 10/15/20% for source SP, 15/20% for primary/repaired. Each table is a configuration, not an independent patient.',
      equivalence='Changing SCCIS to IEC at the same 90% floor is a permutation/rename, not a new clinical target.',
      inputs={k:dict(path=p.relative_to(ROOT).as_posix(),sha256=sha(p)) for k,p in paths.items()},
      metadata_hashes={p.name:sha(p) for p in (OUT/'metadata').glob('*.csv')},
      preserved_files=len(preserved['files']))
    p=OUT/'protocol/PLAN.json'
    if p.exists():
        previous=json.loads(p.read_text(encoding='utf-8'));protocol['created_utc']=previous['created_utc'];assert protocol==previous
    else:js(p,protocol)
    js(OUT/'validation/COHORT_AUDIT.json',dict(status='PASS',N=4978,added=261,AK=99,KA=162,added_image_hash_checks=522,
       old_component_folds_and_labels_unchanged=4717,source_label_counts=dict(collections.Counter(r['y'] for r in audit)),
       folds={str(f):dict(collections.Counter(str(r['y']) for r in audit if r['fold']==f)) for f in range(5)},
       plan_sha256=sha(p),protected_files_unchanged=len(preserved['files'])))
    print('COHORT_FROZEN',len(rows),len(labels),sha(p),flush=True)

if __name__=='__main__':main()
