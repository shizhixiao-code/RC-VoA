"""Check that multiscale preprocessing is unchanged for all external images."""
import time
from common import OUT,ROOT,sha,read_json,write_json

def main():
    path=OUT/'lowflag/source_representation/MULTISCALE_INPUTS.json'
    while not path.exists():
        if read_json(OUT/'RUN_STATE.json').get('status')=='FAILED':raise RuntimeError('GPU pipeline failed')
        time.sleep(15)
    old=read_json(ROOT/'rcvoa_criteria_revision_20261023/experiments/lowflag20261023/source_representation/MULTISCALE_INPUTS.json')
    new=read_json(path)
    assert old['ids']==new['ids'] and old['files']==new['files']
    assert old['records']==new['records']
    for name,h in new['files'].items():assert sha(path.parent/name)==h,name
    write_json(OUT/'validation/MULTISCALE_CACHE_AUDIT.json',dict(status='PASS',external_cases=len(new['ids']),
        original_images=len(new['records']),original_cache_file_hashes_reproduced=new['files'],
        original_manifest_sha256=sha(ROOT/'rcvoa_criteria_revision_20261023/experiments/lowflag20261023/source_representation/MULTISCALE_INPUTS.json'),
        new_manifest_sha256=sha(path),code_sha256=sha(__file__)))
    print('MULTISCALE_CACHE_AUDIT_PASS',len(new['ids']),flush=True)

if __name__=='__main__':main()
