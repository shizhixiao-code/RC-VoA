"""Independent allocation validation and matched comparison with the preserved analysis."""
from pathlib import Path
from collections import defaultdict
import argparse,csv,json,time,platform
import numpy as np
import scipy
from common import OUT,ROOT,sha,read_json,read_csv,write_json,write_csv,nz
from reference_allocation import closed_form,allocation_milp,satisfies
from build_new_tables import LABELS,cell_table

SETTINGS=['reference','AK_noncancer','endpoint_complete_case']
MARGINS=['mandatory_rescue','subtype_rescue','total_rescue','FP_downgrade','flag_downgrade','imaging_capacity']
AK={'malignant- ak','actinic keratosis','ak'}
OLD=ROOT/'rcvoa_label_sensitivity_20261109'
def altered(a,setting):
    labels=a['labels'].copy();keep=np.ones(len(labels),bool)
    ak=np.array([str(s).lower() in AK for s in a['diagnosis']]);assert np.all(labels[ak]==7)
    if setting=='AK_noncancer':labels[ak]=6
    if setting=='endpoint_complete_case':keep=labels!=7
    return labels[keep],a['cells'][keep],a['group'][keep],a['id'][keep]
def stats(l,c,g):
    b=(c&4)>0;p=(c&2)>0;r=(c&1)>0
    return dict(N=len(l),groups=len(np.unique(g)),known=int((l<7).sum()),cancer=int((l<6).sum()),noncancer=int((l==6).sum()),excluded=int((l==7).sum()),
       C_minus=int(((l<6)&~b&p).sum()),B_plus=int(((l==6)&b&~p).sum()),excluded_downgrades=int(((l==7)&b&~p).sum()),
       baseline_flags=int(b.sum()),reference_flags=int(r.sum()),baseline_FP=int(((l==6)&b).sum()),reference_FP=int(((l==6)&r).sum()))
def main():
    global OUT
    ap=argparse.ArgumentParser();ap.add_argument('--reference-mode',choices=['pipeline','frozen'],default='pipeline');args=ap.parse_args()
    if args.reference_mode=='frozen':OUT=OUT/'fixed_reference'
    start=time.perf_counter();seal=read_json(OUT/'validation/NEW_TABLES_SEAL.json')
    def save_csv(name,items):write_csv(OUT/'results'/name,[dict(reference_mode=seal['reference_mode'],**r) for r in items])
    for rel,h in seal['portable_input_hashes'].items():assert sha(OUT/rel)==h,rel
    entries=read_json(OUT/'inputs/tables.json');rows=[];witnesses=[];checks=0
    for e in entries:
        a=nz(OUT/'inputs/tables'/e['file']);assert sha(OUT/'inputs/tables'/e['file'])==seal['portable_input_hashes']['inputs/tables/'+e['file']]
        for setting in SETTINGS:
            l,c,g,ids=altered(a,setting);b=(c&4)>0;p=(c&2)>0;r=(c&1)>0;tab=cell_table(l,b,p,r,e['table_id'],e['cap']);st=stats(l,c,g)
            for budget in ([10,15,20] if e['family']=='source_SP' else [15,20]):
                spec=dict(imaging_pct=budget,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=e['cap'])
                cf=closed_form(tab,spec);minimum,x=allocation_milp(tab,spec)
                assert minimum==cf['minimum_images'] and (minimum>=0)==cf['feasible'];checks+=1
                if x is not None:
                    assert satisfies(tab,np.array(x),spec)
                    witnesses.append(dict(table_id=e['table_id'],setting=setting,imaging_pct=budget,minimum_images=minimum,cells=tab['cells'],selected_by_cell=x))
                margins=cf.pop('margins');cf.pop('C_minus');cf.pop('B_plus')
                fail='feasible' if cf['feasible'] else 'support_failure' if min(margins[:5])<0 else 'capacity_only'
                rows.append({**{k:e[k] for k in ['table_id','family','cohort','mode','batch','cap']},'training':'expanded_source','setting':setting,'imaging_pct':budget,
                    **st,**cf,'required_images':cf['t_star']+cf['r'],'failure':fail,**dict(zip(MARGINS,map(int,margins)))})
    save_csv('table_results.csv',rows);write_json(OUT/'results/allocation_witnesses.json',witnesses)
    previous=read_csv(OLD/'results/table_results.csv')
    index=lambda x:(x['family'],x['cohort'],x['mode'],int(x['batch']),int(x['cap']),x['setting'],int(x['imaging_pct']))
    old={index(x):x for x in previous};assert len(old)==len(rows)==1524
    changes=[]
    for x in rows:
        p=old[index(x)];before=p['feasible']=='True';after=bool(x['feasible'])
        assert int(p['N'])==x['N'] and int(p['cancer'])==x['cancer']
        changes.append({**{k:x[k] for k in ['family','cohort','mode','batch','cap','setting','imaging_pct']},'original_feasible':before,'expanded_source_feasible':after,'changed':before!=after,
            **{f'original_{k}':int(p[k]) for k in ['C_minus','B_plus','t_star','reference_flags','baseline_flags','m','r','K',*MARGINS]},
            **{f'expanded_{k}':x[k] for k in ['C_minus','B_plus','t_star','reference_flags','baseline_flags','m','r','K',*MARGINS]}})
    save_csv('training_rule_changes.csv',changes)
    summary=[];stratified=[];folds=[];failure=[]
    for setting in SETTINGS:
        for family in ['source_SP','primary','repaired']:
            for budget in ([10,15,20] if family=='source_SP' else [15,20]):
                part=[x for x in rows if (x['setting'],x['family'],x['imaging_pct'])==(setting,family,budget)]
                delta=[x for x in changes if (x['setting'],x['family'],x['imaging_pct'])==(setting,family,budget)]
                assert len(part)==(36 if family=='source_SP' else 100)
                summary.append(dict(setting=setting,family=family,imaging_pct=budget,tables=len(part),original_feasible=sum(x['original_feasible'] for x in delta),
                    expanded_source_feasible=sum(x['feasible'] for x in part),newly_feasible=sum(not x['original_feasible'] and x['expanded_source_feasible'] for x in delta),
                    newly_infeasible=sum(x['original_feasible'] and not x['expanded_source_feasible'] for x in delta),support_failure=sum(x['failure']=='support_failure' for x in part),capacity_only=sum(x['failure']=='capacity_only' for x in part)))
                failure.append(dict(setting=setting,family=family,imaging_pct=budget,**{k:sum(x[k]<0 for x in part) for k in MARGINS}))
                groups=defaultdict(list)
                for x in part:groups[x['cohort'],x['mode'],x['cap']].append(x)
                for (co,mode,cap),xx in sorted(groups.items()):
                    stratified.append(dict(setting=setting,family=family,imaging_pct=budget,cohort=co,mode=mode,cap=cap,tables=len(xx),feasible=sum(x['feasible'] for x in xx)))
                    if family!='source_SP' and budget==20:
                        xx=sorted(xx,key=lambda x:x['batch']);folds.append(dict(setting=setting,family=family,cohort=co,mode=mode,cap=cap,passes=sum(x['feasible'] for x in xx),by_batch=';'.join(str(int(x['feasible'])) for x in xx)))
    save_csv('feasibility_summary.csv',summary);save_csv('system_cohort_summary.csv',stratified)
    save_csv('fold_stability.csv',folds);save_csv('failure_margins_nonexclusive.csv',failure)
    key=lambda x:(x['setting'],x['cohort'],x['mode'],x['batch'],x['cap'],x['imaging_pct'])
    p={key(x):x for x in rows if x['family']=='primary'};q={key(x):x for x in rows if x['family']=='repaired'}
    assert p.keys()==q.keys();assert all(q[k]['feasible']>=p[k]['feasible'] for k in p)
    preserved=read_json(OUT/'validation/PRESERVED_CURRENT_VERSION.json')
    original_root=Path(preserved['original_root']);protected_checked=0
    if original_root.exists():
        for rel,h in preserved['files'].items():assert sha(original_root/rel)==h,rel
        protected_checked=len(preserved['files'])
    audit=dict(status='PASS',reference_mode=seal['reference_mode'],tables=236,checks=checks,independent_allocation_milps=checks,integer_witnesses=len(witnesses),
        all_resource_and_cancer_denominators_matched_by_setting=True,paired_repair_monotonicity=True,protected_files_unchanged=protected_checked,
        original_project_available=original_root.exists(),
        elapsed_seconds=time.perf_counter()-start,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,code_sha256=sha(__file__))
    write_json(OUT/'validation/ANALYSIS_AUDIT.json',audit)
    print(json.dumps([x for x in summary if x['imaging_pct']==20],indent=2),flush=True)
if __name__=='__main__':main()
