"""Replay all 100 original cutoffs before any expanded-source evaluation."""
from build_new_tables import *

def main():
    old=ROOT/'rcvoa_threshold_transport_20261102'
    expected={(r['cohort'],r['mode'],int(r['batch']),int(r['frozen_flag_setting'])):r for r in read_csv(old/'analysis/rescue_operating_points_20261026/calibration_cutoffs.csv')}
    fits=read_json(old/'inputs/convnext_tiny.json');checks=0
    for co in ['MRA','UQ']:
        meta=cohort_meta(co);a=nz(old/f'inputs/convnext_tiny__{co}.npz');assert np.array_equal(a['id'],meta['id'])
        ref=a['p1']>=fits['S']['p1']
        for mode in MODES:
            frozen=nz(ORIG/f'{co}__{mode}__planning_decisions.npz');z=nz(ORIG/f'{co}__{mode}__actions.npz');fold=z['fold']
            for f in range(5):
                te=fold==f;cal=fold==(f+1)%5;de=~(te|cal)
                cp=z[f'clinical_{f}'];pp=z[f'paired_{f}'];cc=percentile(cp,cp[de]).mean(1);pc=percentile(pp,pp[de]).mean(1)
                for q in [.3,.5]:
                    t1=cap_threshold(cc[te],q);t12=cap_threshold(pc[de],q);b=cc>=t1
                    assert np.array_equal(b[te],frozen[f'{q}_base'][te])
                    assert np.array_equal(pc[te]>=t12,frozen[f'{q}_pair'][te])
                    cut,info=cutoff(meta['labels'][cal],b[cal],ref[cal],pc[cal],t12)
                    e=expected[co,mode,f+1,int(q*100)]
                    assert t1==float(e['t1']) and t12==float(e['original_t12']) and cut==float(e['repaired_t12'])
                    assert info['calibration_t_star']==int(e['calibration_t_star']);checks+=1
    assert checks==100
    write_json(OUT/'validation/REFERENCE_REPAIR_REPLAY.json',dict(status='PASS',cutoff_checks=checks,primary_decision_vectors_checked=200,all_original_calibration_cutoffs_reproduced_exactly=True,code_sha256=sha(__file__)))
    print('ORIGINAL_REPAIR_REPLAY_PASS',checks,flush=True)
if __name__=='__main__':main()
