"""Wait for the authorized fits, then run both prespecified reference contracts."""
from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys,time,traceback
O=Path(__file__).resolve().parents[1]
def state(stage,status,**more):
    p=O/'POSTPROCESS_STATE.json';t=p.with_suffix('.tmp')
    t.write_text(json.dumps(dict(stage=stage,status=status,utc=datetime.now(timezone.utc).isoformat(),**more),indent=2)+'\n',encoding='utf-8');t.replace(p)
def run(stage,script,args=()):
    state(stage,'RUNNING');start=time.perf_counter();print('STAGE',stage,flush=True)
    with (O/'logs'/f'{stage}.log').open('a',encoding='utf-8') as log:
        r=subprocess.run([sys.executable,str(O/'code'/script),*args],stdout=log,stderr=subprocess.STDOUT,cwd=O.parent)
    if r.returncode:raise RuntimeError(f'{stage} failed: exit {r.returncode}')
    state(stage,'COMPLETE',seconds=time.perf_counter()-start)
def main():
    state('model_fits','WAITING')
    while True:
        p=O/'RUN_STATE.json';r=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
        if r.get('status')=='FAILED':raise RuntimeError(r)
        if (O/'SOURCE_FITS_COMPLETE.json').exists() and r.get('stage')=='all_gpu_fits' and r.get('status')=='COMPLETE':break
        time.sleep(15)
    run('validate_fitting','validate_fitting.py')
    for mode in ['pipeline','frozen']:
        for label,script in [('tables','build_new_tables.py'),('analysis','run_full_analysis.py'),('bootstrap','bootstrap_repair.py')]:
            run(f'{mode}_{label}',script,['--reference-mode',mode])
    run('sccis_equivalence','check_sccis_equivalence.py')
    state('analysis_complete','COMPLETE');print('FULL_P1_ANALYSIS_COMPLETE',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        state('postprocessing','FAILED',error=str(e));traceback.print_exc();sys.exit(1)
