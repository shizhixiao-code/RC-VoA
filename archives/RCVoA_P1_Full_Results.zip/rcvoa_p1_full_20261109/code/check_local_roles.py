"""Independently check the copied local manifest against frozen external folds."""
from collections import defaultdict
from common import OUT,ROOT,read_csv,read_json,write_json,nz,sha
def main():
    cases=read_csv(OUT/'metadata/cases.csv');index={r['id']:r for r in cases};assert len(index)==len(cases)==14146
    p=OUT/'lowflag/source_representation/local_training_manifest.csv';rows=read_csv(p)
    old=ROOT/'rcvoa_criteria_revision_20261023/experiments/lowflag20261023/source_representation'
    assert sha(p)==sha(old/p.name)
    folds={}
    for co in ['MRA','UQ']:
        a=nz(old/f'{co}__headonly__planning_decisions.npz');folds[co]=dict(zip(a['id'],a['fold']))
    groups=defaultdict(lambda:defaultdict(set));ids=defaultdict(lambda:defaultdict(set));checked=0
    for r in rows:
        f=int(r['fold']);co=r['cohort'];role=r['role'];i=r['id'];assert i in index and index[i]['cohort']==co
        assert index[i]['group']==r['group'];assert role in ['train','validation']
        groups[f,co][role].add(r['group']);ids[f,co][role].add(i)
        if co in folds:
            actual=int(folds[co][i]);assert actual not in [f,(f+1)%5]
            if role=='validation':assert actual==(f+2)%5
            else:assert actual not in [f,(f+1)%5,(f+2)%5]
            checked+=1
    for key,x in groups.items():assert x['train'].isdisjoint(x['validation']),key
    for key,x in ids.items():assert x['train'].isdisjoint(x['validation']),key
    write_json(OUT/'validation/LOCAL_ROLE_AUDIT.json',dict(status='PASS',case_ids_unique=14146,manifest_rows=len(rows),
        evaluation_and_calibration_exclusion_row_checks=checked,cohort_fold_strata=len(groups),all_train_validation_groups_disjoint=True,
        manifest_unchanged_from_reference=True,manifest_sha256=sha(p),code_sha256=sha(__file__)))
    print('LOCAL_ROLES_PASS',len(rows),checked,flush=True)
if __name__=='__main__':main()
