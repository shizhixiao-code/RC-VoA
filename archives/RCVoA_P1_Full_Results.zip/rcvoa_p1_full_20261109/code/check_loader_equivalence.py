"""Compare original nonpersistent and retained persistent-worker image streams."""
import importlib.util,sys,hashlib
import torch
from common import OUT,ROOT,source,write_json,sha
import train_backbones as current

original_path=ROOT/'rcvoa_fusion_week2/code/train_backbones.py'
spec=importlib.util.spec_from_file_location('legacy_train_recipe',original_path)
legacy=importlib.util.module_from_spec(spec);sys.modules[spec.name]=legacy;spec.loader.exec_module(legacy)

def digest(loader):
    h=hashlib.sha256();count=0
    for x,y in loader:
        h.update(x.numpy().tobytes());h.update(y.numpy().tobytes());count+=len(y)
    return h.hexdigest(),count

def main():
    rows=source()[:64];seed=2026101401;records=[]
    for mod in ['clinical','dermoscopic']:
        old_streams={epoch:digest(legacy.loader(rows,mod,True,seed,epoch)) for epoch in range(1,4)}
        retained=None
        for epoch in range(1,4):
            old_hash,n=old_streams[epoch]
            if retained is None:retained=current.loader(rows,mod,True,seed,epoch)
            else:
                retained.dataset.epoch.value=epoch;retained.generator.manual_seed(seed+10000*epoch)
                torch.empty((),dtype=torch.int64).random_(generator=retained.generator)
            new_hash,m=digest(retained)
            assert n==m==64 and old_hash==new_hash,(mod,epoch)
            records.append(dict(modality=mod,epoch=epoch,cases=64,tensor_and_label_stream_sha256=new_hash))
        del retained
    write_json(OUT/'validation/LOADER_EQUIVALENCE.json',dict(status='PASS',original_code_sha256=sha(original_path),
        current_code_sha256=sha(current.__file__),records=records,
        scope='Exact equality of ordered augmented float32 input tensors and labels on64sourcecases, bothmodalities and3epochs;2originalnonpersistent vs4retainedpersistentworkers.'))
    print('LOADER_EQUIVALENCE_PASS',len(records),flush=True)

if __name__=='__main__':main()
