"""Compact, read-only run status without dumping large manifests."""
from pathlib import Path
import json
from datetime import datetime,timezone

O=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None
def main():
    b=list((O/'backbones').glob('*/result.json'))
    low=list((O/'lowflag/source_representation').glob('*/COMPLETE.json'))
    r={'utc':datetime.now(timezone.utc).isoformat(),'gpu_state':read(O/'RUN_STATE.json'),
       'postprocessing':read(O/'POSTPROCESS_STATE.json'),
       'backbone_jobs':len(b),'backbone_expected':90,
       'lowflag_initializations':len(list((O/'lowflag/source_initialization/training').glob('*/result.json'))),
       'lowflag_source_adapters':sum(not p.parent.name.startswith(('local','multiscale')) for p in low),
       'lowflag_local':sum(p.parent.name.startswith('local') for p in low),
       'multiscale_exports':sum(p.parent.name.startswith('multiscale') for p in low),
       'fusion_outer':len(list((O/'fusion_guarded').glob('*/*/complete.json'))),
       'multiscale_cache_checked':(O/'validation/MULTISCALE_CACHE_AUDIT.json').exists(),
       'interim_audit':(O/'interim_fixed_reference/INTERIM_AUDIT.json').exists(),
       'interim_error':read(O/'interim_fixed_reference/INTERIM_ERROR.json')}
    progress=read(O/'training_progress.json')
    if r['gpu_state']['stage']=='isolated_backbones':r['backbone_progress']=progress
    else:
        p=O/'logs'/f"{r['gpu_state']['stage']}.log"
        if p.exists():r['latest_stage_log']=p.read_text(encoding='utf-8',errors='replace').splitlines()[-1:]
    print(json.dumps(r,ensure_ascii=False))
if __name__=='__main__':main()
