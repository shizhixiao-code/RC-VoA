"""Audit one fully completed source architecture; never label it the full P1 result."""
import argparse
import numpy as np
from common import OUT,ROOT,BACKBONES,read_json,read_csv,nz,write_json,write_csv,sha
from build_new_tables import cohort_meta,source_thresholds,cell_table
from run_full_analysis import SETTINGS,altered,MARGINS
from reference_allocation import closed_form,allocation_milp,satisfies

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arch',required=True,choices=BACKBONES);args=ap.parse_args();arch=args.arch
    complete=read_json(OUT/f'predictions/{arch}__COMPLETE.json')
    assert complete['source_N']==4978 and complete['source_outer_pipelines']==5
    for item in complete['files']:assert sha(OUT/'predictions'/item['file'])==item['sha256']
    cut=source_thresholds(arch)
    oldroot=ROOT/'rcvoa_label_sensitivity_20261109'
    entries=[e for e in read_json(oldroot/'inputs/tables.json') if e['family']=='source_SP' and e['mode'].startswith(arch+'_')]
    assert len(entries)==12
    previous=read_csv(oldroot/'results/table_results.csv')
    old={(r['cohort'],r['mode'],r['setting'],int(r['imaging_pct'])):r for r in previous if r['family']=='source_SP' and r['mode'].startswith(arch+'_')}
    rows=[];witnesses=0
    for e in entries:
        co=e['cohort'];level=e['mode'].rsplit('_',1)[1];meta=cohort_meta(co)
        a=nz(OUT/f'predictions/{arch}__{co}.npz');before=nz(oldroot/'inputs/tables'/e['file'])
        assert np.array_equal(a['id'],meta['id']) and np.array_equal(before['id'],meta['id'])
        for key in ['p1',f'p12_{level}']:assert np.isfinite(a[key]).all() and np.all((a[key]>=0)&(a[key]<=1))
        b=a['p1']>=cut['S']['p1'];p=a[f'p12_{level}']>=cut['P'][f'p12_{level}']
        for mode in ['pipeline','frozen']:
            r=b if mode=='pipeline' else (before['cells']&1)>0
            data={**meta,'cells':4*b.astype(int)+2*p.astype(int)+r.astype(int)}
            for setting in SETTINGS:
                labels,cells,groups,ids=altered(data,setting)
                tab=cell_table(labels,(cells&4)>0,(cells&2)>0,(cells&1)>0,e['table_id'],100)
                for budget in [10,15,20]:
                    s=dict(imaging_pct=budget,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=100)
                    cf=closed_form(tab,s);minimum,x=allocation_milp(tab,s)
                    assert minimum==cf['minimum_images'] and (minimum>=0)==cf['feasible']
                    if x is not None:assert satisfies(tab,np.asarray(x),s);witnesses+=1
                    prior=old[co,e['mode'],setting,budget]
                    assert len(labels)==int(prior['N']) and int((labels<6).sum())==int(prior['cancer'])
                    margins=cf.pop('margins')
                    rows.append(dict(architecture=arch,reference_mode=mode,cohort=co,mode=e['mode'],setting=setting,imaging_pct=budget,
                        original_feasible=prior['feasible']=='True',**cf,**dict(zip(MARGINS,margins))))
    dest=OUT/'interim_source_SP'/arch
    write_csv(dest/'results/table_results.csv',rows);summary=[]
    for mode in ['pipeline','frozen']:
        for setting in SETTINGS:
            for budget in [10,15,20]:
                part=[r for r in rows if (r['reference_mode'],r['setting'],r['imaging_pct'])==(mode,setting,budget)]
                assert len(part)==12
                summary.append(dict(architecture=arch,reference_mode=mode,setting=setting,imaging_pct=budget,configurations=12,
                    original_feasible=sum(r['original_feasible'] for r in part),expanded_source_feasible=sum(r['feasible'] for r in part),
                    newly_feasible=sum(not r['original_feasible'] and r['feasible'] for r in part),
                    newly_infeasible=sum(r['original_feasible'] and not r['feasible'] for r in part)))
    write_csv(dest/'results/feasibility_summary.csv',summary)
    write_json(dest/'INTERIM_AUDIT.json',dict(status='PASS',architecture=arch,configurations_per_reference_contract=12,
        independent_milps=len(rows),validated_witnesses=witnesses,source_N=4978,
        scope='One completed architecture only; other architectures and full P1 results are not implied.',
        source_thresholds_sha256=sha(OUT/f'predictions/{arch}__thresholds.json'),code_sha256=sha(__file__)))
    print([r for r in summary if r['imaging_pct']==20],flush=True)

if __name__=='__main__':main()
