"""Replay the two fixed original source-initialization jobs on expanded MILK."""
from pathlib import Path
import sys,importlib.util,csv,json,hashlib,inspect
O=Path(__file__).resolve().parents[1];ROOT=O.parent
sys.path.insert(0,str(ROOT/'scripts'))
p=ROOT/'scripts/train_rcvoa_r20_model_pipeline_20260909.py'
sp=importlib.util.spec_from_file_location('original_source_initializer',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
m.OUT=O/'lowflag/source_initialization';m.OUT.mkdir(parents=True,exist_ok=True)
m.DESIGN={**m.DESIGN,'version':'P1_expanded_source_initializer_20261109','validation_folds':[1],'learning_rates':[.00005],
          'evidence_role':'Expanded-source counterpart of the two fixed member1 warm-start checkpoints; no LR/model search beyond original source checkpoint selection.',
          'ensemble':'Not constructed here: only the two member1 modality checkpoints used as low-flag initializers are refitted.',
          'calibration':'Not fitted in this stage; source fold0 remains unused.',
          'source_oof_diagnostic':'Not run in this initialization stage.',
          'external_cohorts':[],
          'scope_limits':'Initialization only; subsequent low-flag source/local fits and held-out audit are separate recorded stages.'}
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def milk_rows():
    with (O/'metadata/cases.csv').open(encoding='utf-8') as f:rr=[r for r in csv.DictReader(f) if r['cohort']=='MILK']
    with (O/'metadata/MILK_label_audit.csv').open(encoding='utf-8') as f:lab={r['id']:r for r in csv.DictReader(f)}
    rows=[dict(r,partition_group_id=r['id'],outer_fold=r['source_fold'],strict_cancer=lab[r['id']]['y']) for r in rr]
    assert len(rows)==4978;return rows
m.milk_rows=milk_rows
lock=dict(design=m.DESIGN,original_training_script_sha256=sha(p),driver_sha256=sha(__file__),
          plan_sha256=sha(O/'protocol/SOURCE_INITIALIZATION_ADDENDUM.json'),
          cases_sha256=sha(O/'metadata/cases.csv'),labels_sha256=sha(O/'metadata/MILK_label_audit.csv'))
def verify():
    q=m.OUT/'protocol_lock.json'
    if q.exists():assert json.loads(q.read_text(encoding='utf-8'))==lock
    else:q.write_text(json.dumps(lock,indent=2)+'\n',encoding='utf-8')
m.verify=verify
# Only change the progress denominator, preserving the full original training function.
text=inspect.getsource(m.training).replace("'total_jobs':16","'total_jobs':2")
exec(compile(text,str(p)+'::expanded_source', 'exec'),m.__dict__)

if __name__=='__main__':m.training()
