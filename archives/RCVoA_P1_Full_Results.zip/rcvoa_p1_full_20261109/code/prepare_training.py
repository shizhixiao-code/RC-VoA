"""Copy and adapt the original isolated recipe into this versioned experiment."""
from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;O=P.parent;R=O.parent
S=R/'rcvoa_efficientnet_isolated_20261022/code'
def save(name,text):
    p=P/name
    if p.exists():assert p.read_text(encoding='utf-8')==text,name
    else:p.write_text(text,encoding='utf-8')

common=(S/'common.py').read_text(encoding='utf-8').split('\nDESIGN =')[0]
common=common.replace("W1 = ROOT / 'rcvoa_fusion_week1_fp32'",'W1 = OUT')
common=common.replace("BACKBONES = ['efficientnet_b0']","BACKBONES = ['efficientnet_b0','convnext_tiny','deit3_base_patch16_224']")
common=common.replace('4717','4978')
common+='''
def freeze():
    plan=read_json(OUT/'protocol/PLAN.json')
    for name,h in plan['metadata_hashes'].items():assert sha(OUT/'metadata'/name)==h
    p=OUT/'protocol.json'
    obj=dict(plan_sha256=sha(OUT/'protocol/PLAN.json'),recipe='Original isolated FP32 source-only recipe on 4978 components',
        source_N=4978,backbones=BACKBONES,folds=5,seeds=3,modalities=MODS,
        original_training_code_sha256=sha(ROOT/'rcvoa_efficientnet_isolated_20261022/code/train_backbones.py'),
        code_hashes={n:sha(OUT/'code'/n) for n in ['common.py','train_backbones.py','fusion.py','fusion_guarded.py']})
    if p.exists():assert read_json(p)==obj
    else:write_json(p,obj)
    print('TRAINING_PROTOCOL_VERIFIED',sha(p),flush=True)
'''
save('common.py',common)
t=(S/'train_backbones.py').read_text(encoding='utf-8').replace('==4717','==4978')
t=t.replace("choices=['efficientnet_b0','all']","choices=BACKBONES+['all']")
t=t.replace("architectures=['efficientnet_b0'] if args.arch=='all' else [args.arch]","architectures=BACKBONES if args.arch=='all' else [args.arch]")
t=t.replace("'expected_jobs':30,'complete':len(completed)==30","'expected_jobs':90,'complete':len(completed)==90")
t=t.replace("save_npz(p,row_index=idx,embedding=f,two_class_logits=z,logit=z[:,1]-z[:,0])", "save_npz(p,row_index=idx,two_class_logits=z,logit=z[:,1]-z[:,0],**({'embedding':f} if seed==1 else {}))")
save('train_backbones.py',t)
for n in ['fusion.py','fusion_guarded.py']:save(n,(S/n).read_text(encoding='utf-8'))
print('TRAINING_CODE_PREPARED',flush=True)
