"""Prevent automatic idle sleep while the authorized experiment/replay is active."""
from pathlib import Path
import ctypes,json,time,os,argparse
O=Path(__file__).resolve().parents[1]
CONTINUOUS=0x80000000;SYSTEM_REQUIRED=0x00000001
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--through-delivery',action='store_true');args=parser.parse_args()
    assert os.name=='nt'
    api=ctypes.windll.kernel32.SetThreadExecutionState
    if not api(CONTINUOUS|SYSTEM_REQUIRED):raise OSError('SetThreadExecutionState failed')
    print('TEMPORARY_SYSTEM_WAKE_REQUEST',os.getpid(),flush=True)
    try:
        while True:
            p=O/('DELIVERY_STATE.json' if args.through_delivery else 'RUN_STATE.json')
            if p.exists():
                try:r=json.loads(p.read_text(encoding='utf-8'))
                except (json.JSONDecodeError,OSError):r={}
                final='delivery' if args.through_delivery else 'all_gpu_fits'
                if r.get('status')=='FAILED' or (r.get('stage')==final and r.get('status')=='COMPLETE'):break
            time.sleep(30)
    finally:
        api(CONTINUOUS);print('TEMPORARY_WAKE_REQUEST_RELEASED',flush=True)
if __name__=='__main__':main()
