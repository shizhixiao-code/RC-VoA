"""Package validated numerical results and replay inputs without image/weight files."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
from common import OUT,ROOT,read_json,write_json,sha

def main():
    assert read_json(OUT/'POSTPROCESS_STATE.json')['stage']=='analysis_complete'
    assert read_json(OUT/'validation/REPORT_AUDIT.json')['status']=='PASS'
    files={}
    def add(p):
        assert p.is_file(),p
        key=p.relative_to(ROOT).as_posix()
        if '__pycache__' not in p.parts:files[key]=p
    def tree(p,patterns=None):
        for q in p.rglob('*'):
            if q.is_file() and (patterns is None or q.suffix in patterns):add(q)
    for name in ['code','protocol','evidence','metadata','validation','results','inputs','predictions']:
        tree(OUT/name)
    for name in ['results','inputs','validation']:tree(OUT/'fixed_reference'/name)
    tree(OUT/'lowflag/code',{'.py'})
    tree(OUT/'lowflag/protocol')
    add(OUT/'lowflag/ORIGINAL_RECIPE_INPUTS.json')
    for p in OUT.glob('*.json'):
        if p.name not in ['training_progress.json','DELIVERY_STATE.json']:add(p)
    for name in ['RESULTS_CN.md','REPRODUCE.md','README.md']:add(OUT/name)
    for name in ['RCVoA_Main_Integrated.pdf','RCVoA_Supplement_Integrated.pdf']:add(OUT/'original_version'/name)
    for p in (OUT/'backbones').glob('*/*'):
        if p.is_file() and p.suffix in ['.json','.csv']:add(p)
    tree(OUT/'fusion_guarded',{'.json','.csv'})
    for root in [OUT/'lowflag/source_initialization',OUT/'lowflag/source_representation']:
        for p in root.rglob('*'):
            if p.is_file() and p.suffix in ['.json','.csv'] and p.name!='MULTISCALE_INPUTS.json':add(p)
    for p in (OUT/'cache').glob('*.json'):add(p)
    old=ROOT/'rcvoa_label_sensitivity_20261109'
    tree(old/'inputs');tree(old/'results',{'.csv'})
    for rel in read_json(OUT/'validation/ORIGINAL_TRAINING_DEPENDENCIES.json'):
        p=ROOT/rel
        if p.suffix=='.py':add(p)
    # An existing archive/replay receipt cannot be a dependency of itself.
    files={k:p for k,p in files.items() if p.name not in ['PACKAGE_AUDIT.json','PORTABLE_REPLAY.json']}
    manifest={k:sha(p) for k,p in sorted(files.items())}
    target=OUT/'RCVoA_P1_Full_Results.zip'
    with ZipFile(target,'w',ZIP_DEFLATED,compresslevel=6) as z:
        for k,p in sorted(files.items()):z.write(p,k)
        z.writestr('ARCHIVE_MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
    with ZipFile(target) as z:
        assert z.testzip() is None
        for k,h in manifest.items():assert hashlib.sha256(z.read(k)).hexdigest()==h,k
    write_json(OUT/'validation/PACKAGE_AUDIT.json',dict(status='PASS',file=target.name,sha256=sha(target),
        bytes=target.stat().st_size,files=len(files),raw_dataset_image_files_included=False,network_weights_included=False,
        preserved_manuscript_pdfs_with_their_figures_included=True,
        portable_scope='Replay allocation counts, integer checks, paired conditional bootstrap and label-renaming equivalence from sealed decision tables. Training requires the separately retained data and weights.'))
    print('PACKAGE_COMPLETE',target.stat().st_size,len(files),flush=True)

if __name__=='__main__':main()
