"""Source-only frozen-backbone fusion fits. External labels are never opened."""
import os
for name in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ.setdefault(name,'2')
import argparse, time
import numpy as np
from scipy.special import expit, logit
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.model_selection import StratifiedKFold
from threadpoolctl import threadpool_limits
import torch
from torch import nn
from common import *

torch.set_num_threads(2)

def fit_logistic(x,y,C=1.):
    x=np.asarray(x,dtype=np.float64);y=np.asarray(y,dtype=np.int64)
    if x.ndim==1:x=x[:,None]
    mu=x.mean(0);sd=x.std(0);sd[sd<1e-10]=1.
    if len(np.unique(y))<2:
        return {'mu':mu.tolist(),'sd':sd.tolist(),'coef':[0.]*x.shape[1],
                'intercept':float(logit((y.sum()+.5)/(len(y)+1))),'fallback':'one-class Jeffreys prior','N':len(y),'positives':int(y.sum())}
    m=LogisticRegression(C=C,solver='lbfgs',max_iter=2000,tol=1e-10)
    m.fit((x-mu)/sd,y)
    assert int(m.n_iter_.max())<2000,'Logistic solver failed to converge'
    return {'mu':mu.tolist(),'sd':sd.tolist(),'coef':m.coef_[0].tolist(),'intercept':float(m.intercept_[0]),'N':len(y),'positives':int(y.sum()),'iterations':int(m.n_iter_.max()),'fallback':None}

def linear(x,fit):
    x=np.asarray(x,dtype=np.float64)
    if x.ndim==1:x=x[:,None]
    return ((x-fit['mu'])/fit['sd'])@np.array(fit['coef'])+fit['intercept']

def sensitivity_threshold(p,y):
    z=np.sort(np.asarray(p)[np.asarray(y)==1])[::-1]
    assert len(z)>0
    return float(z[int(np.ceil(.90*len(z)))-1])

def load_view(arch,outer):
    rr=cases();cal=(outer+1)%5
    rr=[r for r in rr if r['cohort']!='MILK' or int(r['source_fold']) in [outer,cal]]
    idx=np.array([int(r['row_index']) for r in rr]);index={int(j):i for i,j in enumerate(idx)}
    data={'row_index':idx,'id':np.array([r['id'] for r in rr]),'cohort':np.array([r['cohort'] for r in rr]),
          'fold':np.array([int(r['source_fold']) for r in rr]),'group':np.array([r['group'] for r in rr])}
    provenance=[]
    for mi,mod in enumerate(MODS,1):
        zs=[];ps=[]
        for seed in [1,2,3]:
            chunks=[]
            for co in COHORTS:
                p=OUT/f'backbones/{arch}__outer{outer}__seed{seed}__{mod}/{co}.npz'
                if not p.is_file():raise FileNotFoundError(p)
                a=nz(p);take=np.array([int(j) in index for j in a['row_index']])
                chunks.append({k:v[take] for k,v in a.items()})
                provenance.append({'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':sha(p)})
            rows=np.concatenate([a['row_index'] for a in chunks]);lookup={int(j):i for i,j in enumerate(rows)}
            order=np.array([lookup[int(j)] for j in idx]);z=np.concatenate([a['logit'] for a in chunks])[order].astype(float);zs.append(z)
            if seed==1:data[f'f{mi}']=np.concatenate([a['embedding'] for a in chunks])[order]
            ps.append(expit(z))
        zs=np.stack(zs,1);ps=np.stack(ps,1)
        data[f'z{mi}']=zs.mean(1)
        data[f'var{mi}']=ps.var(1,ddof=0)
    return data,provenance

def subset(a,ix):return {k:v[ix] for k,v in a.items()}

def modality_maps(a,y):
    if 'existing_p1' in a:return None
    return {f'm{j}':fit_logistic(a[f'z{j}'],y) for j in [1,2]}

def modality_p(a,maps):
    if maps is None:return a['existing_p1'],a['existing_p2']
    return tuple(expit(linear(a[f'z{j}'],maps[f'm{j}'])) for j in [1,2])

def gate_features(a):
    # Stable equivalent of normalized inverse variances; floor fixed before fitting.
    v1=np.maximum(a['var1'],1e-6);v2=np.maximum(a['var2'],1e-6)
    w1=v2/(v1+v2);w2=v1/(v1+v2)
    assert np.allclose(w1+w2,1)
    return np.c_[w1*a['z1'],w2*a['z2']]

def pca_fit(f):
    n=min(32,len(f)-1,f.shape[1]);m=PCA(n_components=n,svd_solver='randomized',random_state=SEED,iterated_power=5)
    scores=m.fit_transform(f.astype(np.float64));scale=scores.std(0);scale[scale<1e-8]=1.
    return dict(mean=m.mean_,components=m.components_,scale=scale)
def pca_apply(f,p):return ((f.astype(float)-p['mean'])@p['components'].T/p['scale']).astype(np.float32)

class ResidualFusion(nn.Module):
    def __init__(self,n1=32,n2=32):
        super().__init__()
        self.clinical=nn.Linear(n1,32);self.dermoscopy=nn.Linear(n2,32)
        self.attention=nn.MultiheadAttention(32,4,dropout=.2,batch_first=True)
        self.gate=nn.Sequential(nn.Linear(64,16),nn.GELU(),nn.Linear(16,1),nn.Sigmoid())
        self.update=nn.Sequential(nn.Linear(128,64),nn.GELU(),nn.Dropout(.2),nn.Linear(64,1))
        nn.init.zeros_(self.update[-1].weight);nn.init.zeros_(self.update[-1].bias)
    def forward(self,f1,f2,z1):
        c=self.clinical(f1);d=self.dermoscopy(f2);tokens=torch.stack([c,d],1)
        att,_=self.attention(c[:,None,:],tokens,tokens,need_weights=False)
        delta=self.update(torch.cat([c,d,d-c,att[:,0]],1)).squeeze(1)
        gate=self.gate(torch.cat([c,d],1)).squeeze(1)
        return z1+gate*delta

def fit_residual(a,y,maps,seed):
    torch.manual_seed(seed);np.random.seed(seed%(2**32));torch.use_deterministic_algorithms(True)
    pp=[pca_fit(a[f'f{j}']) for j in [1,2]]
    x=[torch.from_numpy(pca_apply(a[f'f{j}'],pp[j-1])) for j in [1,2]]
    p1,_=modality_p(a,maps);base=torch.tensor(logit(np.clip(p1,1e-6,1-1e-6)),dtype=torch.float32)
    yy=torch.tensor(y,dtype=torch.float32);m=ResidualFusion(x[0].shape[1],x[1].shape[1]);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.001)
    g=torch.Generator().manual_seed(seed);history=[]
    for epoch in range(100):
        m.train();order=torch.randperm(len(y),generator=g);loss_sum=0.
        for k in range(0,len(y),128):
            ix=order[k:k+128];opt.zero_grad(set_to_none=True)
            z=m(x[0][ix],x[1][ix],base[ix]);loss=nn.functional.binary_cross_entropy_with_logits(z,yy[ix])
            assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5.,error_if_nonfinite=True);opt.step()
            loss_sum+=float(loss.detach())*len(ix)
        history.append(loss_sum/len(y))
    m.eval();return m,pp,history

@torch.no_grad()
def residual_raw(a,m,maps,pp):
    p1,_=modality_p(a,maps);zz=[]
    for k in range(0,len(p1),512):
        f1=torch.from_numpy(pca_apply(a['f1'][k:k+512],pp[0]));f2=torch.from_numpy(pca_apply(a['f2'][k:k+512],pp[1]));base=torch.tensor(logit(np.clip(p1[k:k+512],1e-6,1-1e-6)),dtype=torch.float32)
        zz.append(m(f1,f2,base).numpy().astype(np.float64))
    return np.concatenate(zz)

def fit_outer(arch,outer):
    dr=OUT/f'fusion/{arch}/outer{outer}';dr.mkdir(parents=True,exist_ok=True)
    receipt=dr/'complete.json';code_hash=sha(__file__)
    if receipt.exists():
        r=read_json(receipt);assert r['code_sha256']==code_hash and r['protocol_sha256']==protocol_hash()
        for q in r['outputs']:assert sha(OUT/q['path'])==q['sha256']
        print('FUSION_REUSED',arch,outer,flush=True);return
    a,provenance=load_view(arch,outer);src=source();labels={r['id']:r['y'] for r in src}
    cal=(a['cohort']=='MILK')&(a['fold']==(outer+1)%5);ca=subset(a,cal);y=np.array([labels[k] for k in ca['id']]);n=len(y)
    skf=StratifiedKFold(5,shuffle=True,random_state=SEED+outer)
    raw_l2=np.full(n,np.nan);raw_l3=np.full(n,np.nan);oof1=np.full(n,np.nan);oof2=np.full(n,np.nan);splits=[]
    print('FUSION_START',arch,outer,'source_head_components',n,flush=True)
    for inner,(tr,va) in enumerate(skf.split(np.zeros(n),y)):
        train=subset(ca,tr);valid=subset(ca,va);maps=modality_maps(train,y[tr]);p1,p2=modality_p(valid,maps)
        oof1[va]=p1;oof2[va]=p2
        l2=fit_logistic(gate_features(train),y[tr]);raw_l2[va]=linear(gate_features(valid),l2)
        model,pp,history=fit_residual(train,y[tr],maps,SEED+10000*outer+inner)
        raw_l3[va]=residual_raw(valid,model,maps,pp)
        splits.append(dict(inner_fold=inner,train_N=len(tr),validation_N=len(va),train_ids=ca['id'][tr].tolist(),validation_ids=ca['id'][va].tolist(),last_training_loss=history[-1]))
        print('FUSION_INNER',arch,outer,inner,flush=True)
    assert all(np.isfinite(v).all() for v in [raw_l2,raw_l3,oof1,oof2])
    maps=modality_maps(ca,y);l2=fit_logistic(gate_features(ca),y)
    l2cal=fit_logistic(raw_l2,y);l3cal=fit_logistic(raw_l3,y)
    model,pp,history=fit_residual(ca,y,maps,SEED+10000*outer+99)
    torch.save(model.state_dict(),dr/'L3.pt')
    save_npz(dr/'L3_projection.npz',**{f'm{j}_{k}':v for j,p in enumerate(pp,1) for k,v in p.items()})
    fits={'modality':maps,'L2':l2,'L2_Platt':l2cal,'L3_Platt':l3cal,'L3_base':'logit(clip(calibrated clinical probability,1e-6,1-1e-6))','head_N':n,
          'thresholds':{'p1':sensitivity_threshold(oof1,y),'L1':sensitivity_threshold((oof1+oof2)/2,y),
             'L2':sensitivity_threshold(expit(linear(raw_l2,l2cal)),y),'L3':sensitivity_threshold(expit(linear(raw_l3,l3cal)),y)}}
    write_json(dr/'fits.json',fits);write_json(dr/'inner_splits.json',splits);write_json(dr/'input_provenance.json',provenance)
    save_npz(dr/'source_head_oof.npz',id=ca['id'],y=y,p1=oof1,p2=oof2,raw_L2=raw_l2,raw_L3=raw_l3,
             p12_L1=(oof1+oof2)/2,p12_L2=expit(linear(raw_l2,l2cal)),p12_L3=expit(linear(raw_l3,l3cal)))
    write_csv(dr/'L3_training_curve.csv',[dict(epoch=i+1,loss=v) for i,v in enumerate(history)])
    outputs=[]
    for co in COHORTS:
        use=a['cohort']==co
        if co=='MILK':use&=a['fold']==outer
        aa=subset(a,use);p1,p2=modality_p(aa,maps);r2=linear(gate_features(aa),l2);r3=residual_raw(aa,model,maps,pp)
        p=dr/f'{co}.npz';save_npz(p,id=aa['id'],group=aa['group'],row_index=aa['row_index'],fold=aa['fold'],
            p1=p1,p2=p2,p12_L1=(p1+p2)/2,p12_L2=expit(linear(r2,l2cal)),p12_L3=expit(linear(r3,l3cal)),
            raw_L2=r2,raw_L3=r3,clinical_variance=aa['var1'],dermoscopic_variance=aa['var2'])
        outputs.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'sha256':sha(p)})
    for name in ['fits.json','L3.pt','L3_projection.npz','source_head_oof.npz','inner_splits.json','input_provenance.json','L3_training_curve.csv']:
        p=dr/name;outputs.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'sha256':sha(p)})
    write_json(receipt,dict(complete=True,arch=arch,outer=outer,created_utc=now(),code_sha256=code_hash,protocol_sha256=protocol_hash(),
                           outer_fit_overlap=0,external_outcomes_read=0,outputs=outputs))
    print('FUSION_COMPLETE',arch,outer,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arch',default='all',choices=BACKBONES+['all']);ap.add_argument('--outer',type=int);args=ap.parse_args()
    freeze()
    with threadpool_limits(limits=2):
      for arch in (BACKBONES if args.arch=='all' else [args.arch]):
       for outer in (range(5) if args.outer is None else [args.outer]):fit_outer(arch,outer)

if __name__=='__main__':main()
