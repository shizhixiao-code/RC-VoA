"""Stage original low-flag recipes with expanded source labels and isolated outputs."""
from pathlib import Path
import json,shutil,hashlib
P=Path(__file__).resolve().parent;O=P.parent;R=O.parent
OLD=R/'rcvoa_criteria_revision_20261023';L=O/'lowflag';C=L/'code';D=L/'source_representation'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,text):
    p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():assert p.read_text(encoding='utf-8')==text,p
    else:p.write_text(text,encoding='utf-8')
def main():
    for d in [C,D,L/'protocol',L/'logs']:d.mkdir(parents=True,exist_ok=True)
    record={}
    for n in ['SOURCE_REPRESENTATION_PLAN.md','SOURCE_WARM_START_PLAN.md','LOCAL_REPRESENTATION_PLAN.md','MULTISCALE_INPUT_PLAN.md']:
        p=OLD/'protocol'/n;shutil.copy2(p,L/'protocol'/n);record[str(p.relative_to(R))]=sha(p)
    for name in ['train_source_subtypes.py','train_source_warm.py','train_local_subtypes.py','prepare_scale_crops.py','export_scale_scores.py']:
        p=OLD/'code'/name;t=p.read_text(encoding='utf-8');record[str(p.relative_to(R))]=sha(p)
        t=t.replace("W=R.parent/'rcvoa_fusion_week1_fp32'",'W=R.parent')
        t=t.replace("D=R/'experiments/lowflag20261023/source_representation'","D=R/'source_representation'")
        t=t.replace("self.initial=R.parent/f'artifacts/analysis/rcvoa_r20_model_pipeline_20260909/training/member1_{mod}_lr5e-05/validation_best.pt'",
                    "self.initial=R/'source_initialization/training'/f'member1_{mod}_lr5e-05'/'validation_best.pt'")
        start=t.find("with np.load(R/'inputs/isolated20261022/convnext_tiny__MILK.npz')")
        if start>=0:
            end=t.index('\n\nclass Images',start)
            t=t[:start]+"with (W/'metadata/MILK_label_audit.csv').open(encoding='utf-8') as f:\n    LAB={r['id']:(int(r['y']),int(r['subtype'])) for r in csv.DictReader(f)}\n"+t[end:]
        t=t.replace("p=R.parent/r[mod+'_image_path']","p=R.parent.parent/r[mod+'_image_path']")
        if name=='prepare_scale_crops.py':
            guard="""import os,time,atexit
lock=D/'MULTISCALE_BUILD.lock';deadline=time.monotonic()+7200
while True:
    if (D/'MULTISCALE_INPUTS.json').exists():
        print('SCALE_CACHE_ALREADY_COMPLETE',flush=True);raise SystemExit(0)
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd);break
    except FileExistsError:
        if time.monotonic()>deadline:raise TimeoutError('Another crop builder has not completed')
        time.sleep(5)
atexit.register(lambda:lock.unlink(missing_ok=True))
"""
            t=t.replace('files={};records=[]',guard+'files={};records=[]')
        save(C/name,t)
    src=OLD/'experiments/lowflag20261023/source_representation/local_training_manifest.csv'
    shutil.copy2(src,D/src.name);record[str(src.relative_to(R))]=sha(src)
    # Original external folds/labels stay fixed in the source-cohort refit axis.
    (L/'ORIGINAL_RECIPE_INPUTS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    add=dict(status='FROZEN_BEFORE_REFITTING',scope='Remove the source exclusion from the low-flag initialization as well as all subsequent source head/feature fits.',
       source_initializer='Refit original member1 clinical and dermoscopic ConvNeXt from ImageNet; source folds2/3/4 train, fold1 validation, fold0 unused. Same selected lr5e-5, seed, augmentation, bfloat16,16 epochs maximum, patience4. No new LR search.',
       lowflag='Then repeat original source heads, laststage, warmstage, source-only choice, multiscale, and 20 grouped local fits. Source AK maps to binary0/subtype0; KA to binary1/SCC-family; SCCIS separate subtype4.',
       source_thresholds='S uses pooled90%, MEL95%, SCC-family95% including retained KA, BCC90%, SCCIS90%. AK never enters SCCIS denominator.',
       external_training='Original external training manifests and group roles retained; endpoint-setting comparisons are downstream audits of these fitted decisions, not separate target-model retrainings.',
       amendment_to='protocol/PLAN.json: replaces the initially planned fixed low-flag warm-start checkpoint with its expanded-source refit; all other recipes retained.',
       source_files=record)
    save(O/'protocol/SOURCE_INITIALIZATION_ADDENDUM.json',json.dumps(add,indent=2)+'\n')
    print('LOWFLAG_CODE_PREPARED',flush=True)

if __name__=='__main__':main()
