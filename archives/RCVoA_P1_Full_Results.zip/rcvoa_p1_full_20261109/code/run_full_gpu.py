"""Sequential, logged GPU pipeline; resume only completed immutable jobs."""
from pathlib import Path
from datetime import datetime,timezone
import json,sys,subprocess,time,traceback
O=Path(__file__).resolve().parents[1]
def state(stage,status,**extra):
    p=O/'RUN_STATE.json';t=p.with_suffix('.tmp')
    t.write_text(json.dumps(dict(stage=stage,status=status,utc=datetime.now(timezone.utc).isoformat(),**extra),indent=2)+'\n',encoding='utf-8');t.replace(p)
def run(stage,script,args=()):
    state(stage,'RUNNING');print('STAGE',stage,flush=True)
    with (O/'logs'/f'{stage}.log').open('a',encoding='utf-8') as log:
        r=subprocess.run([sys.executable,str(script),*args],stdout=log,stderr=subprocess.STDOUT,cwd=O.parent)
    if r.returncode:raise RuntimeError(f'{stage} exited {r.returncode}; see logs/{stage}.log')
    state(stage,'COMPLETE')
def main():
    state('first_job','WAITING')
    first=O/'backbones/efficientnet_b0__outer0__seed1__clinical/result.json'
    while not first.exists():time.sleep(10)
    run('lowflag_initialization',O/'code/refit_lowflag_initialization.py')
    run('lowflag_source',O/'lowflag/code/train_source_subtypes.py')
    run('lowflag_warmstage',O/'lowflag/code/train_source_warm.py')
    run('lowflag_local',O/'lowflag/code/train_local_subtypes.py')
    if not (O/'lowflag/source_representation/MULTISCALE_INPUTS.json').exists():
        run('lowflag_scale_crops',O/'lowflag/code/prepare_scale_crops.py')
    run('lowflag_multiscale',O/'lowflag/code/export_scale_scores.py')
    run('isolated_backbones',O/'code/train_backbones.py')
    state('all_gpu_fits','COMPLETE');print('ALL_GPU_FITS_COMPLETE',flush=True)
if __name__=='__main__':
    try:main()
    except Exception as e:
        state('pipeline','FAILED',error=str(e));traceback.print_exc();sys.exit(1)
