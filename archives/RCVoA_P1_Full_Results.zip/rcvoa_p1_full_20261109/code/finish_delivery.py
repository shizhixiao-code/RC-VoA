"""After validated analysis, create and independently replay the numerical delivery."""
from pathlib import Path
import json,sys,subprocess,time,traceback
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parents[1]
def read_json(path):return json.loads(path.read_text(encoding='utf-8'))
def write_json(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8');temp.replace(path)

def main():
    write_json(OUT/'DELIVERY_STATE.json',dict(stage='analysis',status='WAITING'))
    while True:
        r=read_json(OUT/'POSTPROCESS_STATE.json')
        if r.get('status')=='FAILED':raise RuntimeError(r)
        if r.get('stage')=='analysis_complete' and r.get('status')=='COMPLETE':break
        time.sleep(15)
    for script in ['make_report.py','package_results.py','replay_package.py']:
        write_json(OUT/'DELIVERY_STATE.json',dict(stage=script,status='RUNNING'))
        with (OUT/'logs'/script.replace('.py','.log')).open('w',encoding='utf-8') as log:
            subprocess.run([sys.executable,str(OUT/'code'/script)],stdout=log,stderr=subprocess.STDOUT,check=True,cwd=OUT.parent)
    write_json(OUT/'DELIVERY_STATE.json',dict(stage='delivery',status='COMPLETE',utc=datetime.now(timezone.utc).isoformat()))
    print('P1_DELIVERY_COMPLETE',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        write_json(OUT/'DELIVERY_STATE.json',dict(stage='delivery',status='FAILED',error=str(e)))
        traceback.print_exc();sys.exit(1)
