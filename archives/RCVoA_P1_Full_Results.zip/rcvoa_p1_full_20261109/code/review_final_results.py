"""Cross-check final denominators, reported contrasts, and preserved PDF pages."""
from pathlib import Path
from collections import defaultdict
import json
from pypdf import PdfReader
from common import OUT,ROOT,read_json,read_csv,write_json,sha

def key(r):
    return (r['family'],r['cohort'],r['mode'],r['batch'],r['cap'],r['setting'],r['imaging_pct'])

def main():
    allrows={}
    for mode,p in [('pipeline',OUT),('frozen',OUT/'fixed_reference')]:
        assert read_json(p/'validation/ANALYSIS_AUDIT.json')['status']=='PASS'
        assert read_json(p/'validation/BOOTSTRAP_AUDIT.json')['status']=='PASS'
        assert read_json(p/'validation/NEW_TABLES_SEAL.json')['interim_tables_reproduced']==200
        rows=read_csv(p/'results/table_results.csv');allrows[mode]={key(r):r for r in rows}
        assert len(rows)==len(allrows[mode])==1524
        for r in rows:
            assert int(r['N'])==int(r['cancer'])+int(r['noncancer'])+int(r['excluded'])
            assert int(r['known'])==int(r['cancer'])+int(r['noncancer'])
            assert int(r['K'])==int(r['N'])*int(r['imaging_pct'])//100
        for r in read_csv(p/'results/feasibility_summary.csv'):
            part=[x for x in rows if all(x[k]==r[k] for k in ['family','setting','imaging_pct'])]
            assert len(part)==int(r['tables'])==(36 if r['family']=='source_SP' else 100)
            assert sum(x['feasible']=='True' for x in part)==int(r['expanded_source_feasible'])
        for r in read_csv(p/'results/system_cohort_summary.csv'):
            part=[x for x in rows if all(x[k]==r[k] for k in ['family','setting','imaging_pct','cohort','mode','cap'])]
            assert len(part)==int(r['tables'])==(1 if r['family']=='source_SP' else 5)
            assert sum(x['feasible']=='True' for x in part)==int(r['feasible'])
        for r in read_csv(p/'results/paired_gain_summary.csv'):
            def selected(x):
                s=r['stratum']
                return s=='all' or x['cohort']==s or (s.startswith('cap') and x['cap']==s[3:])
            parts={f:[x for x in rows if x['family']==f and x['setting']==r['setting'] and x['imaging_pct']=='20' and selected(x)] for f in ['primary','repaired']}
            assert all(len(v)==int(r['tables']) for v in parts.values())
            counts={f:sum(x['feasible']=='True' for x in part) for f,part in parts.items()}
            assert all(counts[f]==int(r[f]) for f in counts)
            assert abs(100*(counts['repaired']-counts['primary'])/int(r['tables'])-float(r['gain_pp']))<1e-10
        # Identical counts do not by themselves establish identical configurations.
        labels=defaultdict(dict)
        for r in rows:
            labels[key(r)[:5]+(r['imaging_pct'],)][r['setting']]=r['feasible']
        assert all(len(set(v.values()))==1 for v in labels.values())
    assert allrows['pipeline'].keys()==allrows['frozen'].keys()
    differences=[k for k,r in allrows['pipeline'].items() if r['feasible']!=allrows['frozen'][k]['feasible']]
    assert len(differences)==9
    assert all(k[0]=='source_SP' and k[1]=='MCR-SL' and k[2].startswith('deit3_') and k[-1]=='15' for k in differences)
    changes=read_csv(OUT/'results/training_rule_changes.csv')
    lost=[r for r in changes if r['family']=='repaired' and r['setting']=='reference' and r['imaging_pct']=='20' and r['original_feasible']=='True' and r['expanded_source_feasible']=='False']
    rescue=lambda r:any(int(r['expanded_'+k])<0 for k in ['mandatory_rescue','subtype_rescue','total_rescue'])
    flag=lambda r:int(r['expanded_flag_downgrade'])<0
    lost_summary=dict(configurations=len(lost),rescue_support=sum(rescue(r) for r in lost),flag_downgrade=sum(flag(r) for r in lost),both=sum(rescue(r) and flag(r) for r in lost))
    assert lost_summary==dict(configurations=8,rescue_support=6,flag_downgrade=4,both=2)
    protected=read_json(OUT/'validation/PRESERVED_CURRENT_VERSION.json')
    for rel,h in protected['files'].items():assert sha(Path(protected['original_root'])/rel)==h
    pages={name:len(PdfReader(OUT/'original_version'/name).pages) for name in ['RCVoA_Main_Integrated.pdf','RCVoA_Supplement_Integrated.pdf']}
    assert list(pages.values())==[8,4]
    fit=read_json(OUT/'validation/FITTING_AUDIT.json')
    assert fit['image_network_training_jobs']==118 and fit['fusion_outer_pipelines']==15
    write_json(OUT/'validation/FINAL_REVIEW.json',dict(status='PASS',code_sha256=sha(__file__),
        resource_denominators_and_integer_budgets_consistent=True,summary_strata_and_bootstrap_observed_counts_match=True,
        endpoint_setting_verdict_sets_identical_within_each_reference_contract=True,
        cross_reference_verdict_differences=differences,reference_repaired_lost_configurations=lost_summary,
        preserved_files=len(protected['files']),preserved_pdf_pages=pages,total_pages=sum(pages.values())))
    print(json.dumps(dict(status='FINAL_REVIEW_PASS',R_differences=len(differences),lost_repaired=lost_summary,pages=pages)))

if __name__=='__main__':main()
