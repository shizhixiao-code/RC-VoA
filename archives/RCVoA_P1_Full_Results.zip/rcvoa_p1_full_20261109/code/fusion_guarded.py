"""Source-selected residual fusion with preserved classifier information.

The original fixed-epoch prototype remains in fusion/. This recipe refinement
is selected and calibrated entirely inside each outer pipeline's source head
fold; no new external outcome has been examined at refinement time.
"""
import argparse
import numpy as np
from scipy.special import expit, logit
from sklearn.model_selection import StratifiedKFold
from threadpoolctl import threadpool_limits
import torch
from torch import nn
from common import *
from fusion import load_view, subset, modality_maps, modality_p, fit_logistic, linear, gate_features, pca_fit, pca_apply, sensitivity_threshold

LAMBDAS=[.1,1.,10.]

def freeze_refinement():
    p=OUT/'fusion_refinement_protocol.json'
    obj=dict(parent_protocol_sha256=protocol_hash(), recipe='Same guarded residual recipe as isolated ConvNeXt/DeiT; fixed before this rerun', penalties=LAMBDAS, inner_folds=5, epochs=100, lr=.001, weight_decay=.001, dropout=.2, batch=128, fallback_improvement=1e-4, external_outcomes_used=False)
    if p.exists():assert read_json(p)==obj
    else:write_json(p,obj)

class GuardedResidual(nn.Module):
    def __init__(self,n1=32,n2=32):
        super().__init__();self.clinical=nn.Linear(n1,32);self.dermoscopy=nn.Linear(n2,32)
        self.attention=nn.MultiheadAttention(32,4,dropout=.2,batch_first=True)
        self.gate=nn.Sequential(nn.Linear(67,16),nn.GELU(),nn.Linear(16,1),nn.Sigmoid())
        self.update=nn.Sequential(nn.Linear(131,64),nn.GELU(),nn.Dropout(.2),nn.Linear(64,1))
        for layer in [self.gate[-2],self.update[-1]]:nn.init.zeros_(layer.weight);nn.init.zeros_(layer.bias)
    def forward(self,f1,f2,z1,z2,baseline):
        c=self.clinical(f1);d=self.dermoscopy(f2);tokens=torch.stack([c,d],1)
        att,_=self.attention(c[:,None,:],tokens,tokens,need_weights=False);scalars=torch.stack([z1,z2,z2-z1],1)
        gate=self.gate(torch.cat([c,d,scalars],1)).squeeze(1)
        residual=self.update(torch.cat([c,d,d-c,att[:,0],scalars],1)).squeeze(1)
        return z1+gate*(2*(baseline-z1)+residual)

def tensors(a,maps,pp):
    p1,p2=modality_p(a,maps)
    x=[torch.from_numpy(pca_apply(a[f'f{j}'],pp[j-1])) for j in [1,2]]
    z=[torch.tensor(logit(np.clip(p,1e-6,1-1e-6)),dtype=torch.float32) for p in [p1,p2,(p1+p2)/2]]
    return [*x,*z]

def fit(a,y,maps,penalty,seed):
    torch.manual_seed(seed);torch.set_num_threads(2);torch.use_deterministic_algorithms(True)
    pp=[pca_fit(a[f'f{j}']) for j in [1,2]];xx=tensors(a,maps,pp);yy=torch.tensor(y,dtype=torch.float32)
    m=GuardedResidual(xx[0].shape[1],xx[1].shape[1]);opt=torch.optim.AdamW(m.parameters(),lr=.001,weight_decay=.001);g=torch.Generator().manual_seed(seed);history=[]
    m.eval()
    with torch.no_grad():assert torch.max(torch.abs(m(*xx)-xx[-1]))<2e-6,'Initialization must reproduce average-probability baseline'
    for epoch in range(100):
        m.train();order=torch.randperm(len(y),generator=g);total=0.
        for k in range(0,len(y),128):
            ix=order[k:k+128];opt.zero_grad(set_to_none=True);z=m(*[v[ix] for v in xx]);loss=nn.functional.binary_cross_entropy_with_logits(z,yy[ix])+penalty*((z-xx[-1][ix])**2).mean()
            assert torch.isfinite(loss);loss.backward();nn.utils.clip_grad_norm_(m.parameters(),5.,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*len(ix)
        history.append(total/len(y))
    m.eval();return m,pp,history

@torch.no_grad()
def predict(a,m,maps,pp):
    out=[]
    for k in range(0,len(a['id']),512):out.append(m(*tensors(subset(a,slice(k,k+512)),maps,pp)).numpy().astype(float))
    return np.concatenate(out)

def logloss(y,z):return float(np.mean(np.logaddexp(0,z)-y*z))

def fit_outer(arch,outer):
    dr=OUT/f'fusion_guarded/{arch}/outer{outer}';dr.mkdir(parents=True,exist_ok=True);codehash=sha(__file__)
    if (dr/'complete.json').exists():
        r=read_json(dr/'complete.json');assert r['code_sha256']==codehash
        for item in r['outputs']:assert sha(OUT/item['path'])==item['sha256']
        return
    a,provenance=load_view(arch,outer);cal=(a['cohort']=='MILK')&(a['fold']==(outer+1)%5);ca=subset(a,cal)
    lookup={r['id']:r['y'] for r in source()};y=np.array([lookup[s] for s in ca['id']]);N=len(y)
    raw2=np.full(N,np.nan);raw3=np.full((N,len(LAMBDAS)),np.nan);oof1=np.full(N,np.nan);oof2=np.full(N,np.nan);splits=[]
    print('GUARDED_FUSION_START',arch,outer,flush=True)
    for inner,(tr,va) in enumerate(StratifiedKFold(5,shuffle=True,random_state=SEED+outer).split(np.zeros(N),y)):
        aa=subset(ca,tr);bb=subset(ca,va);maps=modality_maps(aa,y[tr]);oof1[va],oof2[va]=modality_p(bb,maps)
        l2=fit_logistic(gate_features(aa),y[tr]);raw2[va]=linear(gate_features(bb),l2)
        for j,penalty in enumerate(LAMBDAS):
            m,pp,_=fit(aa,y[tr],maps,penalty,SEED+10000*outer+inner);raw3[va,j]=predict(bb,m,maps,pp)
        splits.append(dict(inner_fold=inner,train_N=len(tr),validation_N=len(va),train_ids=ca['id'][tr].tolist(),validation_ids=ca['id'][va].tolist()))
        print('GUARDED_INNER',arch,outer,inner,flush=True)
    assert np.isfinite(raw3).all() and np.isfinite(raw2).all()
    baseline=logit(np.clip((oof1+oof2)/2,1e-6,1-1e-6));base_loss=logloss(y,baseline);losses=[logloss(y,raw3[:,j]) for j in range(len(LAMBDAS))]
    winner=min(range(len(LAMBDAS)),key=lambda j:(losses[j],-LAMBDAS[j]));fallback=base_loss-losses[winner]<1e-4
    maps=modality_maps(ca,y);l2=fit_logistic(gate_features(ca),y);l2cal=fit_logistic(raw2,y)
    if fallback:m=pp=l3cal=None;l3oof=expit(baseline)
    else:
        m,pp,history=fit(ca,y,maps,LAMBDAS[winner],SEED+10000*outer+99);l3cal=fit_logistic(raw3[:,winner],y);l3oof=expit(linear(raw3[:,winner],l3cal))
        torch.save(m.state_dict(),dr/'L3.pt');save_npz(dr/'L3_projection.npz',**{f'm{j}_{k}':v for j,p in enumerate(pp,1) for k,v in p.items()})
        write_csv(dr/'L3_training_curve.csv',[dict(epoch=j+1,loss=v) for j,v in enumerate(history)])
    selection={'baseline_OOF_logloss':base_loss,'candidate_lambdas':LAMBDAS,'candidate_OOF_logloss':losses,'selected_lambda':None if fallback else LAMBDAS[winner],'L1_fallback':fallback,'minimum_improvement':.0001}
    fits={'modality':maps,'L2':l2,'L2_Platt':l2cal,'L3_Platt':l3cal,'L3_selection':selection,'head_N':N,
          'thresholds':{'p1':sensitivity_threshold(oof1,y),'L1':sensitivity_threshold((oof1+oof2)/2,y),'L2':sensitivity_threshold(expit(linear(raw2,l2cal)),y),'L3':sensitivity_threshold(l3oof,y)}}
    write_json(dr/'fits.json',fits);write_json(dr/'inner_splits.json',splits);write_json(dr/'input_provenance.json',provenance)
    save_npz(dr/'source_head_oof.npz',id=ca['id'],y=y,p1=oof1,p2=oof2,raw_L2=raw2,raw_L3_candidates=raw3,p12_L1=(oof1+oof2)/2,p12_L2=expit(linear(raw2,l2cal)),p12_L3=l3oof)
    for co in COHORTS:
        use=a['cohort']==co
        if co=='MILK':use&=a['fold']==outer
        aa=subset(a,use);p1,p2=modality_p(aa,maps);r2=linear(gate_features(aa),l2)
        if fallback:r3=logit(np.clip((p1+p2)/2,1e-6,1-1e-6));p3=(p1+p2)/2
        else:r3=predict(aa,m,maps,pp);p3=expit(linear(r3,l3cal))
        save_npz(dr/f'{co}.npz',id=aa['id'],group=aa['group'],row_index=aa['row_index'],fold=aa['fold'],p1=p1,p2=p2,p12_L1=(p1+p2)/2,p12_L2=expit(linear(r2,l2cal)),p12_L3=p3,
            raw_L2=r2,raw_L3=r3,clinical_variance=aa['var1'],dermoscopic_variance=aa['var2'])
    outputs=[{'path':p.relative_to(OUT).as_posix(),'sha256':sha(p)} for p in sorted(dr.iterdir()) if p.is_file()]
    write_json(dr/'complete.json',dict(complete=True,arch=arch,outer=outer,utc=now(),code_sha256=codehash,protocol_sha256=protocol_hash(),refinement_protocol_sha256=sha(OUT/'fusion_refinement_protocol.json'),outer_fit_overlap=0,external_outcomes_read=0,outputs=outputs))
    print('GUARDED_FUSION_COMPLETE',arch,outer,selection,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arch',default='all',choices=BACKBONES+['all']);ap.add_argument('--outer',type=int);ap.add_argument('--freeze-only',action='store_true');args=ap.parse_args();freeze_refinement()
    if args.freeze_only:return
    with threadpool_limits(limits=2):
      for arch in BACKBONES if args.arch=='all' else [args.arch]:
       for outer in range(5) if args.outer is None else [args.outer]:fit_outer(arch,outer)

if __name__=='__main__':main()
