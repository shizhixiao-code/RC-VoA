"""Verify all completed fits, roles, source labels and preserved paper hashes."""
from pathlib import Path
from collections import Counter
import csv,json,sys
import numpy as np
from common import OUT,ROOT,sha,read_json,read_csv,write_json,nz,BACKBONES,MODS

def main():
    assert read_json(OUT/'validation/MULTISCALE_CACHE_AUDIT.json')['status']=='PASS'
    original_runtime=read_json(ROOT/'rcvoa_fusion_week2/training_runtime.json')
    current_runtime=read_json(OUT/'training_runtime.json')
    runtime_keys=['python','torch','numpy','timm','gpu','cuda','precision']
    assert all(original_runtime[k]==current_runtime[k] for k in runtime_keys)
    fusion_runtime=read_json(OUT/'fusion_runtime.json')
    assert fusion_runtime['torch']=='2.13.0+cpu' and fusion_runtime['numpy']=='2.5.1'
    assert fusion_runtime['original_interpreter_reused'] is True
    for rel,h in read_json(OUT/'validation/ORIGINAL_TRAINING_DEPENDENCIES.json').items():assert sha(ROOT/rel)==h,rel
    protocol=sha(OUT/'protocol.json');jobs=[];epochs=0;fit_seconds=0.
    resume_file=OUT/'validation/RESUME_HISTORY.json'
    resume_history=read_json(resume_file) if resume_file.exists() else []
    for arch in BACKBONES:
        for f in range(5):
            for seed in [1,2,3]:
                for mod in MODS:
                    dr=OUT/f'backbones/{arch}__outer{f}__seed{seed}__{mod}';r=read_json(dr/'result.json')
                    assert r['protocol_sha256']==protocol and r['training_code_sha256']==sha(OUT/'code/train_backbones.py')
                    assert r['checkpoint_sha256']==sha(dr/'best.pt')
                    for p in r['exports']:assert sha(OUT/p['path'])==p['sha256']
                    roles=read_csv(dr/'component_roles.csv');assert len(roles)==len({x['id'] for x in roles})==4978
                    assert all((int(x['fold'])==f)==(x['role']=='outer_holdout') for x in roles)
                    assert all((int(x['fold'])==(f+1)%5)==(x['role']=='fusion_calibration') for x in roles)
                    assert r['outer_rows_used_in_fitting_or_selection']==r['external_outcomes_read']==0
                    curve=read_csv(dr/'learning_curve.csv');epochs+=len(curve);fit_seconds+=float(curve[-1]['elapsed_seconds'])
                    fit_seconds+=sum(float(q['committed_elapsed_seconds']) for q in resume_history if q['job']==r['job'])
                    jobs.append(r['job'])
            dr=OUT/f'fusion_guarded/{arch}/outer{f}';r=read_json(dr/'complete.json')
            assert r['outer_fit_overlap']==r['external_outcomes_read']==0
            for p in r['outputs']:assert sha(OUT/p['path'])==p['sha256']
        aggregated=read_json(OUT/f'predictions/{arch}__COMPLETE.json')
        assert aggregated['source_N']==4978 and aggregated['source_outer_pipelines']==5
        assert aggregated['external_outcomes_used'] is False
        for item in aggregated['files']:
            path=OUT/'predictions'/item['file'];assert sha(path)==item['sha256']
            a=nz(path)
            for key in ['p1','p2','p12_L1','p12_L2','p12_L3']:
                assert np.isfinite(a[key]).all() and np.all((a[key]>=0)&(a[key]<=1))
    low=OUT/'lowflag/source_representation';lowjobs=[]
    for mod in MODS:
        init=OUT/f'lowflag/source_initialization/training/member1_{mod}_lr5e-05';r=read_json(init/'result.json')
        assert sha(init/'validation_best.pt')==r['checkpoint_sha256'] and r['external_rows_used']==r['calibration_components_used']==0
        for mode in ['headonly','laststage','warmstage']:
            dr=low/f'{mode}__{mod}';r=read_json(dr/'COMPLETE.json')
            script='train_source_warm.py' if mode=='warmstage' else 'train_source_subtypes.py'
            plan='SOURCE_WARM_START_PLAN.md' if mode=='warmstage' else 'SOURCE_REPRESENTATION_PLAN.md'
            assert r['code']==sha(OUT/'lowflag/code'/script) and r['protocol']==sha(OUT/'lowflag/protocol'/plan)
            assert r['external_training_cases']==0 and r['initial_sha256']==sha(init/'validation_best.pt')
            assert r['source_train']+r['source_validation']<4978
            assert sha(dr/'selected_delta.pt')==r['delta_sha256']
            for p in r['exports']:assert sha(dr/p['file'])==p['sha256']
            lowjobs.append(dr.name)
        dr=low/f'multiscale__{mod}';r=read_json(dr/'COMPLETE.json');assert r['external_training_cases']==0
        assert r['code']==sha(OUT/'lowflag/code/export_scale_scores.py')
        for p in r['exports']:assert sha(dr/p['file'])==p['sha256']
        for mode in ['localheads','localfeatures']:
            for f in range(5):
                dr=low/f'{mode}__fold{f}__{mod}';r=read_json(dr/'COMPLETE.json')
                assert r['code']==sha(OUT/'lowflag/code/train_local_subtypes.py')
                assert r['protocol']==sha(OUT/'lowflag/protocol/LOCAL_REPRESENTATION_PLAN.md')
                assert r['manifest_sha256']==sha(low/'local_training_manifest.csv')
                assert r['evaluation_training_cases']==r['calibration_training_cases']==0 and r['outer_fold']==f
                assert sha(dr/'selected_delta.pt')==r['selected_delta_sha256']
                for p in r['exports']:assert sha(dr/p['file'])==p['sha256']
                lowjobs.append(dr.name)
    for mod in MODS:
        rec=read_json(OUT/f'cache/{mod}_uint8.json');assert rec['existing_crops_verified']==13885
    protected=read_json(OUT/'validation/PRESERVED_CURRENT_VERSION.json')
    for rel,h in protected['files'].items():assert sha(Path(protected['original_root'])/rel)==h
    assert len(jobs)==90 and len(lowjobs)==26
    write_json(OUT/'validation/FITTING_AUDIT.json',dict(status='PASS',source_backbone_jobs=90,source_initialization_jobs=2,lowflag_training_jobs=26,
        image_network_training_jobs=118,fusion_outer_pipelines=15,source_components=4978,source_backbone_epochs=epochs,
        source_backbone_fit_validation_seconds=fit_seconds,resumed_jobs=len({q['job'] for q in resume_history}),
        timing_scope='Sum of committed training/validation run segments, including recorded pre-resume segments; excludes interrupted partial-epoch overhead, export, preprocessing, fusion and lowflag stages. Not online verification runtime.',
        original_crops_verified=27770,original_isolated_training_runtime_matched=runtime_keys,
        protected_files_unchanged=len(protected['files']),code_sha256=sha(__file__)))
    print('FITTING_AUDIT_PASS',len(jobs),len(lowjobs)+2,flush=True)
if __name__=='__main__':main()
