"""Verify a packaged result by a fresh, separate numerical replay."""
from pathlib import Path
from zipfile import ZipFile
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
from common import OUT,read_json,sha,write_json

CSV=['table_results.csv','training_rule_changes.csv','feasibility_summary.csv','system_cohort_summary.csv',
     'fold_stability.csv','failure_margins_nonexclusive.csv','paired_gain_summary.csv','bootstrap_draws.csv',
     'bootstrap_validation.csv','batch_pass_counts.csv']

def main():
    archive=OUT/'RCVoA_P1_Full_Results.zip'
    receipt=read_json(OUT/'validation/PACKAGE_AUDIT.json');assert sha(archive)==receipt['sha256']
    dest=OUT/'portable_replays'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    dest.mkdir(parents=True,exist_ok=False)
    with ZipFile(archive) as z:
        manifest=json.loads(z.read('ARCHIVE_MANIFEST.json'))
        for name,h in manifest.items():
            path=(dest/name).resolve();assert path.is_relative_to(dest.resolve())
            data=z.read(name);assert hashlib.sha256(data).hexdigest()==h
            path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    project=dest/OUT.name;checked=[]
    for mode in ['pipeline','frozen']:
        for script in ['run_full_analysis.py','bootstrap_repair.py']:
            with (dest/f'{mode}_{script}.log').open('w',encoding='utf-8') as log:
                subprocess.run([sys.executable,str(project/'code'/script),'--reference-mode',mode],check=True,
                               stdout=log,stderr=subprocess.STDOUT,cwd=dest)
        src=OUT if mode=='pipeline' else OUT/'fixed_reference'
        new=project if mode=='pipeline' else project/'fixed_reference'
        for name in CSV:
            assert sha(src/'results'/name)==sha(new/'results'/name),(mode,name)
            checked.append(f'{mode}/{name}')
    with (dest/'sccis.log').open('w',encoding='utf-8') as log:
        subprocess.run([sys.executable,str(project/'code/check_sccis_equivalence.py')],check=True,
                       stdout=log,stderr=subprocess.STDOUT,cwd=dest)
    write_json(OUT/'validation/PORTABLE_REPLAY.json',dict(status='PASS',archive_sha256=sha(archive),
        extracted_to=str(dest),exact_csv_hash_matches=checked,independent_source_images_or_weights_needed=False))
    print('PORTABLE_REPLAY_PASS',len(checked),flush=True)

if __name__=='__main__':main()
