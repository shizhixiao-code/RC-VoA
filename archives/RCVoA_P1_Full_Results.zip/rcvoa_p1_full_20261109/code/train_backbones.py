"""MILK-only new outer-OOF backbones; resumable, FP32, no target outcomes."""
import os
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
os.environ['HF_HUB_OFFLINE']='1'
import argparse, gc, math, random, time
import multiprocessing as mp
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms
from PIL import Image
import timm
from safetensors.torch import load_file
from common import *

def setup(seed):
    random.seed(seed);np.random.seed(seed % 2**32);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark=False;torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    timm.layers.set_fused_attn(False)

def save_torch(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp')
    torch.save(x,t);t.replace(p)

def split(outer):
    rows=source();cal=(outer+1)%5
    pool=[r for r in rows if r['fold'] not in [outer,cal]]
    val=set()
    for y in [0,1]:
        group=sorted([r for r in pool if r['y']==y],key=lambda r:hashlib.sha256(f'{SEED}|{outer}|{r["id"]}'.encode()).hexdigest())
        val.update(r['id'] for r in group[:max(1,round(.10*len(group)))] )
    tr=[r for r in pool if r['id'] not in val];va=[r for r in pool if r['id'] in val]
    ca=[r for r in rows if r['fold']==cal];te=[r for r in rows if r['fold']==outer]
    sets=[set(r['id'] for r in x) for x in [tr,va,ca,te]]
    assert sum(map(len,sets))==4978 and len(set.union(*sets))==4978
    return tr,va,ca,te

class Images(Dataset):
    def __init__(self,rows,modality,train,seed,epoch):
        self.rows=rows;self.mod=modality;self.train=train;self.seed=seed;self.epoch=mp.Value("q",epoch) if train else epoch
        aug=[transforms.RandomResizedCrop(224,scale=(.75,1.)),transforms.RandomHorizontalFlip(),transforms.RandomVerticalFlip(),
             transforms.RandomRotation(20),transforms.ColorJitter(.15,.15,.15,.02)] if train else [transforms.Resize(256),transforms.CenterCrop(224)]
        self.tx=transforms.Compose(aug+[transforms.ToTensor(),transforms.Normalize([.485,.456,.406],[.229,.224,.225])])
    def __len__(self):return len(self.rows)
    def __getitem__(self,i):
        r=self.rows[i]
        with Image.open(ROOT/r[self.mod+'_image_path']) as im:image=im.convert('RGB')
        epoch=self.epoch.value if self.train else self.epoch
        seed=int.from_bytes(hashlib.sha256(f'{self.seed}|{epoch}|{r["id"]}'.encode()).digest()[:8],'little')%(2**63-1)
        with torch.random.fork_rng(devices=[]):
            torch.manual_seed(seed);x=self.tx(image)
        return x,r['y']

def loader(rows,mod,train,seed,epoch,batch=16):
    return DataLoader(Images(rows,mod,train,seed,epoch),batch_size=batch,shuffle=train,num_workers=4 if train else 0,persistent_workers=train,
                      pin_memory=True,generator=torch.Generator().manual_seed(seed+10000*epoch),drop_last=False)

def build(arch):
    if arch=='efficientnet_b0':
        m=models.efficientnet_b0(weights=None)
        m.load_state_dict(torch.load(ROOT/'artifacts/pretrained/efficientnet_b0_rwightman-7f5810bc.pth',map_location='cpu',weights_only=True))
        m.classifier[-1]=nn.Linear(1280,2)
    elif arch=='convnext_tiny':
        m=models.convnext_tiny(weights=None)
        m.load_state_dict(torch.load(ROOT/'artifacts/pretrained/convnext_tiny-983f1562.pth',map_location='cpu',weights_only=True))
        m.classifier[-1]=nn.Linear(768,2)
    else:
        m=timm.create_model(arch,pretrained=False,num_classes=2)
        state=load_file(str(ROOT/'output/rcvoa_autodl_20261008/bundle/weights/model.safetensors'))
        state.pop('head.weight');state.pop('head.bias')
        missing=m.load_state_dict(state,strict=False)
        assert set(missing.missing_keys)=={'head.weight','head.bias'} and not missing.unexpected_keys
    return m.cuda()

def rank_auc(y,z):
    ix=np.argsort(z,kind='stable');s=z[ix];a=np.flatnonzero(np.r_[True,s[1:]!=s[:-1]]);b=np.r_[a[1:],len(s)]
    ranks=np.empty(len(y),float)
    for start,end in zip(a,b):ranks[ix[start:end]]=(start+1+end)/2
    n1=int(y.sum());n0=len(y)-n1
    return float((ranks[y==1].sum()-n1*(n1+1)/2)/(n1*n0))

@torch.no_grad()
def evaluate(m,dl):
    m.eval();yy=[];zz=[]
    for x,y in dl:
        z=m(x.cuda(non_blocking=True));assert torch.isfinite(z).all()
        zz.extend((z[:,1]-z[:,0]).double().cpu().tolist());yy.extend(y.tolist())
    y=np.array(yy);z=np.array(zz)
    return {'logloss':float(np.mean(np.logaddexp(0,z)-y*z)),'auc':rank_auc(y,z)}

@torch.no_grad()
def export(m,arch,outer,seed,mod,directory):
    m.eval();rows=cases();cal=(outer+1)%5
    take=[r for r in rows if r['cohort']!='MILK' or int(r['source_fold']) in [outer,cal]]
    cache=np.load(W1/f'cache/{mod}_uint8.npy',mmap_mode='r')
    mean=torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None]
    sd=torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]
    exports=[]
    for co in COHORTS:
        rr=[r for r in take if r['cohort']==co];p=directory/f'{co}.npz';idx=np.array([int(r['row_index']) for r in rr])
        fs=[];zs=[]
        for k in range(0,len(idx),32):
            x=torch.from_numpy(np.array(cache[idx[k:k+32]],copy=True)).cuda().float().div_(255)
            x=(x-mean)/sd
            if arch=='efficientnet_b0':h=torch.flatten(m.avgpool(m.features(x)),1);z=m.classifier(h)
            elif arch=='convnext_tiny':h=m.classifier[1](m.classifier[0](m.avgpool(m.features(x))));z=m.classifier[2](h)
            else:h=m.forward_head(m.forward_features(x),pre_logits=True);z=m.head(h)
            assert torch.isfinite(h).all() and torch.isfinite(z).all()
            fs.append(h.cpu().numpy());zs.append(z.cpu().numpy())
        f=np.concatenate(fs);z=np.concatenate(zs)
        save_npz(p,row_index=idx,two_class_logits=z,logit=z[:,1]-z[:,0],**({'embedding':f} if seed==1 else {}))
        exports.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'sha256':sha(p),'N':len(idx)})
    return exports

def run_job(arch,outer,seedindex,mod):
    job=f'{arch}__outer{outer}__seed{seedindex}__{mod}'
    dr=OUT/'backbones'/job;dr.mkdir(parents=True,exist_ok=True)
    result=dr/'result.json';ph=protocol_hash();codehash=sha(__file__)
    if result.exists():
        r=read_json(result);assert r['protocol_sha256']==ph and r['training_code_sha256']==codehash
        assert sha(dr/'best.pt')==r['checkpoint_sha256']
        for item in r['exports']:assert sha(OUT/item['path'])==item['sha256']
        print('REUSED_COMPLETE',job,flush=True);return
    setup(SEED+10000*outer+100*seedindex+MODS.index(mod))
    seed=SEED+10000*outer+100*seedindex+MODS.index(mod)
    tr,va,ca,te=split(outer)
    roles=[dict(id=r['id'],role=role,fold=r['fold']) for role,rs in [('gradient',tr),('validation',va),('fusion_calibration',ca),('outer_holdout',te)] for r in rs]
    write_csv(dr/'component_roles.csv',roles)
    m=build(arch)
    if arch=='deit3_base_patch16_224':
        groups=[{'params':[p for n,p in m.named_parameters() if p.ndim>1 and not n.endswith('.bias')],'weight_decay':.05},
                {'params':[p for n,p in m.named_parameters() if p.ndim<=1 or n.endswith('.bias')],'weight_decay':0.}]
    else:groups=[{'params':m.parameters(),'weight_decay':.0001}]
    opt=torch.optim.AdamW(groups,lr=5e-5,foreach=False)
    counts=np.bincount([r['y'] for r in tr],minlength=2);w=torch.tensor(len(tr)/(2*counts),dtype=torch.float32,device='cuda')
    history=[];best=None;bad=0;last=OUT/'live_training_resume.pt'
    if last.exists():
        state=torch.load(last,map_location='cpu',weights_only=True)
        if state['job']==job:
            assert state['protocol_sha256']==ph and state['training_code_sha256']==codehash
            m.load_state_dict(state['model']);opt.load_state_dict(state['optimizer']);history=state['history'];best=state['best'];bad=state['bad']
            for st in opt.state.values():
                for k,v in st.items():
                    if isinstance(v,torch.Tensor):st[k]=v.cuda()
        del state
    started=time.time();print('START',job,'source_roles',[len(x) for x in [tr,va,ca,te]],flush=True)
    dl=None
    for epoch in range(len(history)+1,9):
        if bad>=3 and len(history)>=3:break
        setup(seed+1000000*epoch);m.train();loss_sum=denom_sum=0.
        if dl is None:dl=loader(tr,mod,True,seed,epoch)
        else:
            dl.dataset.epoch.value=epoch
            dl.generator.manual_seed(seed+10000*epoch)
            # A fresh iterator consumes one worker base seed before its shuffle.
            # Persistent workers reuse the iterator; consume that draw explicitly.
            torch.empty((),dtype=torch.int64).random_(generator=dl.generator)
        for step,(x,y) in enumerate(dl):
            opt.zero_grad(set_to_none=True);y=y.cuda(non_blocking=True);denom=w[y].sum();total=0.
            for a in range(0,len(y),8):
                xx=x[a:a+8].cuda(non_blocking=True);yy=y[a:a+8]
                z=m(xx);loss=nn.functional.cross_entropy(z,yy,weight=w,reduction='sum')/denom
                assert torch.isfinite(loss) and torch.isfinite(z).all();loss.backward();total+=float(loss.detach())
            nn.utils.clip_grad_norm_(m.parameters(),5.,error_if_nonfinite=True);opt.step()
            loss_sum+=total*float(denom);denom_sum+=float(denom)
            if step%50==0:write_json(OUT/'training_progress.json',dict(job=job,epoch=epoch,step=step,total_steps=len(dl),updated_utc=now(),state='TRAINING'))
        met=evaluate(m,loader(va,mod,False,seed,epoch,batch=16))
        row=dict(epoch=epoch,weighted_train_loss=loss_sum/denom_sum,validation_logloss=met['logloss'],validation_auc=met['auc'],elapsed_seconds=time.time()-started)
        history.append(row)
        key=(met['logloss'],-met['auc'],epoch)
        if best is None or key<tuple(best['key']):
            significant=best is None or met['logloss']<best['key'][0]-.0001
            best=dict(key=list(key),epoch=epoch,validation=met);save_torch(dr/'best.pt',{k:v.detach().cpu() for k,v in m.state_dict().items()})
            bad=0 if significant else bad+1
        else:bad+=1
        save_torch(last,dict(job=job,protocol_sha256=ph,training_code_sha256=codehash,model={k:v.detach().cpu() for k,v in m.state_dict().items()},optimizer=opt.state_dict(),history=history,best=best,bad=bad))
        write_csv(dr/'learning_curve.csv',history)
        write_json(OUT/'training_progress.json',dict(job=job,updated_utc=now(),state='EPOCH_COMMITTED',**row))
        print(json.dumps({'job':job,**row,'best_epoch':best['epoch']}),flush=True)
    del dl
    m.load_state_dict(torch.load(dr/'best.pt',map_location='cpu',weights_only=True));del opt
    torch.cuda.empty_cache()
    exports=export(m,arch,outer,seedindex,mod,dr)
    write_json(result,dict(job=job,arch=arch,outer_fold=outer,seed_index=seedindex,seed=seed,modality=mod,
        completed_utc=now(),protocol_sha256=ph,training_code_sha256=codehash,checkpoint_sha256=sha(dr/'best.pt'),
        best=best,epochs_run=len(history),source_counts=dict(gradient=len(tr),validation=len(va),fusion_calibration=len(ca),outer_holdout=len(te)),
        outer_rows_used_in_fitting_or_selection=0,external_outcomes_read=0,exports=exports))
    del m;gc.collect();torch.cuda.empty_cache();print('JOB_COMPLETE',job,flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--arch',choices=BACKBONES+['all'],default='all');ap.add_argument('--one',action='store_true');args=ap.parse_args()
    freeze();assert torch.cuda.is_available()
    write_json(OUT/'training_runtime.json',{'created_utc':now(),'python':sys.version,'torch':str(torch.__version__),'numpy':np.__version__,'timm':timm.__version__,'gpu':torch.cuda.get_device_name(),'cuda':torch.version.cuda,'precision':'FP32','protocol_sha256':protocol_hash()})
    architectures=BACKBONES if args.arch=='all' else [args.arch]
    for arch in architectures:
      for outer in range(5):
       for seed in [1,2,3]:
        for mod in MODS:
         run_job(arch,outer,seed,mod)
         if args.one:return
    completed=list((OUT/'backbones').glob('*/result.json'))
    write_json(OUT/'backbone_training_complete.json',{'completed_jobs':len(completed),'expected_jobs':90,'complete':len(completed)==90,'utc':now(),'protocol_sha256':protocol_hash()})

if __name__=='__main__':main()
