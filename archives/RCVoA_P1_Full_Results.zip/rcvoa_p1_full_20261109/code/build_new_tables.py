"""Seal expanded-source thresholds and primary/repaired decision tables.

All clinical targets, reference definitions, and original external groups are
unchanged. Evaluation labels are used only after each repair cutoff is fixed
from the disjoint calibration fold. Audits are run in a separate script.
"""
from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from common import read_json,read_csv,write_json,write_csv,save_npz,nz,sha,OUT,ROOT,BACKBONES
from reference_allocation import closed_form

OLD=ROOT/'rcvoa_label_sensitivity_20261109'
ORIG=ROOT/'rcvoa_criteria_revision_20261023/experiments/lowflag20261023/source_representation'
LABELS=['Melanoma','Invasive SCC','SCC NOS','BCC','SCCIS','Other cancer','Benign','Excluded']
RATES={0:95,1:95,2:95,3:90,4:90}
MODES=['headonly','laststage','multiscale','localheads','localfeatures']

def cohort_meta(co):
    entries=read_json(OLD/'inputs/tables.json')
    e=next(x for x in entries if x['family']=='source_SP' and x['cohort']==co)
    z=nz(OLD/'inputs/tables'/e['file']);return {k:v for k,v in z.items() if k!='cells'}
def cell_table(labels,b,p,r,key='calibration',cap=100):
    cells=b.astype(int)*4+p.astype(int)*2+r.astype(int)
    x=np.zeros((8,8),dtype=np.int64);np.add.at(x,(labels,cells),1)
    return dict(table_id=key,cap=cap,cells=[[LABELS[j],int((c>>2)&1),int((c>>1)&1),int(c&1),int(x[j,c])] for j,c in np.argwhere(x>0)])
def threshold(p,mask,pct):
    n=int(mask.sum());assert n>0
    assert np.isfinite(p).all() and np.all((p>=0)&(p<=1))
    need=(pct*n+99)//100;cut=float(np.sort(p[mask])[::-1][need-1])
    assert int(((p>=cut)&mask).sum())>=need
    return cut
def source_thresholds(arch):
    a=nz(OUT/f'predictions/{arch}__MILK.npz');ll={r['id']:r for r in read_csv(OUT/'metadata/MILK_label_audit.csv')}
    labels=np.array([int(ll[i]['y']) for i in a['id']]);sub=np.array([int(ll[i]['subtype']) for i in a['id']])
    assert len(labels)==4978 and np.array_equal(labels,a['y'])
    out=dict(P={},S={},source_N=4978,source_prediction_sha256=sha(OUT/f'predictions/{arch}__MILK.npz'),external_outcomes_used=False)
    detail=[]
    for key in ['p1','p12_L1','p12_L2','p12_L3']:
        out['P'][key]=threshold(a[key],labels==1,90)
        cuts=[out['P'][key]]
        detail.append(dict(arch=arch,score=key,subtype='pooled',floor_pct=90,N=int((labels==1).sum()),cutoff=out['P'][key]))
        for ty,rate in [(1,95),(2,90),(3,95),(4,90)]:
            mask=(labels==1)&(sub==ty);cut=threshold(a[key],mask,rate);cuts.append(cut)
            detail.append(dict(arch=arch,score=key,subtype=ty,floor_pct=rate,N=int(mask.sum()),cutoff=cut))
        out['S'][key]=min(cuts)
        for row in [r for r in detail if r['score']==key]:
            mask=(labels==1) if row['subtype']=='pooled' else (labels==1)&(sub==row['subtype'])
            row['required']=(row['floor_pct']*row['N']+99)//100;row['S_cutoff']=out['S'][key]
            row['detected_at_S']=int(((a[key]>=out['S'][key])&mask).sum());assert row['detected_at_S']>=row['required']
    write_json(OUT/f'predictions/{arch}__thresholds.json',out)
    write_csv(OUT/f'predictions/{arch}__threshold_strata.csv',detail)
    return out
def percentile(x,ref):
    return np.column_stack([(np.searchsorted(np.sort(ref[:,j]),x[:,j],'left')+np.searchsorted(np.sort(ref[:,j]),x[:,j],'right')+1)/(2*(len(ref)+1)) for j in range(x.shape[1])])
def cap_threshold(x,q):
    return float(np.nextafter(np.sort(x)[::-1][int(np.floor(q*len(x)))],np.inf))
def cutoff(labels,b,r,risk,original):
    tab=cell_table(labels,b,risk>=original,r)
    s=dict(imaging_pct=100,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=100)
    cf=closed_form(tab,s);ca=labels<6;mandatory=ca&r&~b
    bounds=[('original',float(original))]
    if mandatory.any():bounds.append(('mandatory',float(risk[mandatory].min())))
    for ty,rate in RATES.items():
        mask=labels==ty;need=max(0,(rate*int(mask.sum())+99)//100-int((mask&b).sum()))
        if need:bounds.append((LABELS[ty],float(np.sort(risk[mask&~b])[::-1][need-1])))
    if cf['t_star']:bounds.append(('total',float(np.sort(risk[ca&~b])[::-1][cf['t_star']-1])))
    cut=min(v for _,v in bounds)
    after=closed_form(cell_table(labels,b,risk>=cut,r),s)
    assert min(after['margins'][:3])>=0
    if cut<original:assert min(closed_form(cell_table(labels,b,risk>=np.nextafter(cut,np.inf),r),s)['margins'][:3])<0
    return cut,dict(calibration_N=len(labels),calibration_cancer=int(ca.sum()),calibration_mandatory=int(mandatory.sum()),calibration_t_star=cf['t_star'],binding=';'.join(k for k,v in bounds if v==cut))
def select_source(d):
    out={}
    for mod in ['clinical','dermoscopic']:
        choices=[]
        for mode in ['laststage','warmstage']:
            dr=d/f'{mode}__{mod}';rec=read_json(dr/'COMPLETE.json');history=read_json(dr/'history.json')
            val=next(r['loss'] for r in history if r['epoch']==rec['selected_epoch']);choices.append((val,mode))
        val,mode=min(choices);out[mod]=dict(mode=mode,loss=val,alternatives=choices)
    return out
def scores(d,selection,co,mode,f,ids):
    cols=[]
    for mod in ['clinical','dermoscopic']:
        name=selection[mod]['mode'] if mode=='laststage' else mode
        dr=d/(f'{name}__fold{f}__{mod}' if name.startswith('local') else f'{name}__{mod}')
        rec=read_json(dr/'COMPLETE.json');p=dr/f'{co}.npz'
        assert sha(p)==next(r['sha256'] for r in rec['exports'] if r['file']==p.name)
        if name.startswith('local'):assert rec['evaluation_training_cases']==rec['calibration_training_cases']==0
        a=nz(p);assert np.array_equal(a['id'],ids)
        col=a['risk_scores'] if 'risk_scores' in a else np.column_stack([a['binary_logits'][:,1]-a['binary_logits'][:,0],a['subtype_logits'][:,1]-a['subtype_logits'][:,0]])
        assert col.shape==(len(ids),2) and np.isfinite(col).all()
        cols.append(col)
    return cols[0],(cols[0]+cols[1])/2

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--reference-mode',choices=['pipeline','frozen'],default='pipeline');args=ap.parse_args()
    target=OUT if args.reference_mode=='pipeline' else OUT/'fixed_reference'
    dest=target/'inputs/tables';dest.mkdir(parents=True,exist_ok=True)
    original_entries={(e['family'],e['cohort'],e['mode']):e for e in read_json(OLD/'inputs/tables.json') if e['family']=='source_SP'}
    entries=[];cutoffs=[];fits={a:source_thresholds(a) for a in BACKBONES}
    def save_entry(meta,b,p,r,family,co,mode,batch,cap):
        key=f'{family}_{co}_{mode}_b{batch}_q{cap}';cells=b.astype(int)*4+p.astype(int)*2+r.astype(int)
        path=dest/f'{key}.npz';save_npz(path,**meta,cells=cells)
        entries.append(dict(table_id=key,family=family,cohort=co,mode=mode,batch=batch,cap=cap,file=path.name,reference_mode=args.reference_mode,
            reference_N=len(b),decision_sha256=hashlib.sha256(cells.tobytes()).hexdigest()))
    for co in ['MRA','HIBA','UQ','MCR-SL']:
        meta=cohort_meta(co)
        for arch in BACKBONES:
            a=nz(OUT/f'predictions/{arch}__{co}.npz');assert np.array_equal(a['id'],meta['id'])
            b=a['p1']>=fits[arch]['S']['p1']
            for level in ['L1','L2','L3']:
                p=a[f'p12_{level}']>=fits[arch]['P'][f'p12_{level}']
                if args.reference_mode=='frozen':
                    e=original_entries['source_SP',co,arch+'_'+level];old=nz(OLD/'inputs/tables'/e['file'])
                    assert np.array_equal(old['id'],meta['id']);r=(old['cells']&1)>0
                else:r=b
                save_entry(meta,b,p,r,'source_SP',co,arch+'_'+level,-1,100)
    d=OUT/'lowflag/source_representation';selection=select_source(d);write_json(d/'SOURCE_SELECTION.json',selection)
    for co in ['MRA','UQ']:
        meta=cohort_meta(co);a=nz(OUT/f'predictions/convnext_tiny__{co}.npz');assert np.array_equal(a['id'],meta['id'])
        if args.reference_mode=='frozen':
            e=original_entries['source_SP',co,'convnext_tiny_L1'];old=nz(OLD/'inputs/tables'/e['file'])
            assert np.array_equal(old['id'],meta['id']);ref=(old['cells']&1)>0
        else:ref=a['p1']>=fits['convnext_tiny']['S']['p1']
        for mode in MODES:
            frozen=nz(ORIG/f'{co}__{mode}__planning_decisions.npz');fold=frozen['fold'];assert np.array_equal(frozen['id'],meta['id'])
            for g in np.unique(meta['group']):assert len(set(fold[meta['group']==g]))==1
            for f in range(5):
                te=fold==f;cal=fold==(f+1)%5;de=~(te|cal)
                assert not set(meta['group'][te])&set(meta['group'][cal])
                cp,pp=scores(d,selection,co,mode,f,meta['id']);cc=percentile(cp,cp[de]).mean(1);pc=percentile(pp,pp[de]).mean(1)
                for q in [.3,.5]:
                    t1=cap_threshold(cc[te],q);t12=cap_threshold(pc[de],q);b=cc>=t1;p=pc>=t12
                    cut,info=cutoff(meta['labels'][cal],b[cal],ref[cal],pc[cal],t12)
                    repaired=np.where(b,p,pc>=cut)
                    assert np.array_equal(repaired[b],p[b]) and np.all(repaired|~p)
                    mm={k:v[te] for k,v in meta.items()}
                    for family,pair in [('primary',p),('repaired',repaired)]:save_entry(mm,b[te],pair[te],ref[te],family,co,mode,f+1,int(q*100))
                    cutoffs.append(dict(cohort=co,mode=mode,batch=f+1,cap=int(q*100),t1=t1,original_t12=t12,repaired_t12=cut,lowered=cut<t12,
                        evaluation_group_overlap=0,calibration_ids_sha256=hashlib.sha256('\n'.join(meta['id'][cal]).encode()).hexdigest(),**info))
    assert len(entries)==236 and len(cutoffs)==100
    interim=OUT/('interim_fixed_reference' if args.reference_mode=='frozen' else 'interim_pipeline_reference')
    interim_checks=0
    if (interim/'INTERIM_AUDIT.json').exists():
        assert read_json(interim/'INTERIM_AUDIT.json')['status']=='PASS'
        for e in entries:
            if e['family']=='source_SP':continue
            before=nz(interim/'inputs/tables'/e['file']);after=nz(dest/e['file'])
            assert before.keys()==after.keys()
            assert all(np.array_equal(before[k],after[k]) for k in before),e['table_id']
            interim_checks+=1
        assert interim_checks==200
    write_json(target/'inputs/tables.json',entries);write_csv(target/'results/calibration_cutoffs.csv',cutoffs)
    write_json(target/'validation/PRESERVED_CURRENT_VERSION.json',read_json(OUT/'validation/PRESERVED_CURRENT_VERSION.json'))
    write_json(target/'validation/NEW_TABLES_SEAL.json',dict(status='PASS',tables=236,source_SP=36,primary=100,repaired=100,reference_mode=args.reference_mode,
        original_folds_preserved=True,source_N=4978,source_fit_hashes={a:sha(OUT/f'predictions/{a}__thresholds.json') for a in BACKBONES},
        portable_input_hashes={p.relative_to(target).as_posix():sha(p) for p in (target/'inputs').rglob('*') if p.is_file()},
        code_sha256=sha(__file__),calibration_cutoffs_sha256=sha(target/'results/calibration_cutoffs.csv'),interim_tables_reproduced=interim_checks))
    print('NEW_TABLES_SEALED',len(entries),flush=True)
if __name__=='__main__':main()
