"""Conditional paired group bootstrap of the expanded-source repair contrasts."""
from collections import defaultdict
import time,json,argparse
import numpy as np
from common import OUT,ROOT,read_json,nz,write_json,write_csv,sha
from run_full_analysis import SETTINGS,altered
from reference_allocation import closed_form,allocation_milp
from build_new_tables import LABELS

C=np.arange(8);B=(C&4)!=0;P=(C&2)!=0;R=(C&1)!=0;A=B|R
UP=~B&P;DOWN=B&~P;MAND=~B&R;MISSING=MAND&~P
RATES=np.array([95,95,95,90,90])
def audit(x,cap):
    N=x.sum(axis=(-2,-1));ca=x[...,:6,:].sum(axis=-2);ben=x[...,6,:]
    req=(RATES*x[...,:5,:].sum(axis=-1)+99)//100
    needs=np.maximum(0,req-(x[...,:5,:]*B).sum(axis=-1));un=np.maximum(0,req-(x[...,:5,:]*A).sum(axis=-1))
    t=(ca*MAND).sum(axis=-1)+np.maximum(un.sum(axis=-1),np.maximum(0,(90*ca.sum(axis=-1)+99)//100-(ca*A).sum(axis=-1)))
    BB=(ben*B).sum(axis=-1);BR=(ben*R).sum(axis=-1);m=np.maximum((BB+9)//10,BB-9*BR//10)
    FB=(x*B).sum(axis=(-2,-1));FR=(x*R).sum(axis=(-2,-1))
    fmax=np.minimum(np.minimum(cap*N//100,FB-(N+9)//10),FR-(N+9)//10);rr=np.maximum(m,t+FB-fmax)
    margins=np.stack([-(ca*MISSING).sum(axis=-1),((x[...,:5,:]*UP).sum(axis=-1)-needs).min(axis=-1),(ca*UP).sum(axis=-1)-t,(ben*DOWN).sum(axis=-1)-m,(ben*DOWN).sum(axis=-1)+(x[...,7,:]*DOWN).sum(axis=-1)-rr,N//5-t-rr],axis=-1)
    return (margins>=0).all(axis=-1),margins
def table(x,cap,name):return dict(table_id=name,cap=cap,cells=[[LABELS[j],int(B[c]),int(P[c]),int(R[c]),int(x[j,c])] for j,c in np.argwhere(x>0)])
def spec(cap):return dict(imaging_pct=20,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=cap)
def main():
    global OUT
    ap=argparse.ArgumentParser();ap.add_argument('--reference-mode',choices=['pipeline','frozen'],default='pipeline')
    ap.add_argument('--interim-frozen',action='store_true');args=ap.parse_args()
    plan_path=OUT/'protocol/BOOTSTRAP_PLAN.json'
    if args.interim_frozen:
        assert args.reference_mode=='frozen'
        OUT=OUT/'interim_fixed_reference'
        interim=read_json(OUT/'INTERIM_AUDIT.json');assert interim['status']=='PASS'
        for name,h in interim['decision_hashes'].items():assert sha(OUT/'inputs/tables'/name)==h
    elif args.reference_mode=='frozen':OUT=OUT/'fixed_reference'
    start=time.perf_counter();plan=read_json(plan_path);n=plan['replicates']
    entries=read_json(OUT/'inputs/tables.json');paired=defaultdict(dict)
    for e in entries:
        if e['family']!='source_SP':paired[e['cohort'],e['batch'],e['mode'],e['cap']][e['family']]=e
    keys=sorted(paired);assert len(keys)==100
    rows=[];drawrows=[];validation=[];foldrows=[]
    for setting in SETTINGS:
        rng=np.random.default_rng(plan['seed']);vv=[];observed=[];weights={}
        for key in keys:
            co,batch,mode,cap=key;e=paired[key];a=nz(OUT/'inputs/tables'/e['primary']['file']);b=nz(OUT/'inputs/tables'/e['repaired']['file'])
            la,ca,ga,ia=altered(a,setting);lb,cb,gb,ib=altered(b,setting)
            assert np.array_equal(la,lb) and np.array_equal(ga,gb) and np.array_equal(ia,ib)
            names,gi=np.unique(ga,return_inverse=True);G=len(names);stratum=co,batch
            if stratum not in weights:weights[stratum]=(names,rng.multinomial(G,np.full(G,1/G),size=n))
            assert np.array_equal(names,weights[stratum][0]);w=weights[stratum][1]
            counts=np.zeros((2,G,8,8),dtype=np.int64)
            for stage,c in enumerate([ca,cb]):np.add.at(counts[stage],(gi,la,c),1)
            original=counts.sum(axis=1);truth,mm=audit(original,cap);observed.append(truth)
            sampled=np.einsum('rg,sglc->rslc',w,counts,optimize=True);decisions,margins=audit(sampled,cap)
            assert np.all(decisions[:,1]>=decisions[:,0]);vv.append(decisions)
            for stage in range(2):assert closed_form(table(original[stage],cap,'original'),spec(cap))['margins']==mm[stage].tolist()
            for k in [0,n-1]:
                for stage in range(2):
                    tab=table(sampled[k,stage],cap,f'{setting}_{key}_{k}_{stage}');cf=closed_form(tab,spec(cap));minimum,_=allocation_milp(tab,spec(cap))
                    assert cf['margins']==margins[k,stage].tolist() and minimum==cf['minimum_images']
                    validation.append(dict(setting=setting,cohort=co,batch=batch,mode=mode,cap=cap,replicate=k,stage=stage,minimum_images=minimum))
        vv=np.stack(vv,axis=1);oo=np.array(observed,dtype=int)
        subsets={'all':np.ones(100,bool),'MRA':np.array([k[0]=='MRA' for k in keys]),'UQ':np.array([k[0]=='UQ' for k in keys]),'cap30':np.array([k[3]==30 for k in keys]),'cap50':np.array([k[3]==50 for k in keys])}
        for name,mask in subsets.items():
            diff=100*(vv[:,mask,1].mean(1)-vv[:,mask,0].mean(1));lo,hi=np.quantile(diff,[.025,.975],method='linear')
            rows.append(dict(setting=setting,stratum=name,tables=int(mask.sum()),primary=int(oo[mask,0].sum()),repaired=int(oo[mask,1].sum()),gain_pp=float(100*(oo[mask,1]-oo[mask,0]).mean()),bootstrap_mean_gain_pp=float(diff.mean()),percentile95_low_pp=float(lo),percentile95_high_pp=float(hi),replicates=n))
        for k in range(n):drawrows.append(dict(setting=setting,replicate=k,primary=int(vv[k,:,0].sum()),repaired=int(vv[k,:,1].sum()),gain_pp=int(vv[k,:,1].sum()-vv[k,:,0].sum())))
        for co in ['MRA','UQ']:
            for batch in range(1,6):
                mask=np.array([k[0]==co and k[1]==batch for k in keys]);foldrows.append(dict(setting=setting,cohort=co,batch=batch,tables=int(mask.sum()),primary=int(oo[mask,0].sum()),repaired=int(oo[mask,1].sum())))
        print('BOOTSTRAP_SETTING_COMPLETE',setting,flush=True)
    def save_csv(name,items):write_csv(OUT/'results'/name,[dict(reference_mode=args.reference_mode,**r) for r in items])
    save_csv('paired_gain_summary.csv',rows);save_csv('bootstrap_draws.csv',drawrows)
    save_csv('bootstrap_validation.csv',validation);save_csv('batch_pass_counts.csv',foldrows)
    write_json(OUT/'validation/BOOTSTRAP_AUDIT.json',dict(status='PASS',replicates=n,settings=3,paired_configurations=100,reference_mode=args.reference_mode,milp_checks=len(validation),elapsed_seconds=time.perf_counter()-start,code_sha256=sha(__file__),plan_sha256=sha(plan_path),scope='Conditional on fitted models and frozen decisions; shared group multiplicities across modes/caps/stages; groups with no remaining cases excluded in complete-case setting.'))
if __name__=='__main__':main()
