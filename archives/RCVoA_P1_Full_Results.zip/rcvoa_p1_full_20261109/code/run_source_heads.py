"""Fit source-only fusion heads after each set of six isolated networks."""
from pathlib import Path
import subprocess,sys,time,json
from common import *
KEYS=['p1','p2','p12_L1','p12_L2','p12_L3','clinical_variance','dermoscopic_variance']
def aggregate(arch):
    (OUT/'predictions').mkdir(exist_ok=True);rr=cases();lab={r['id']:r['y'] for r in source()}
    files=[]
    for co in COHORTS:
        parts=[nz(OUT/f'fusion_guarded/{arch}/outer{f}/{co}.npz') for f in range(5)]
        desired=np.array([r['id'] for r in rr if r['cohort']==co]);groups=np.array([r['group'] for r in rr if r['cohort']==co])
        if co=='MILK':
            cat={k:np.concatenate([p[k] for p in parts]) for k in parts[0]};look={s:i for i,s in enumerate(cat['id'])}
            assert len(look)==len(desired)==4978
            ix=np.array([look[s] for s in desired]);a={k:v[ix] for k,v in cat.items()};a['y']=np.array([lab[s] for s in desired],np.int8)
        else:
            assert all(np.array_equal(p['id'],desired) for p in parts)
            a={k:parts[0][k] for k in ['id','group','row_index','fold']}
            for k in KEYS:a[k]=np.mean([p[k] for p in parts],axis=0)
        assert np.array_equal(a['id'],desired) and np.array_equal(a['group'],groups)
        assert np.allclose(a['p12_L1'],(a['p1']+a['p2'])/2,atol=1e-15,rtol=0)
        p=OUT/f'predictions/{arch}__{co}.npz';save_npz(p,**a);files.append(dict(file=p.name,sha256=sha(p)))
    write_json(OUT/f'predictions/{arch}__COMPLETE.json',dict(source_N=4978,source_outer_pipelines=5,files=files,external_outcomes_used=False))

def main():
    for arch in BACKBONES:
        for f in range(5):
            paths=[OUT/f'backbones/{arch}__outer{f}__seed{s}__{m}/result.json' for s in [1,2,3] for m in MODS]
            while not all(p.exists() for p in paths):
                run=OUT/'RUN_STATE.json'
                if run.exists() and read_json(run)['status']=='FAILED':raise RuntimeError(read_json(run))
                time.sleep(15)
            with (OUT/'logs'/f'fusion_{arch}_{f}.log').open('a',encoding='utf-8') as log:
                res=subprocess.run([sys.executable,str(OUT/'code/fusion_guarded.py'),'--arch',arch,'--outer',str(f)],stdout=log,stderr=subprocess.STDOUT,cwd=OUT.parent)
            if res.returncode:raise RuntimeError(f'Fusion failed: {arch}/{f}')
            print('FUSION_COMPLETE',arch,f,flush=True)
        aggregate(arch);print('PREDICTIONS_COMPLETE',arch,flush=True)
    write_json(OUT/'SOURCE_FITS_COMPLETE.json',dict(status='PASS',backbones=3,outer_folds=15,backbone_jobs=90,source_N=4978))
if __name__=='__main__':main()
