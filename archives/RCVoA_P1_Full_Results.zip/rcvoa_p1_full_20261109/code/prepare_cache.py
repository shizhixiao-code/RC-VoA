"""Rebuild the original RGB center crops and verify all unchanged cases."""
from concurrent.futures import ThreadPoolExecutor
import time
from PIL import Image
from torchvision import transforms
from common import *

def main():
    rows=cases();crop=transforms.Compose([transforms.Resize(256,interpolation=transforms.InterpolationMode.BILINEAR,antialias=True),transforms.CenterCrop(224)])
    for mod in MODS:
        p=OUT/f'cache/{mod}_uint8.npy';receipt=p.with_suffix('.json')
        if p.exists() and receipt.exists():
            old=read_json(receipt);assert old['sha256']==sha(p) and old['case_manifest_sha256']==sha(OUT/'metadata/cases.csv');continue
        prior={(r['cohort'],r['id']):r for r in read_csv(ROOT/f'rcvoa_fusion_week1_fp32/cache/{mod}_image_fingerprints.csv')}
        tmp=p.with_suffix('.tmp.npy');a=np.lib.format.open_memmap(tmp,mode='w+',dtype=np.uint8,shape=(len(rows),3,224,224));fingerprints=[];checked=0
        def one(item):
            i,r=item;image_path=ROOT/r[mod+'_image_path']
            with image_path.open('rb') as f:
                digest=hashlib.file_digest(f,'sha256').hexdigest();f.seek(0)
                with Image.open(f) as im:pix=np.asarray(crop(im.convert('RGB')),dtype=np.uint8).transpose(2,0,1).copy()
            rec=dict(row_index=i,cohort=r['cohort'],id=r['id'],modality=mod,image_path=r[mod+'_image_path'],image_sha256=digest,crop_sha256=hashlib.sha256(pix.tobytes()).hexdigest())
            return i,pix,rec
        start=time.time()
        with ThreadPoolExecutor(max_workers=6) as pool:
            for block in range(0,len(rows),64):
                for i,pix,rec in pool.map(one,enumerate(rows[block:block+64],start=block)):
                    key=rec['cohort'],rec['id']
                    if key in prior:
                        assert all(rec[k]==prior[key][k] for k in ['image_sha256','crop_sha256']),key
                        checked+=1
                    a[i]=pix;fingerprints.append(rec)
                if block%1024==0:print('CACHE',mod,block,len(rows),flush=True)
        a.flush();del a;tmp.replace(p)
        assert checked==13885
        write_csv(OUT/f'cache/{mod}_image_fingerprints.csv',fingerprints)
        write_json(receipt,dict(sha256=sha(p),shape=[len(rows),3,224,224],dtype='uint8',case_manifest_sha256=sha(OUT/'metadata/cases.csv'),existing_crops_verified=checked,seconds=time.time()-start,utc=now()))
        print('CACHE_COMPLETE',mod,checked,flush=True)

if __name__=='__main__':main()
