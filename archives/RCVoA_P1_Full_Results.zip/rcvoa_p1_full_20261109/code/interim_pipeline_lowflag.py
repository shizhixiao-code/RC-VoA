"""Early audit of completed low-flag fits with the prespecified refitted pipeline R.

This never enters the formal final-result directories. The full run subsequently
rebuilds the same tables and must reproduce every sealed decision bit.
"""
from pathlib import Path
import json,time,sys,traceback
import numpy as np
from common import OUT,ROOT,read_json,nz,write_json,write_csv,save_npz,sha
from build_new_tables import (OLD,ORIG,MODES,cohort_meta,select_source,scores,
                             percentile,cap_threshold,cutoff,cell_table,source_thresholds)
from run_full_analysis import SETTINGS,altered,stats,MARGINS
from reference_allocation import closed_form,allocation_milp,satisfies

DEST=OUT/'interim_pipeline_reference'

def main():
    d=OUT/'lowflag/source_representation'
    required=[d/f'{mode}__{mod}/COMPLETE.json' for mode in ['headonly','laststage','warmstage','multiscale'] for mod in ['clinical','dermoscopic']]
    required += [d/f'{mode}__fold{f}__{mod}/COMPLETE.json' for mode in ['localheads','localfeatures'] for f in range(5) for mod in ['clinical','dermoscopic']]
    while not all(p.exists() for p in required):
        state=read_json(OUT/'RUN_STATE.json')
        if state.get('status')=='FAILED':raise RuntimeError(state)
        time.sleep(15)
    for p in required:
        r=read_json(p)
        for e in r['exports']:assert sha(p.parent/e['file'])==e['sha256']
    selection=select_source(d);entries=[];cuts=[]
    complete=read_json(OUT/'predictions/convnext_tiny__COMPLETE.json')
    assert complete['source_N']==4978 and complete['source_outer_pipelines']==5
    for item in complete['files']:
        assert sha(OUT/'predictions'/item['file'])==item['sha256']
    source_cut=source_thresholds('convnext_tiny')['S']['p1']
    for co in ['MRA','UQ']:
        meta=cohort_meta(co);fitted=nz(OUT/f'predictions/convnext_tiny__{co}.npz')
        assert np.array_equal(fitted['id'],meta['id']);ref=fitted['p1']>=source_cut
        for mode in MODES:
            original=nz(ORIG/f'{co}__{mode}__planning_decisions.npz')
            assert np.array_equal(original['id'],meta['id']);fold=original['fold']
            for f in range(5):
                te=fold==f;cal=fold==(f+1)%5;de=~(te|cal)
                assert not set(meta['group'][te])&set(meta['group'][cal])
                cp,pp=scores(d,selection,co,mode,f,meta['id'])
                cc=percentile(cp,cp[de]).mean(1);pc=percentile(pp,pp[de]).mean(1)
                for q in [.3,.5]:
                    t1=cap_threshold(cc[te],q);t12=cap_threshold(pc[de],q);b=cc>=t1;p=pc>=t12
                    cut,info=cutoff(meta['labels'][cal],b[cal],ref[cal],pc[cal],t12)
                    repaired=np.where(b,p,pc>=cut);mm={k:v[te] for k,v in meta.items()}
                    for family,pair in [('primary',p),('repaired',repaired)]:
                        key=f'{family}_{co}_{mode}_b{f+1}_q{int(q*100)}'
                        path=DEST/'inputs/tables'/f'{key}.npz'
                        save_npz(path,**mm,cells=b[te].astype(int)*4+pair[te].astype(int)*2+ref[te].astype(int))
                        entries.append(dict(table_id=key,family=family,cohort=co,mode=mode,batch=f+1,cap=int(q*100),file=path.name))
                    cuts.append(dict(cohort=co,mode=mode,batch=f+1,cap=int(q*100),t1=t1,original_t12=t12,repaired_t12=cut,**info))
    assert len(entries)==200 and len(cuts)==100
    write_json(DEST/'inputs/tables.json',entries);write_csv(DEST/'results/calibration_cutoffs.csv',cuts)
    rows=[];checks=0
    for e in entries:
        a=nz(DEST/'inputs/tables'/e['file'])
        for setting in SETTINGS:
            l,c,g,ids=altered(a,setting);tab=cell_table(l,(c&4)>0,(c&2)>0,(c&1)>0,e['table_id'],e['cap'])
            for budget in [15,20]:
                s=dict(imaging_pct=budget,pooled_pct=90,subtype_delta_pp=0,fp_reduction_pct=10,flag_reduction_pp=10,cap=e['cap'])
                cf=closed_form(tab,s);minimum,x=allocation_milp(tab,s)
                assert minimum==cf['minimum_images'];checks+=1
                if x is not None:assert satisfies(tab,np.asarray(x),s)
                margin=cf.pop('margins')
                rows.append({'reference_mode':'pipeline',**e,'setting':setting,'imaging_pct':budget,**stats(l,c,g),**cf,**dict(zip(MARGINS,margin))})
    write_csv(DEST/'results/table_results.csv',rows)
    summary=[]
    for setting in SETTINGS:
        for budget in [15,20]:
            for family in ['primary','repaired']:
                part=[r for r in rows if (r['setting'],r['imaging_pct'],r['family'])==(setting,budget,family)]
                assert len(part)==100
                summary.append(dict(reference_mode='pipeline',setting=setting,imaging_pct=budget,family=family,tables=100,feasible=sum(r['feasible'] for r in part)))
    write_csv(DEST/'results/feasibility_summary.csv',summary)
    write_json(DEST/'INTERIM_AUDIT.json',dict(status='PASS',reference_mode='pipeline',tables=200,independent_milps=checks,
        scope='Completed low-flag fits with the refitted ConvNeXt source-S reference. Full Source S/P and P1 results remain pending.',
        source_thresholds_sha256=sha(OUT/'predictions/convnext_tiny__thresholds.json'),
        decision_hashes={e['file']:sha(DEST/'inputs/tables'/e['file']) for e in entries},code_sha256=sha(__file__)))
    print(json.dumps([r for r in summary if r['imaging_pct']==20],ensure_ascii=False),flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e:
        write_json(DEST/'INTERIM_ERROR.json',dict(error=str(e)));traceback.print_exc();sys.exit(1)
