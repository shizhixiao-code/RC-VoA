"""Generate a source-backed Chinese report only from completed validated results."""
from pathlib import Path
from collections import defaultdict
from datetime import datetime,timezone
import csv,json,hashlib
from common import OUT,ROOT,read_json,read_csv,write_json,sha

NAMES={'reference':'现行外部结局规则','AK_noncancer':'外部 AK 纳入非癌症侧','endpoint_complete_case':'外部原始结局完整病例'}
FAMILIES={'source_SP':'Source S/P','primary':'Primary','repaired':'Repaired'}
def find(rows,**keys):
    found=[r for r in rows if all(str(r[k])==str(v) for k,v in keys.items())];assert len(found)==1,(keys,len(found));return found[0]
def table(headers,rows):
    return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']+['| '+' | '.join(map(str,r))+' |' for r in rows])
def pct(x):return f'{float(x):g}'
def main():
    assert read_json(OUT/'POSTPROCESS_STATE.json')['stage']=='analysis_complete'
    completed=datetime.fromisoformat(read_json(OUT/'POSTPROCESS_STATE.json')['utc'])
    frozen=datetime.fromisoformat(read_json(OUT/'protocol/PLAN.json')['created_utc'])
    workflow_hours=(completed-frozen).total_seconds()/3600
    pauses=read_json(OUT/'USER_PAUSE_INTERVALS.json') if (OUT/'USER_PAUSE_INTERVALS.json').exists() else []
    pause_hours=sum(float(p['seconds']) for p in pauses)/3600
    assert 0<=pause_hours<=workflow_hours
    fit=read_json(OUT/'validation/FITTING_AUDIT.json');assert fit['status']=='PASS'
    old=read_csv(ROOT/'rcvoa_label_sensitivity_20261109/results/feasibility_summary.csv')
    projects=[('重训并更新 R',OUT),('重训并固定原 R',OUT/'fixed_reference')]
    summaries={};gains={};checks=0;bootchecks=0
    for label,p in projects:
        a=read_json(p/'validation/ANALYSIS_AUDIT.json');b=read_json(p/'validation/BOOTSTRAP_AUDIT.json')
        assert a['status']==b['status']=='PASS' and a['protected_files_unchanged']==101
        checks+=a['independent_allocation_milps'];bootchecks+=b['milp_checks']
        summaries[label]=read_csv(p/'results/feasibility_summary.csv');gains[label]=read_csv(p/'results/paired_gain_summary.csv')
    lines=['# P1 完整标签／排除敏感性实验结果','',
       '本轮完成 MILK 纳入规则的训练链重跑，并将训练变化与外部结局定义变化分开核查。论文保持修改前的 8＋4 页版本，未写入新结果。','',
       '## 20% imaging 的主要结果','',
       '分母 36、100、100 均为固定配置数，所有通过数均指自由配额、至多 K 张影像下的分配存在性。全部采用原始 reference targets：pooled sensitivity 90%，MEL／invasive SCC／SCC NOS 95%，BCC／SCCIS 90%，癌症保留、FP 相对减少 10% 及 flags 减少 10 个百分点。Source S/P 不加低工作量绝对 cap；primary 和 repaired 各自均含 30% 与 50% flag cap，每个 cap 各 50 个配置。以下两种 R 口径分别比较，不合并分母。','']
    data=[]
    for setting in NAMES:
        vals=[find(old,setting=setting,family=f,imaging_pct=20)['feasible'] for f in FAMILIES]
        data.append(['原训练规则',NAMES[setting],f'{vals[0]}/36',f'{vals[1]}/100',f'{vals[2]}/100'])
    for label,_ in projects:
        for setting in NAMES:
            vals=[find(summaries[label],setting=setting,family=f,imaging_pct=20)['expanded_source_feasible'] for f in FAMILIES]
            data.append([label,NAMES[setting],f'{vals[0]}/36',f'{vals[1]}/100',f'{vals[2]}/100'])
    lines += [table(['训练／参考决策','外部评估设定','Source S/P','Primary','Repaired'],data),'',
       '“更新 R”重复原来的流水线定义：由重训后的 source-S 得到参考决策。“固定原 R”保留原论文每个病例的 R，并在不相交的校准组上重新选择救回阈值。它检验原参考基准下的结果变化，不额外训练神经网络。','',
       '结果解读：本轮不支持“可行配置比例对源域纳入规则不敏感”。重训后的 repaired 可行数仍高于 primary，但现行外部结局下的 repaired 从 14/100 变为 7/100。这里的区间量化修复相对 primary 的条件增益，不检验原训练与新训练之间的差异是否显著。三种外部结局设定在新训练下给出相同可行计数；主要变化出现在纳入 AK／KA 后重跑训练和校准的完整流程。','',
       '## 15% 与 20% imaging','']
    data=[]
    for label,_ in projects:
        for setting in NAMES:
            vals=[]
            for f in FAMILIES:
                a=find(summaries[label],setting=setting,family=f,imaging_pct=15)['expanded_source_feasible'];b=find(summaries[label],setting=setting,family=f,imaging_pct=20)['expanded_source_feasible']
                vals.append(f'{a} → {b}')
            data.append([label,NAMES[setting],*vals])
    lines += [table(['参考决策口径','外部评估设定','S/P 可行数：15% → 20%','Primary：15% → 20%','Repaired：15% → 20%'],data),'',
       'Source S/P 在 10% imaging 下，原训练与新训练的两种 R 口径均为 0/36。固定原 R 的 15% 与 20% 预算不能合并为同一个结果。','',
       '现行外部结局下，固定原 R 的三个额外容量失败均为 MCR-SL 的 DeiT L1／L2／L3：新 B 产生 197 个 flags，原 R 为 181 个，最终须降至 158 个，因此需 39 次降级；15% 预算为 33 张，20% 为 44 张。更新 R 后该组需 23 次降级，两个预算均满足。这解释了固定 R 的 21/36 与更新 R 的 24/36 在 15% 预算下的差别。','',
       '## Source S/P 的架构分解','']
    old_detail=read_csv(ROOT/'rcvoa_label_sensitivity_20261109/results/table_results.csv')
    current_detail={label:read_csv(p/'results/table_results.csv') for label,p in projects}
    data=[]
    for arch in ['efficientnet_b0','convnext_tiny','deit3_base_patch16_224']:
        def count_arch(rr,budget):
            part=[r for r in rr if r['family']=='source_SP' and r['setting']=='reference' and int(r['imaging_pct'])==budget and r['mode'].startswith(arch+'_')]
            assert len(part)==12
            return f"{sum(r['feasible']=='True' for r in part)}/12"
        data.append([arch,count_arch(old_detail,20),count_arch(current_detail['重训并更新 R'],15),count_arch(current_detail['重训并更新 R'],20),count_arch(current_detail['重训并固定原 R'],15),count_arch(current_detail['重训并固定原 R'],20)])
    lines += [table(['架构','原训练：20%','更新 R：15%','更新 R：20%','固定 R：15%','固定 R：20%'],data),'',
       '现行外部结局、20% 预算下，6 个新增不可行配置为 EfficientNet 的 MCR-SL 三种融合与 ConvNeXt 的 UQ 三种融合，均有 t_star=1、C_minus=0 的救回缺口；3 个新增可行配置为 DeiT 的 MCR-SL 三种融合，其救回需求从 1 变为 0。总体 27→24 包含 6 个丢失与 3 个新增，并非所有架构均下降。Primary 虽仍为 1/100，但原可行配置退出、另一个配置进入。','',
       '## 修复增益与分层','',
       '下列为 20% imaging 下、100 个配置等权的 repaired-minus-primary 百分点差。区间来自 1,000 次条件分组 bootstrap：同一队列、同一评估 batch 中，五种模型、两个 cap 和两个阶段共用 group 重采样权重；每次重算 N、整数目标、预算和可行性。模型、阈值与标签保持固定。','']
    data=[]
    for label,_ in projects:
        for setting in NAMES:
            r=find(gains[label],setting=setting,stratum='all')
            data.append([label,NAMES[setting],pct(r['gain_pp']),f"[{pct(r['percentile95_low_pp'])}, {pct(r['percentile95_high_pp'])}]"])
    lines += [table(['参考决策口径','外部评估设定','修复增益（百分点）','条件 bootstrap 95% 区间'],data),'']
    data=[]
    for label,p in projects:
        rr=read_csv(p/'results/table_results.csv')
        for setting in NAMES:
            part=[r for r in rr if r['family']=='repaired' and r['setting']==setting and int(r['imaging_pct'])==20]
            feasible=[r for r in part if r['feasible']=='True'];needed=[r for r in feasible if int(r['t_star'])>0];zero=sum(int(r['C_minus'])==int(r['t_star']) for r in needed)
            vals=[]
            for field,value in [('cohort','MRA'),('cohort','UQ'),('cap','30'),('cap','50')]:
                sub=[r for r in part if r[field]==value];assert len(sub)==50;vals.append(f"{sum(r['feasible']=='True' for r in sub)}/50")
            needed_text=f'{len(needed)}/{len(feasible)}' if feasible else '无可行配置'
            slack_text=f'{zero}/{len(needed)}' if needed else ('无须救回' if feasible else '不适用')
            data.append([label,NAMES[setting],*vals,needed_text,slack_text])
    lines += [table(['参考决策口径','外部设定','MRA repaired','UQ repaired','30% cap','50% cap','需救回／全部可行','需救回中零 slack'],data),'',
       'Primary／repaired 的系统×队列×cap 每组分母为 5 个 batch，详见 `system_cohort_summary.csv` 与 `fold_stability.csv`；其队列×cap 合计为 25，单队列或单 cap 合计为 50。Source S/P 的架构×融合×队列组合各对应 1 个配置。零 slack 指 C_minus − t_star = 0；本表只在 t_star > 0 的配置中计算，避免将无须救回的情况解释为苛刻选择任务。allocation 存在性与实际选择器成功率是不同指标。','',
       '## 变更配置与失败来源','']
    data=[]
    for label,p in projects:
        rows=read_csv(p/'results/feasibility_summary.csv')
        for setting in NAMES:
            for family in FAMILIES:
                r=find(rows,setting=setting,family=family,imaging_pct=20)
                data.append([label,NAMES[setting],FAMILIES[family],r['newly_feasible'],r['newly_infeasible'],r['support_failure'],r['capacity_only']])
    lines += [table(['参考口径','外部设定','配置组','新增可行','新增不可行','当前全部支持失败','当前全部仅容量失败'],data),'',
       '支持失败指前五项 margin 至少一项为负；仅容量失败指前五项均满足、但影像容量 margin 为负。`training_rule_changes.csv` 给出逐配置的原值、新值、六类 margin、C_minus、B_plus、救回需求、降级需求及基准 flags。`failure_margins_nonexclusive.csv` 保留并存的失败条件，不能将同一配置的多个负 margin 当作互斥原因。','',
       '## 原始标签与训练范围','',
       'MILK 从 4,717 扩至 4,978 个 duplicate components，新增 99 例 AK 与 162 例 KA。原有病例的标签、代表图像和五折分配全部保持；新增病例使用已有 v2 folds。224 个非病理确认病例、33 个 overlap candidates 的排除及五次 duplicate 合并保持原规则。','',
       '新增病例沿用原始 provider binary side：AK=0、KA=1。AK 在 subtype head 中归于非癌症背景，SCCIS 继续单列；KA 进入既有 SCC-family 训练／校准层，source-S 对该层仍用 95% floor。该设定不将 KA 重新病理判定为 invasive SCC。详见 `evidence/LABEL_RULES.md` 和 `metadata/MILK_label_audit.csv`。','',
       '外部 9,168 例中，现行明确二分类结局为 8,969 例；AK 设定增加 92 例非癌症结局，资源分母保持 9,168。完整病例设定移除原来 199 个结局排除病例，资源分母变为 8,969。原有癌症及 subtype 分母保持。其他含糊／未指定诊断未被赋予虚构二分类标签。外部结局设定是已拟合决策的下游审计，不是三个分别重训的外部模型。','',
       f"训练核验通过：{fit['source_backbone_jobs']} 个 isolated backbone jobs、{fit['source_initialization_jobs']} 个初始化模型、{fit['lowflag_training_jobs']} 个 source/local 训练任务，以及 {fit['fusion_outer_pipelines']} 个 source-only fusion outer pipelines。Local fits 保留原始设计组和校准／评估分离。模型选择、早停及学习率规则沿用原配方。",'',
       '## SCCIS／IEC 核验','',
       '原方法已经将 SCCIS 单列并使用 90% floor。将该层仅改名为 IEC、保持成员和 floor 不变，所有计数、整数 deficit 和六类 margin 完全一致。该核验不作为一个新的独立稳健性实验。','',
       '## 计算与复现','',
       f"两种 R 口径共完成 {checks:,} 次表级 allocation MILP 对照，全部与闭式准则一致；bootstrap 另完成 {bootchecks:,} 次独立 MILP 检查。可行整数 witness 已保存。所有求解失败或未证明状态均会中止结果生成，不会被当作不可行。",'',
       f"Isolated backbone 的已提交训练＋源域验证段累计记录时间为 {fit['source_backbone_fit_validation_seconds']/3600:.2f} 小时，包含断点恢复前已提交的训练段。该数值不包含中断的未完成 epoch 开销、预处理、导出、fusion 与低工作量分支，也不是在线 verification 时间。完整训练曲线、恢复记录、运行环境、代码与输入哈希均保留。",'',
       f"从方案冻结到全部数值审计完成的实际经过时间为 {workflow_hours:.2f} 小时，其中用户主动暂停 {pause_hours:.2f} 小时；扣除用户暂停后的流程经过时间为 {workflow_hours-pause_hours:.2f} 小时，仍包含准备、并行计算、等待和恢复。这两种经过时间均与上述累计训练段时间采用不同口径。暂停区间记录于 USER_PAUSE_INTERVALS.json。",'',
       '主要结果目录为 `results/`，固定原 R 的结果位于 `fixed_reference/results/`。大体积新 checkpoint 和低工作量中间文件位于 `G:/RCVoA_P1_20261109_Artifacts/`，位置映射见 `ARTIFACT_STORAGE.json`。原论文及完整交付包位于 `original_version/`，正式稿文件哈希再次核验保持不变。','']
    text='\n'.join(lines)
    (OUT/'RESULTS_CN.md').write_text(text,encoding='utf-8')
    (OUT/'README.md').write_text('''# P1 full label/exclusion sensitivity experiment

The fitted-model and numerical analyses are complete. Read `RESULTS_CN.md` for the full Chinese results and `REPRODUCE.md` for replay instructions. The manuscript remains the preserved 8+4-page version; no experimental result has been inserted into it.

The experiment retains 99 AK and 162 KA source components, refits the original model/calibration chain, and audits three external endpoint settings under two separate reference-decision contracts. Configuration denominators are 36/100/100. Results concern allocation existence, not clinical-input-only selector success.

Main results are in `results/`; the frozen-original-R companion is in `fixed_reference/results/`. Model, role, denominator, integer-allocation, bootstrap and version-preservation checks are recorded in `validation/`. The same-floor SCCIS/IEC rename is an exact equivalence check, not an independent robustness experiment.

`RCVoA_P1_Full_Results.zip` is built after this report and contains compact numerical replay inputs and training receipts; `validation/PACKAGE_AUDIT.json` and `validation/PORTABLE_REPLAY.json` confirm packaging and fresh numerical replay when present. Raw lesion-image pixels and network weights are retained separately. New large model artifacts are at `G:/RCVoA_P1_20261109_Artifacts/`, documented in `ARTIFACT_STORAGE.json`. The original manuscript delivery is backed up in `original_version/`.
''',encoding='utf-8')
    write_json(OUT/'validation/REPORT_AUDIT.json',dict(status='PASS',created_utc=datetime.now(timezone.utc).isoformat(),
        report_sha256=sha(OUT/'RESULTS_CN.md'),reference_contracts=2,endpoint_settings=3,all_main_rows_from_validated_csv=True,
        source_code_sha256=sha(__file__)))
    print('REPORT_COMPLETE',str(OUT/'RESULTS_CN.md'),flush=True)
if __name__=='__main__':main()
