# Source-validation warm-start control

Written before reading any external result from the newly trained ConvNeXt.
Cold last-stage optimization starts with a random subtype head; source validation
favoured fitting that head with a frozen trunk. Test whether this optimization
transient is avoided by first fitting the head, then updating the last stage.

Start from the selected head-only delta for each modality. Keep the same MILK
training/validation folds, deterministic seed, augmentation, balanced losses,
batch size, weight decay, maximum eight epochs and patience two. Learning rates:
last stage/final normalization 1e-5, binary head 1e-5, subtype head 1e-4. Include
the initial head-only checkpoint (epoch zero) in source-validation selection.

Select the feature-training arm per modality from cold and warm last-stage fits
by minimum balanced source-validation loss, with fixed lexical tie-breaking.
The frozen-trunk arm remains the original head-only fit. Record this selection
before running the external policy and planning evaluators. No external labels
or performance enter this choice. Retain all training histories and exports.
