# Fixed image-scale control

Raw-image inspection and header audit identified unequal available detail:
MRA melanoma clinical images have median short side3024 pixels, while UQ
clinical tiles have median66 pixels (range35--120). UQ dermoscopy short side is
4000 pixels. Standard resize256/center224 can reduce small lesions substantially.
This motivates an input-scale ablation, not an assertion that resolution alone
caused the misses.

Use the already source-fitted frozen-trunk ConvNeXt heads, with no new fitting.
For EVERY MRA/UQ clinical and paired record, add centered square crops spanning
one half and one quarter of the original image's short side, bilinearly resized
to224. Retain the original full-view prediction. Each of the two risk coordinates
(cancer log-odds, melanoma-versus-benign log-odds) takes its maximum across the
eligible views. A crop is eligible only when its native side is at least224
pixels; smaller crops cannot recover detail and are omitted from score pooling.
The cache may contain these smaller crops, but inference ignores them. This
eligibility rule was specified from image dimensions before score export.
Clinical and dermoscopic coordinates are subsequently combined in
the same paired-score average. No manually located lesion, segmentation label,
clinical diagnosis or evaluation outcome enters the crop or view aggregation.
Existing calibration-only weighting/routing/gamma selection is unchanged.

Primary50% final flags and20% acquisition; retain30/70% trade-offs. Compare with
the source-head full-view control on identical grouped folds. Low-flag planning
uses the same conditional forecaster, thresholds and20%/80% reference conditions.
Freeze all outputs and policies before recounting outcomes. Do not select a
scale or aggregation after reading its evaluation performance.
