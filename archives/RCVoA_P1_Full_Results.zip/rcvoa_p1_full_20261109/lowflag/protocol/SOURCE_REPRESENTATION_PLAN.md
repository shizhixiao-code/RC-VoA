# Source-only subtype feature learning

Motivation: the original binary source training set has 2,509 BCC and 441
melanomas. Low-flag diagnostics showed weak melanoma separation, not merely a
threshold-calibration error. The controlled intervention changes subtype feature
learning rather than adding another acquisition selector.

Fixed architecture: the existing member-1 ConvNeXt clinical and dermoscopic
checkpoints. Compare (a) frozen trunk with newly learned subtype heads and (b)
the same heads plus updates to the last ConvNeXt stage and final LayerNorm.
Both start from identical source-only binary checkpoints and identical head seeds.
Five subtype classes: benign, melanoma, BCC, SCC, IEC; other source cancer keeps
the binary loss but is excluded from subtype loss. AK/KA exclusions are unchanged.
Loss is half class-balanced subtype cross-entropy and half class-balanced binary
cross-entropy. Training uses MILK folds 2/3/4; validation uses fold0; fold1 is not
used for fitting or checkpoint selection. No external data or labels enter this
training or checkpoint selection. Original nine audit systems are unchanged.

AdamW: last-stage and final-normalization learning rate 1e-5; binary head 1e-4;
subtype head 1e-3; weight decay1e-4. Maximum8 epochs, patience2, select minimum
source validation loss (mean of balanced binary and subtype log loss). Batch24,
FP32, deterministic operations, seed20267023 plus modality index. Both arms use
the same cached224px source images with random horizontal/vertical flips and
90-degree rotations; no stochastic depth during fitting. Frozen export uses the
original unchanged image cache and normalization. Record every epoch and checkpoint.

External selection uses only two scores: binary log-odds and melanoma-versus-
benign log-odds. Paired scores are equal averages of the corresponding clinical
and dermoscopic log-odds. Apply the SAME previously specified weight/route/gamma
grid, 20% imaging cap and 30/50/70% final flags. Calibration group alone chooses
those rules. Clinical-score control has identical queried cases and final flags.
No target-fitted additional classifier is introduced in this comparison. Freeze
both source exports and all external selections before evaluation. Evaluate all
five group folds in MRA/UQ, never choose a fold/backbone from its test results.
The 50% condition remains primary; 70% is a trade-off, not low-workload success.
Report all-floor attainment, melanoma counts, FP, acquisition and individual
retention; use paired grouped bootstrap for the head-only/last-stage comparison.
