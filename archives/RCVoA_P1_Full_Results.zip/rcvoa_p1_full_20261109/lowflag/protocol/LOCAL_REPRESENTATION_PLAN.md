# Design-group adaptation of melanoma features

This protocol is fixed before evaluating the new source-trained ConvNeXt on
external outcomes. The diagnostic target is poor clinical melanoma separation,
which leaves most missed melanomas outside acquisition at 50% flags. Source-only
feature learning cannot directly address target-domain image differences.

Use the same source-only head-fitted ConvNeXt member1 in both conditions. For
each outer evaluation fold f, calibration is f+1 modulo5. Of the three design
folds, f+2 is validation; the remaining two supply gradient updates, pooled across
all four cohorts. No calibration/evaluation group in any cohort enters feature
fitting or checkpoint selection. Every case is evaluated in its own outer fold.

Compare local head fitting alone with the same fitting plus updates to the last
ConvNeXt stage and final LayerNorm. AdamW: heads1e-4; last stage/normalization1e-5;
weight decay1e-4. Balanced sampling gives each represented cohort/subtype cell
equal mass within cohort. Classes are benign, melanoma, BCC, SCC (including NOS),
IEC and other cancer; the last class contributes binary loss only. The binary
loss is reweighted for the sampler's class frequencies; subtype CE is balanced
by its corresponding expected sampling frequencies. Loss averages these two
tasks. Validation uses the mean of cell-averaged binary loss and subtype loss,
so no large cohort or subtype dominates model selection.

Batch24, source image preprocessing/augmentation unchanged, deterministic seed
20269023+10f+modality index. Maximum4 epochs, patience2; the initial source-head
checkpoint is a candidate (epoch0). Keep every history and selected checkpoint.
Do not choose the adaptation condition from external results.

Evaluate the same fixed clinical-only acquisition grid and matched clinical-score
control as SOURCE_REPRESENTATION_PLAN. Primary final flag cap50%, imaging cap20%;
30/70% are declared trade-offs. No workload escalation to force complete detection.
Source-only, locally head-adapted and locally feature-adapted conditions are all
reported. Planning on locally fitted models uses only the separate20% calibration
groups as reference, never in-sample design outcomes. Evaluate 30/50% final flags,
10/20% imaging caps and the same0.95 affirmative threshold. All outerfolds retained.
