"""Endpoint-blind original-resolution crops; no image annotations are read."""
from pathlib import Path
import json,csv,hashlib,io
import numpy as np
from PIL import Image
from concurrent.futures import ThreadPoolExecutor
R=Path(__file__).resolve().parents[1];D=R/'source_representation';W=R.parent;P=R/'protocol/MULTISCALE_INPUT_PLAN.md'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
with (W/'metadata/cases.csv').open() as f:rows=[r for r in csv.DictReader(f) if r['cohort'] in ['MRA','UQ']]
def one(args):
    j,r,mod=args;p=R.parent.parent/r[mod+'_image_path'];data=p.read_bytes()
    with Image.open(io.BytesIO(data)) as raw:
        im=raw.convert('RGB');w,h=im.size;out=[]
        for frac in [.5,.25]:
            n=max(1,int(min(w,h)*frac));left=(w-n)//2;top=(h-n)//2;out.append(np.asarray(im.crop((left,top,left+n,top+n)).resize((224,224),Image.Resampling.BILINEAR)).transpose(2,0,1))
    return j,np.stack(out),dict(id=r['id'],cohort=r['cohort'],modality=mod,width=w,height=h,path=str(p),sha256=hashlib.sha256(data).hexdigest())
import os,time,atexit
lock=D/'MULTISCALE_BUILD.lock';deadline=time.monotonic()+7200
while True:
    if (D/'MULTISCALE_INPUTS.json').exists():
        print('SCALE_CACHE_ALREADY_COMPLETE',flush=True);raise SystemExit(0)
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd);break
    except FileExistsError:
        if time.monotonic()>deadline:raise TimeoutError('Another crop builder has not completed')
        time.sleep(5)
atexit.register(lambda:lock.unlink(missing_ok=True))
files={};records=[]
for mod in ['clinical','dermoscopic']:
    p=D/f'multiscale_crops__{mod}.npy';a=np.lib.format.open_memmap(p,mode='w+',dtype='uint8',shape=(len(rows),2,3,224,224))
    with ThreadPoolExecutor(max_workers=3) as pool:
        for j,pix,rec in pool.map(one,((j,r,mod) for j,r in enumerate(rows))):
            a[j]=pix;records.append(rec)
            if j%1000==0:print(mod,j,flush=True)
    a.flush();del a;files[p.name]=sha(p)
(D/'MULTISCALE_INPUTS.json').write_text(json.dumps(dict(protocol=sha(P),code=sha(__file__),ids=[r['id'] for r in rows],files=files,records=records),indent=2))
print('SCALE_CACHE_COMPLETE',len(rows),flush=True)
