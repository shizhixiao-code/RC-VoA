"""Source-head multi-view inference; no target labels are read."""
from train_source_subtypes import *
PLAN=R/'protocol/MULTISCALE_INPUT_PLAN.md'
rec=json.loads((D/'MULTISCALE_INPUTS.json').read_text());ids=np.array(rec['ids']);assert rec['protocol']==sha(PLAN)
for mod in ['clinical','dermoscopic']:
    dr=D/f'multiscale__{mod}';dr.mkdir(exist_ok=True)
    if (dr/'COMPLETE.json').exists():continue
    setup(20267023+['clinical','dermoscopic'].index(mod));m=Network(mod,'headonly').cuda();state=m.state_dict();initial=D/f'headonly__{mod}/selected_delta.pt';state.update(torch.load(initial,map_location='cpu',weights_only=True));m.load_state_dict(state);m.eval()
    cache=np.load(D/f'multiscale_crops__{mod}.npy',mmap_mode='r');risk=np.zeros((len(ids),2))
    dims={x['id']:min(x['width'],x['height']) for x in rec['records'] if x['modality']==mod};valid=np.array([[int(dims[i]*v)>=224 for v in [.5,.25]] for i in ids])
    with torch.no_grad():
      for st in range(0,len(ids),24):
        x=torch.from_numpy(np.array(cache[st:st+24],copy=True).reshape(-1,3,224,224));b,t,_=m(normalize(x));z=torch.stack([b[:,1]-b[:,0],t[:,1]-t[:,0]],dim=1).cpu().numpy().reshape(-1,2,2);z[~valid[st:st+24]]=-np.inf;risk[st:st+24]=z.max(1)
    exports=[]
    for co in ['MRA','UQ']:
        with np.load(D/f'headonly__{mod}/{co}.npz') as z:
            mask=np.isin(ids,z['id']);assert np.array_equal(ids[mask],z['id']);full=np.column_stack([z['binary_logits'][:,1]-z['binary_logits'][:,0],z['subtype_logits'][:,1]-z['subtype_logits'][:,0]]);out=np.maximum(risk[mask],full)
            p=dr/f'{co}.npz';np.savez_compressed(p,id=z['id'],risk_scores=out);exports.append(dict(file=p.name,sha256=sha(p)))
    dump(dr/'COMPLETE.json',dict(code=sha(__file__),protocol=sha(PLAN),input_manifest=sha(D/'MULTISCALE_INPUTS.json'),initial_delta_sha256=sha(initial),external_training_cases=0,exports=exports))
    del m;torch.cuda.empty_cache();print('SCALE_EXPORT_COMPLETE',mod,flush=True)
