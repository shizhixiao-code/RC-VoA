"""Controlled source-only subtype training; no external endpoints are loaded."""
import os
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
from pathlib import Path
import argparse,csv,json,hashlib,time,random
import numpy as np,torch
from torch import nn
from torch.utils.data import Dataset,DataLoader
from torchvision import models

R=Path(__file__).resolve().parents[1];W=R.parent;D=R/'source_representation';D.mkdir(parents=True,exist_ok=True)
PLAN=R/'protocol/SOURCE_REPRESENTATION_PLAN.md'
def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2)+'\n')
def setup(seed):
    torch.set_num_threads(2);random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);torch.use_deterministic_algorithms(True);torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
with (W/'metadata/cases.csv').open() as f:CASES=list(csv.DictReader(f))
with (W/'metadata/MILK_label_audit.csv').open(encoding='utf-8') as f:
    LAB={r['id']:(int(r['y']),int(r['subtype'])) for r in csv.DictReader(f)}


class Images(Dataset):
    def __init__(self,rows,mod,aug=False):self.rows=rows;self.cache=np.load(W/f'cache/{mod}_uint8.npy',mmap_mode='r');self.aug=aug
    def __len__(self):return len(self.rows)
    def __getitem__(self,i):
        r=self.rows[i];x=torch.from_numpy(np.array(self.cache[int(r['row_index'])],copy=True))
        if self.aug:
            if torch.rand(())<.5:x=x.flip(1)
            if torch.rand(())<.5:x=x.flip(2)
            x=torch.rot90(x,int(torch.randint(4,()).item()),[1,2])
        y,s=LAB[r['id']];return x,y,s

class Network(nn.Module):
    def __init__(self,mod,mode):
        super().__init__();self.base=models.convnext_tiny(weights=None,num_classes=2)
        self.initial=R/'source_initialization/training'/f'member1_{mod}_lr5e-05'/'validation_best.pt'
        self.base.load_state_dict(torch.load(self.initial,map_location='cpu',weights_only=True));self.types=nn.Linear(768,5)
        self.base.requires_grad_(False);self.base.classifier[2].requires_grad_(True)
        if mode=='laststage':self.base.features[7].requires_grad_(True);self.base.classifier[0].requires_grad_(True)
    def forward(self,x):
        h=self.base.classifier[1](self.base.classifier[0](self.base.avgpool(self.base.features(x))));return self.base.classifier[2](h),self.types(h),h

def normalize(x):
    x=x.cuda(non_blocking=True).float().div(255);return (x-torch.tensor([.485,.456,.406],device='cuda')[None,:,None,None])/torch.tensor([.229,.224,.225],device='cuda')[None,:,None,None]

@torch.no_grad()
def validation(m,dl):
    m.eval();yy=[];ss=[];bb=[];tt=[]
    for x,y,s in dl:
        b,t,_=m(normalize(x));yy.append(y.numpy());ss.append(s.numpy());bb.append(b.cpu());tt.append(t.cpu())
    y=np.concatenate(yy);s=np.concatenate(ss);b=torch.cat(bb);t=torch.cat(tt)
    lb=-torch.log_softmax(b,1).numpy()[np.arange(len(y)),y];known=s>=0;lt=-torch.log_softmax(t[known],1).numpy()[np.arange(known.sum()),s[known]]
    binary=float(np.mean([lb[y==v].mean() for v in [0,1]]));subtype=float(np.mean([lt[s[known]==v].mean() for v in np.unique(s[known])]))
    return dict(loss=(binary+subtype)/2,binary_loss=binary,subtype_loss=subtype)

def run(mod,mode):
    dr=D/f'{mode}__{mod}';dr.mkdir(exist_ok=True);complete=dr/'COMPLETE.json'
    if complete.exists():
        cc=json.loads(complete.read_text());assert cc['code']==sha(__file__) and cc['protocol']==sha(PLAN);return
    seed=20267023+['clinical','dermoscopic'].index(mod);setup(seed)
    tr=[r for r in CASES if r['cohort']=='MILK' and int(r['source_fold']) in [2,3,4]];va=[r for r in CASES if r['cohort']=='MILK' and int(r['source_fold'])==0]
    assert not(set(r['id'] for r in tr)&set(r['id'] for r in va));assert all(r['cohort']=='MILK' for r in tr+va)
    dl=DataLoader(Images(tr,mod,True),batch_size=24,shuffle=True,num_workers=0,pin_memory=True,generator=torch.Generator().manual_seed(seed));vl=DataLoader(Images(va,mod),batch_size=32,num_workers=0,pin_memory=True)
    m=Network(mod,mode).cuda();params=[dict(params=m.types.parameters(),lr=1e-3),dict(params=m.base.classifier[2].parameters(),lr=1e-4)]
    if mode=='laststage':params.append(dict(params=list(m.base.features[7].parameters())+list(m.base.classifier[0].parameters()),lr=1e-5))
    opt=torch.optim.AdamW(params,weight_decay=1e-4,foreach=False);cy=np.bincount([LAB[r['id']][0] for r in tr],minlength=2);cs=np.bincount([LAB[r['id']][1] for r in tr if LAB[r['id']][1]>=0],minlength=5)
    wy=torch.tensor(len(tr)/(2*cy),dtype=torch.float32,device='cuda');ws=torch.tensor(cs.sum()/(5*cs),dtype=torch.float32,device='cuda');best=float('inf');bad=0;history=[];start=time.time()
    for epoch in range(8):
        m.eval();losses=[]
        for x,y,s in dl:
            y=y.cuda();s=s.cuda();opt.zero_grad(set_to_none=True);b,t,_=m(normalize(x));known=s>=0;lb=nn.functional.cross_entropy(b,y,weight=wy);lt=nn.functional.cross_entropy(t[known],s[known],weight=ws) if known.any() else 0*b.sum();loss=(lb+lt)/2;assert torch.isfinite(loss);loss.backward();opt.step();losses.append(float(loss.detach()))
        met=validation(m,vl);row=dict(epoch=epoch+1,training_loss=float(np.mean(losses)),**met,elapsed=time.time()-start);history.append(row);dump(dr/'history.json',history);print(mode,mod,json.dumps(row),flush=True)
        if met['loss']<best-1e-8:
            best=met['loss'];bad=0;selected=epoch+1
            keep={n:p.detach().cpu() for n,p in m.named_parameters() if p.requires_grad};torch.save(keep,dr/'selected_delta.pt')
        else:
            bad+=1
            if bad>=2:break
    delta=torch.load(dr/'selected_delta.pt',map_location='cpu',weights_only=True);state=m.state_dict();state.update(delta);m.load_state_dict(state);m.eval()
    exports=[];cache=np.load(W/f'cache/{mod}_uint8.npy',mmap_mode='r')
    with torch.no_grad():
      for co in ['MILK','MRA','HIBA','UQ','MCR-SL']:
        rr=[r for r in CASES if r['cohort']==co];ix=np.array([int(r['row_index']) for r in rr]);bb=[];tt=[]
        for st in range(0,len(ix),32):
            x=torch.from_numpy(np.array(cache[ix[st:st+32]],copy=True));b,t,_=m(normalize(x));bb.append(b.cpu().numpy());tt.append(t.cpu().numpy())
        p=dr/f'{co}.npz';np.savez_compressed(p,id=np.array([r['id'] for r in rr]),binary_logits=np.concatenate(bb),subtype_logits=np.concatenate(tt));exports.append(dict(file=p.name,sha256=sha(p)))
    dump(complete,dict(code=sha(__file__),protocol=sha(PLAN),checkpoint_initial=str(m.initial),initial_sha256=sha(m.initial),delta_sha256=sha(dr/'selected_delta.pt'),selected_epoch=selected,epochs=len(history),source_train=len(tr),source_validation=len(va),seed=seed,external_training_cases=0,exports=exports,torch=torch.__version__,gpu=torch.cuda.get_device_name()))
    del opt,m;torch.cuda.empty_cache()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['headonly','laststage','all'],default='all');a=p.parse_args()
    for mode in ['headonly','laststage'] if a.mode=='all' else [a.mode]:
      for mod in ['clinical','dermoscopic']:run(mod,mode)
