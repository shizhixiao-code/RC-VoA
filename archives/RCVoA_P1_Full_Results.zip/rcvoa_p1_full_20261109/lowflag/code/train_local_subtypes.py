"""Design-only feature adaptation. Test/calibration endpoints are not loaded."""
from train_source_subtypes import *
from torch.utils.data import WeightedRandomSampler
PLAN=R/'protocol/LOCAL_REPRESENTATION_PLAN.md'
with (D/'local_training_manifest.csv').open() as f:MANIFEST=list(csv.DictReader(f))
INDEX={r['id']:r for r in CASES}

class LocalImages(Images):
    def __getitem__(self,i):
        r=self.rows[i];x=torch.from_numpy(np.array(self.cache[int(r['row_index'])],copy=True))
        if self.aug:
            if torch.rand(())<.5:x=x.flip(1)
            if torch.rand(())<.5:x=x.flip(2)
            x=torch.rot90(x,int(torch.randint(4,()).item()),[1,2])
        return x,int(r['y']),int(r['subtype'])

@torch.no_grad()
def valid_local(m,dl,rows):
    m.eval();yy=[];ss=[];bb=[];tt=[]
    for x,y,s in dl:
        b,t,_=m(normalize(x));yy.append(y.numpy());ss.append(s.numpy());bb.append(b.cpu());tt.append(t.cpu())
    y=np.concatenate(yy);s=np.concatenate(ss);b=torch.cat(bb);t=torch.cat(tt);co=np.array([r['cohort'] for r in rows])
    lb=-torch.log_softmax(b,1).numpy()[np.arange(len(y)),y]
    lt=np.zeros(len(y));k=s>=0;lt[k]=-torch.log_softmax(t[k],1).numpy()[np.arange(k.sum()),s[k]]
    vals=[];types=[]
    for c in np.unique(co):
        vals.append(np.mean([lb[(co==c)&(s==v)].mean() for v in np.unique(s[co==c])]))
        types.append(np.mean([lt[(co==c)&(s==v)].mean() for v in np.unique(s[(co==c)&k])]))
    return dict(loss=float((np.mean(vals)+np.mean(types))/2),binary_loss=float(np.mean(vals)),subtype_loss=float(np.mean(types)))

def run_local(f,mod,mode):
    dr=D/f'{mode}__fold{f}__{mod}';dr.mkdir(exist_ok=True)
    if (dr/'COMPLETE.json').exists():
        rec=json.loads((dr/'COMPLETE.json').read_text());assert rec['code']==sha(__file__) and rec['protocol']==sha(PLAN);return
    seed=20269023+10*f+['clinical','dermoscopic'].index(mod);setup(seed)
    def rows(role):return [dict(INDEX[r['id']],**{k:r[k] for k in ['y','subtype','group']}) for r in MANIFEST if int(r['fold'])==f and r['role']==role]
    tr=rows('train');va=rows('validation');assert not(set(r['id'] for r in tr)&set(r['id'] for r in va))
    co=np.array([r['cohort'] for r in tr]);s=np.array([int(r['subtype']) for r in tr]);y=np.array([int(r['y']) for r in tr]);w=np.zeros(len(tr))
    for c in np.unique(co):
        types=np.unique(s[co==c])
        for v in types:
            mask=(co==c)&(s==v);w[mask]=1/len(np.unique(co))/len(types)/mask.sum()
    assert np.isclose(w.sum(),1)
    sampler=WeightedRandomSampler(torch.from_numpy(w),len(tr),replacement=True,generator=torch.Generator().manual_seed(seed))
    dl=DataLoader(LocalImages(tr,mod,True),batch_size=24,sampler=sampler,num_workers=0,pin_memory=True)
    vl=DataLoader(LocalImages(va,mod),batch_size=32,num_workers=0,pin_memory=True)
    m=Network(mod,'laststage' if mode=='localfeatures' else 'headonly').cuda()
    initial=D/f'headonly__{mod}/selected_delta.pt';delta=torch.load(initial,map_location='cpu',weights_only=True);state=m.state_dict();state.update(delta);m.load_state_dict(state)
    params=[dict(params=m.types.parameters(),lr=1e-4),dict(params=m.base.classifier[2].parameters(),lr=1e-4)]
    if mode=='localfeatures':params.append(dict(params=list(m.base.features[7].parameters())+list(m.base.classifier[0].parameters()),lr=1e-5))
    opt=torch.optim.AdamW(params,weight_decay=1e-4,foreach=False)
    py=np.array([w[y==v].sum() for v in [0,1]]);ps=np.array([w[s==v].sum() for v in range(5)])
    wy=torch.tensor(.5/py,dtype=torch.float32,device='cuda');ws=torch.tensor(ps.sum()/(5*ps),dtype=torch.float32,device='cuda')
    best=valid_local(m,vl,va)['loss'];selected=0;bad=0;start=time.time();history=[dict(epoch=0,loss=best,elapsed=0)]
    def save():torch.save({n:p.detach().cpu() for n,p in m.named_parameters() if p.requires_grad},dr/'selected_delta.pt')
    save()
    for epoch in range(4):
        m.eval();losses=[]
        for x,y,s in dl:
            y=y.cuda();s=s.cuda();opt.zero_grad(set_to_none=True);b,t,_=m(normalize(x));known=s>=0
            lb=nn.functional.cross_entropy(b,y,weight=wy);lt=nn.functional.cross_entropy(t[known],s[known],weight=ws) if known.any() else 0*b.sum();loss=(lb+lt)/2
            assert torch.isfinite(loss);loss.backward();opt.step();losses.append(float(loss.detach()))
        met=valid_local(m,vl,va);row=dict(epoch=epoch+1,training_loss=float(np.mean(losses)),**met,elapsed=time.time()-start);history.append(row);dump(dr/'history.json',history);print(mode,f,mod,json.dumps(row),flush=True)
        if met['loss']<best-1e-8:best=met['loss'];selected=epoch+1;bad=0;save()
        else:
            bad+=1
            if bad>=2:break
    state=m.state_dict();state.update(torch.load(dr/'selected_delta.pt',map_location='cpu',weights_only=True));m.load_state_dict(state);m.eval();exports=[]
    cache=np.load(W/f'cache/{mod}_uint8.npy',mmap_mode='r')
    with torch.no_grad():
      for co in ['MRA','UQ']:
        rr=[r for r in CASES if r['cohort']==co];ix=np.array([int(r['row_index']) for r in rr]);bb=[];tt=[]
        for st in range(0,len(ix),32):
            b,t,_=m(normalize(torch.from_numpy(np.array(cache[ix[st:st+32]],copy=True))));bb.append(b.cpu().numpy());tt.append(t.cpu().numpy())
        p=dr/f'{co}.npz';np.savez_compressed(p,id=np.array([r['id'] for r in rr]),binary_logits=np.concatenate(bb),subtype_logits=np.concatenate(tt));exports.append(dict(file=p.name,sha256=sha(p)))
    dump(dr/'COMPLETE.json',dict(code=sha(__file__),protocol=sha(PLAN),manifest_sha256=sha(D/'local_training_manifest.csv'),initial_delta_sha256=sha(initial),selected_delta_sha256=sha(dr/'selected_delta.pt'),outer_fold=f,selected_epoch=selected,validation_loss=best,train=len(tr),validation=len(va),calibration_training_cases=0,evaluation_training_cases=0,exports=exports,seed=seed))
    del opt,m;torch.cuda.empty_cache()

if __name__=='__main__':
    for f in range(5):
      for mode in ['localheads','localfeatures']:
       for mod in ['clinical','dermoscopic']:run_local(f,mod,mode)
