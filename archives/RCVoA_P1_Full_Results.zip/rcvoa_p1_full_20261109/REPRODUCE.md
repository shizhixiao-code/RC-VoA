# Reproducing the P1 experiment

This experiment is separate from the preserved manuscript. `RESULTS_CN.md` is generated only after all model fits and numerical audits pass. During execution, consult `RUN_STATE.json`, `POSTPROCESS_STATE.json`, and `logs/`; their presence alone does not imply completion.

## Numerical replay from the compact archive

Extract `RCVoA_P1_Full_Results.zip` while keeping its two sibling project directories. It contains per-case fixed decision tables and labels, original comparator results, numerical analysis code, protocols, and training receipts. Raw dataset image files and neural-network weights are excluded; the preserved manuscript PDFs include their original figures.

Use Python 3.13 with NumPy 2.5.x and SciPy 1.18.0. From the extracted parent directory, run:

```text
python rcvoa_p1_full_20261109/code/run_full_analysis.py --reference-mode pipeline
python rcvoa_p1_full_20261109/code/bootstrap_repair.py --reference-mode pipeline
python rcvoa_p1_full_20261109/code/run_full_analysis.py --reference-mode frozen
python rcvoa_p1_full_20261109/code/bootstrap_repair.py --reference-mode frozen
python rcvoa_p1_full_20261109/code/check_sccis_equivalence.py
```

These commands reconstruct counts, independent allocation MILP checks, conditional paired group-bootstrap results, and the same-floor SCCIS/IEC equivalence. Results use configuration denominators 36, 100, and 100; the two R contracts and three endpoint settings remain separate. A local `PORTABLE_REPLAY.json` receipt records exact CSV hash comparison against a fresh extracted replay. Off the original computer, manuscript-file preservation is recorded as unavailable rather than falsely verified; this does not alter numerical outputs.

The bootstrap fixes fitted models and thresholds and resamples available groups. It is not a retraining bootstrap or evidence of patient independence where linkage is incomplete. All favorable and unfavorable configurations are retained.

## Training chain

Training uses the original source/model recipes, source v2 duplicate-component folds, pretrained ImageNet weights, image preprocessing, and source-only selection rules. Added source components are 99 AK and 162 KA, with the provider binary side and fine-label mapping stated in `evidence/LABEL_RULES.md`. Source size is 4,978. The immutable main training protocol and amendments are in `protocol.json` and `protocol/`.

The full fit comprises 90 isolated backbone jobs, 2 source-initialization fits, 6 source adapters, 20 local fits, and 15 source-only fusion outer pipelines. External endpoint alternatives are downstream audits of these fits, not three separately fitted external-model branches. Frozen-original-R repair thresholds are recalibrated on the original disjoint calibration groups.

GPU training runtime: Python 3.13.14, PyTorch 2.13.0+cu126, CUDA 12.6, timm 1.0.20, NumPy 2.5.3; NVIDIA GeForce RTX 4060 Laptop GPU. Original isolated-training runtime versions match. Source fusion uses the original CPU interpreter, `.codex_runtime/p1_cuda/Scripts/python.exe` (despite its name, this environment has CPU-only PyTorch 2.13.0+cpu), with NumPy 2.5.1, scikit-learn 1.9.0 and SciPy 1.18.0. `training_runtime.json` and `fusion_runtime.json` record these separately. Original model recipes, source image paths and hashes, fold assignments, and pretrained-weight hashes are retained. The raw datasets and licensed pretrained weights must be restored separately at the paths specified by the preparation scripts and metadata. The numerical archive alone is not a self-contained neural-training dataset.

On the original workstation, GPU fits are managed by `code/run_full_gpu.py`, fusion by `code/run_source_heads.py`, and final audits by `code/run_postprocessing.py`. Completed job receipts are verified before reuse. Only one isolated-backbone training process should run because it uses a shared resume checkpoint. Do not restart preparation or alter protocol files during a running experiment.

Set `OPENBLAS_NUM_THREADS=1` before launching the coordinators to limit idle NumPy thread allocation. This resource setting was applied after eight completed backbone jobs at a model boundary and is documented in `protocol/EXECUTION_THREADS.json`; the scientific recipe and immutable training code remain unchanged. Source fusion retains its original `threadpool_limits(2)` during fitting. The delivery watcher does not import numerical libraries while waiting.

Large new checkpoints and low-flag intermediates are at `G:/RCVoA_P1_20261109_Artifacts/`, connected through local directory junctions documented in `ARTIFACT_STORAGE.json`. Existing models and manuscript files are preserved. `original_version/` contains the main/supplement PDF copies and the original complete delivery ZIP.

Timing fields state their scope. Summed backbone fit/validation time includes committed pre-resume training segments recorded in `validation/RESUME_HISTORY.json`, and excludes interrupted partial-epoch overhead, export, cache preparation, fusion, and low-flag stages; it is not online verification time. A Windows commit-memory interruption during an auxiliary concurrent loader check was recovered from the prior completed epoch, preserving the original model/optimizer state, seeds, and recipe. Completed models were retained. The auxiliary loader check is run separately from model training to avoid competing worker processes.
